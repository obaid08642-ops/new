import React, { useEffect, useState } from 'react';
import { View, Modal, TouchableOpacity, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { SP, FS, R } from '../constants';
import { useTheme, useLang, useToast } from '../context';
import { I as NIcon } from './icons';
import client from '../api/client';
import { translateProviderPair, translateProviderTemplate } from '../i18n/providerTextTranslations';

interface ContractModalProps {
  visible: boolean;
  onClose: () => void;
  pricingDetails?: { labelAr: string; labelEn: string; price: string | number }[];
}

export const ContractModal: React.FC<ContractModalProps> = ({ visible, onClose, pricingDetails }) => {
  const { theme } = useTheme();
  const { lang } = useLang();
  const { show } = useToast();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

  // Fetch the live Provider Agreement from the legal service (ar/en, versioned).
  const [policy, setPolicy] = useState<{ content: string; version: string } | null>(null);
  const [loadingPolicy, setLoadingPolicy] = useState(false);
  const [accepting, setAccepting] = useState(false);
  useEffect(() => {
    if (!visible) return;
    setPolicy(null);
    setLoadingPolicy(true);
    client.get(`/legal/policy/provider_agreement?lang=${AR ? 'ar' : 'en'}`)
      .then((res: any) => {
        if (res.data?.content && res.data?.version) setPolicy({ content: res.data.content, version: res.data.version });
      })
      .finally(() => setLoadingPolicy(false));
  }, [visible, AR]);

  const styles = StyleSheet.create({
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    modal: { width: '90%', height: '80%', backgroundColor: theme.bg, borderRadius: R.lg, padding: SP.lg },
    header: { flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SP.md },
    title: { fontSize: FS.lg, fontWeight: 'bold', color: theme.text },
    closeBtn: { padding: SP.xs },
    content: { flex: 1, backgroundColor: theme.surface, padding: SP.md, borderRadius: R.md },
    text: { fontSize: FS.md, color: theme.text, textAlign: AR ? 'right' : 'left', lineHeight: 26 },
    pricingSection: { marginTop: SP.md, padding: SP.md, backgroundColor: theme.surface2, borderRadius: R.sm },
    pricingTitle: { fontWeight: 'bold', marginBottom: SP.sm, color: theme.text },
    pricingRow: { flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', marginBottom: 4 },
    confirmBtn: { padding: SP.md, borderRadius: R.md, backgroundColor: theme.primary, marginTop: SP.md },
    confirmTxt: { color: 'white', textAlign: 'center', fontWeight: 'bold' }
  });

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>{tr('عقد تقديم الخدمات', 'Service Provision Contract')}</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <NIcon name="close" size={24} color={theme.text} />
            </TouchableOpacity>
          </View>
          <ScrollView style={styles.content}>
            {loadingPolicy && <ActivityIndicator color={theme.primary} style={{ marginVertical: SP.lg }} />}
            <Text style={styles.text}>
              {policy ? policy.content : tr('لا يمكن عرض أو قبول العقد قبل تحميل النسخة القانونية المعتمدة من الخادم.', 'The agreement cannot be displayed or accepted until the approved legal version is loaded from the server.')}
            </Text>
            {policy && (
              <Text style={[styles.text, { fontSize: FS.xs, color: theme.textSub, marginTop: SP.sm }]}>
                {trT("الإصدار {0}", "Version {0}", [policy.version])}
              </Text>
            )}
            
            {pricingDetails && pricingDetails.length > 0 && (
              <View style={styles.pricingSection}>
                <Text style={styles.pricingTitle}>{tr('ملحق التسعير المتفق عليه:', 'Agreed Pricing Annex:')}</Text>
                {pricingDetails.map((item, idx) => (
                  <View key={idx} style={styles.pricingRow}>
                    <Text style={{color: theme.textSub}}>{AR ? item.labelAr : item.labelEn}</Text>
                    <Text style={{fontWeight: 'bold', color: theme.text}}>{item.price} {tr('ر.س', 'SAR')}</Text>
                  </View>
                ))}
              </View>
            )}
            
            {policy && <Text style={[styles.text, { marginTop: SP.md, fontWeight: 'bold' }]}> 
              {tr('(يعتبر هذا العقد ملزماً بمجرد التوقيع الرقمي أدناه)', '(This contract is binding upon digital signature below)')}
            </Text>}
          </ScrollView>

          <TouchableOpacity
            style={[styles.confirmBtn, (accepting || !policy) && { opacity: 0.6 }]}
            disabled={accepting || !policy}
            onPress={async () => {
              if (!policy) {
                show(tr('لا يمكن قبول عقد غير محمل من الخادم.', 'An agreement not loaded from the server cannot be accepted.'), 'error');
                return;
              }
              setAccepting(true);
              try {
                await client.post('/legal/accept/provider_agreement');
                show(tr('تم تسجيل الموافقة بعد تأكيد الخادم.', 'Acceptance was recorded after server confirmation.'), 'success');
                onClose();
              } catch {
                show(tr('تعذر تسجيل الموافقة على العقد من الخادم.', 'The server could not record agreement acceptance.'), 'error');
              } finally {
                setAccepting(false);
              }
            }}
          >
            <Text style={styles.confirmTxt}>
              {accepting ? tr('جارٍ التسجيل…', 'Recording…') : policy ? tr('أوافق', 'I Agree') : tr('العقد غير متاح', 'Agreement unavailable')}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};
