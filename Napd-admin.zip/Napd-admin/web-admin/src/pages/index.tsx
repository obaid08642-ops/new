import { useEffect } from 'react';
import { useRouter } from 'next/router';

/**
 * M0-11 — Root route now routes to the admin app (was the default
 * create-next-app template left in production code).
 */
export default function Home() {
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    const role = localStorage.getItem('admin_role');
    router.replace(token && role === 'admin' ? '/admin/dashboard' : '/login');
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900 text-slate-300" dir="rtl">
      جاري التوجيه إلى لوحة التحكم...
    </div>
  );
}
