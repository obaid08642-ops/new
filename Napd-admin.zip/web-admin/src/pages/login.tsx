import React, { useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8002';

/**
 * M0-11 — Admin login screen (was completely missing).
 * Flow: credentials → POST /auth/login → admins always get requires_2fa →
 * OTP → POST /auth/login/verify-2fa → store session → /admin/dashboard.
 */
export default function AdminLogin() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'credentials' | 'otp'>('credentials');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/v1/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: identifier.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || 'بيانات الدخول غير صحيحة');

      if (data?.requires_2fa) {
        setStep('otp');
        return;
      }
      completeLogin(data);
    } catch (err: any) {
      setError(err?.message || 'تعذر الاتصال بالخادم');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/v1/auth/login/verify-2fa`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: identifier.trim(), code: otp.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || 'رمز التحقق غير صحيح');
      completeLogin(data);
    } catch (err: any) {
      setError(err?.message || 'تعذر التحقق من الرمز');
    } finally {
      setLoading(false);
    }
  };

  const completeLogin = (data: any) => {
    const role = data?.user?.role;
    if (role !== 'admin' && role !== 'super_admin') {
      setError('هذا الحساب لا يملك صلاحيات الإدارة');
      return;
    }
    // M0-12: unified session keys across the admin app
    localStorage.setItem('admin_token', data?.token?.accessToken || data?.token || '');
    localStorage.setItem('admin_refresh_token', data?.token?.refreshToken || '');
    localStorage.setItem('admin_role', role);
    localStorage.setItem('admin_user', JSON.stringify(data?.user || {}));
    router.push('/admin/dashboard');
  };

  return (
    <>
      <Head>
        <title>تسجيل الدخول — لوحة تحكم نبضة</title>
      </Head>
      <div className="min-h-screen flex items-center justify-center bg-slate-900" dir="rtl">
        <div className="w-full max-w-md bg-slate-800 rounded-2xl shadow-2xl p-8 border border-slate-700">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-teal-400 tracking-wider">NABDah</h1>
            <p className="text-slate-400 mt-2">لوحة تحكم الإدارة المركزية</p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/40 text-red-400 text-sm text-center">
              {error}
            </div>
          )}

          {step === 'credentials' ? (
            <form onSubmit={handleLogin} className="space-y-5">
              <div>
                <label className="block text-sm text-slate-300 mb-2">رقم الجوال أو البريد الإلكتروني</label>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  required
                  dir="ltr"
                  className="w-full px-4 py-3 rounded-lg bg-slate-900 border border-slate-600 text-white focus:border-teal-400 focus:outline-none"
                  placeholder="+9665XXXXXXXX"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-300 mb-2">كلمة المرور</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-lg bg-slate-900 border border-slate-600 text-white focus:border-teal-400 focus:outline-none"
                  placeholder="••••••••••••"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-900 font-bold transition-colors disabled:opacity-50"
              >
                {loading ? 'جاري التحقق...' : 'تسجيل الدخول'}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-5">
              <p className="text-slate-300 text-sm text-center">
                تم إرسال رمز التحقق الثنائي إلى جهات الاتصال المسجلة. أدخل الرمز المكوّن من 6 أرقام:
              </p>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                required
                dir="ltr"
                className="w-full px-4 py-3 rounded-lg bg-slate-900 border border-slate-600 text-white text-center text-2xl tracking-[0.5em] focus:border-teal-400 focus:outline-none"
                placeholder="——————"
              />
              <button
                type="submit"
                disabled={loading || otp.length !== 6}
                className="w-full py-3 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-900 font-bold transition-colors disabled:opacity-50"
              >
                {loading ? 'جاري التحقق...' : 'تأكيد الدخول'}
              </button>
              <button
                type="button"
                onClick={() => { setStep('credentials'); setOtp(''); setError(''); }}
                className="w-full py-2 text-slate-400 hover:text-teal-400 text-sm transition-colors"
              >
                ← العودة لتسجيل الدخول
              </button>
            </form>
          )}
        </div>
      </div>
    </>
  );
}
