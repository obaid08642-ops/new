import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve('src/pages/admin/disputes.tsx'), 'utf8');
assert.match(source, /if \(action === 'refund'\) \{/);
assert.match(source, /طابور الاستردادات المعتمد/);
assert.doesNotMatch(source, /action === 'refund' \? 'تم إرسال قرار/);
assert.match(source, /\/force-cancel/);
console.log('admin refund contract: passed');
