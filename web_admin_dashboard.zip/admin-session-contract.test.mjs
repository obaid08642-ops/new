import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';

const root = path.resolve(import.meta.dirname);
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('admin session is cookie-only and server-authorized', () => {
  const login = read('src/pages/login.tsx');
  const api = read('src/utils/api.ts');
  const guard = read('src/components/AdminGuard.tsx');
  const audit = read('src/pages/admin/audit-logs.tsx');
  const disputes = read('src/pages/admin/disputes.tsx');

  for (const source of [login, api, guard, audit, disputes]) {
    assert.equal(source.includes('localStorage'), false);
    assert.equal(source.includes('sessionStorage'), false);
    assert.equal(source.includes('Authorization: `Bearer'), false);
  }
  assert.match(login, /credentials: 'include'/);
  assert.match(api, /credentials: 'include'/);
  assert.match(api, /X-Requested-With/);
  assert.match(guard, /apiFetch\('\/auth\/me'\)/);
  assert.match(guard, /auth\/logout/);
  assert.match(disputes, /apiFetch\('\/admin\/disputes'\)/);
});
