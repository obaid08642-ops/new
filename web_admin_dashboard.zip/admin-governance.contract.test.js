const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const assert = require('node:assert/strict');

test('config portal contains unimplemented global operations instead of claiming browser execution', () => {
  const source = fs.readFileSync(path.join(__dirname, 'src/pages/admin/config-portal.tsx'), 'utf8');
  assert.equal(source.includes("adminId: 'admin-master-001'"), false);
  assert.equal(source.includes('التحكم التشغيلي غير متاح من لوحة المتصفح'), true);
  assert.equal(source.includes('لا تعرض هذه الواجهة حالة نظام أو نجاحاً غير مؤكدين.'), true);
});

test('notification campaign UI requires audience confirmation and contains unapproved manual retargeting', () => {
  const source = fs.readFileSync(path.join(__dirname, 'src/pages/admin/notification-center.tsx'), 'utf8');
  assert.equal(source.includes('audienceConfirmed'), true);
  assert.equal(source.includes('لم يؤكد الخادم إرسال الإشعار'), true);
  assert.equal(source.includes('إعادة الاستهداف اليدوية غير متاحة من المتصفح'), true);
  assert.equal(source.includes('const runRetarget'), false);
});

test('SOS monitor does not expose emergency PHI or browser dispatch controls before approval', () => {
  const source = fs.readFileSync(path.join(__dirname, 'src/pages/admin/sos-monitor.tsx'), 'utf8');
  assert.equal(source.includes('سطح الطوارئ الإداري غير متاح'), true);
  assert.equal(source.includes('لا تعرض هذه الواجهة حالات الطوارئ أو هوية المريض أو موقعه'), true);
});

test('AI control does not expose model routing or usage operations before governance approval', () => {
  const source = fs.readFileSync(path.join(__dirname, 'src/pages/admin/ai-control.tsx'), 'utf8');
  assert.equal(source.includes('التحكم الإداري بالذكاء الاصطناعي غير متاح'), true);
  assert.equal(source.includes('لا تعرض هذه الواجهة حالة مزودي النماذج أو سجل الاستخدام'), true);
});

test('nursing portal does not expose patient address or direct assignment before workflow approval', () => {
  const source = fs.readFileSync(path.join(__dirname, 'src/pages/admin/nursing-portal.tsx'), 'utf8');
  assert.equal(source.includes('عمليات التمريض الإدارية غير متاحة'), true);
  assert.equal(source.includes('لا تعرض هذه الواجهة بيانات المريض أو العنوان'), true);
});

test('dispute portal does not expose case data or trigger cancellation before financial workflow approval', () => {
  const source = fs.readFileSync(path.join(__dirname, 'src/pages/admin/disputes.tsx'), 'utf8');
  assert.equal(source.includes('عمليات النزاعات والاسترداد غير متاحة'), true);
  assert.equal(source.includes('لا تعرض هذه الواجهة بيانات قضية أو مبالغ'), true);
});
