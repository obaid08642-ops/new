const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const assert = require('node:assert/strict');

test('config portal contains unimplemented global operations instead of claiming browser execution', () => {
  const source = fs.readFileSync(path.join(__dirname, 'src/pages/admin/config-portal.tsx'), 'utf8');
  assert.equal(source.includes("adminId: 'admin-master-001'"), false);
  assert.equal(source.includes('التحكم التشغيلي غير متاح من لوحة المتصفح'), true);
  assert.equal(source.includes('لا تعرض هذه الواجهة حالة نظام أو نجاحاً غير مؤكدين.'), true);
});
