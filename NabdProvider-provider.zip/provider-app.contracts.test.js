const fs = require('node:fs');
const path = require('node:path');

describe('Provider App release contracts', () => {
  const root = process.cwd();
  const dashboard = fs.readFileSync(path.join(root, 'src/screens/doctor/DoctorDashboard.tsx'), 'utf8');
  const pharmacyDashboard = fs.readFileSync(path.join(root, 'src/screens/pharmacy/PharmacyDashboard.tsx'), 'utf8');
  const radiologyDashboard = fs.readFileSync(path.join(root, 'src/screens/radiology/RadiologyDashboard.tsx'), 'utf8');
  const authContext = fs.readFileSync(path.join(root, 'src/context/index.tsx'), 'utf8');
  const platformMapWeb = fs.readFileSync(path.join(root, 'src/components/PlatformMap.web.tsx'), 'utf8');
  const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
  const registrations = [
    'doctor/DoctorRegistration.tsx',
    'pharmacy/PharmacyRegistration.tsx',
    'lab/LabRegistration.tsx',
    'radiology/RadiologyRegistration.tsx',
    'nursing/NursingRegistration.tsx',
  ].map(file => fs.readFileSync(path.join(root, 'src/screens', file), 'utf8')).join('\n');
  const config = JSON.parse(fs.readFileSync(path.join(root, 'app.json'), 'utf8')).expo;
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

  it('has explicit production API and native platform identifiers', () => {
    expect(config.extra.apiBaseUrl).toBe('https://api.nabd.plus/api/v1');
    expect(config.android.package).toBe('com.nabd.plus.provider');
    expect(config.ios.bundleIdentifier).toBe('com.nabd.plus.provider');
    expect(config.userInterfaceStyle).toBe('automatic');
  });

  it('does not ship an insecure runtime API override or legacy endpoint domain', () => {
    const constants = read('src/constants/index.ts');
    const client = read('src/api/client.ts');
    const auth = read('src/context/index.tsx');
    const login = read('src/screens/auth/AuthScreens.tsx');
    const httpClient = read('src/services/HttpClient.ts');
    expect(constants).toContain("const PRODUCTION_API_BASE = 'https://api.nabd.plus/api/v1'");
    expect(constants).toContain('Unsafe provider API configuration');
    expect(constants).not.toContain('LOCAL_DEV_API');
    expect(constants).not.toContain('10.0.2.2');
    expect(client).not.toContain('CUSTOM_API_IP');
    expect(auth).not.toContain('CUSTOM_API_IP');
    expect(login).not.toContain('Override API IP');
    expect(httpClient).toContain('baseURL: API_BASE');
    for (const source of [constants, client, auth, login, httpClient]) expect(source).not.toMatch(/nabdahplus\.(sa|com)/);
  });

  it('routes pending, rejected and suspended provider states away from operational dashboards', () => {
    const app = read('App.tsx');
    const context = read('src/context/index.tsx');
    const pending = read('src/screens/auth/PendingDashboard.tsx');
    expect(context).toContain("if (normalized === 'approved' || normalized === 'active')");
    expect(context).toContain("setAppState('pending')");
    expect(app).toContain("appState === 'pending' || appState === 'rejected' || appState === 'suspended'");
    expect(pending).toContain('Refresh review status');
    expect(pending).not.toContain("label={AR ? 'استكشاف التطبيق' : 'Explore App'}");
  });

  it('does not fabricate patient identity or financial values in intake mapping', () => {
    expect(dashboard).not.toContain('test_patient');
    expect(dashboard).not.toContain("national_id || '1029384756'");
    expect(dashboard).not.toContain("dob || '1980-05-12'");
    expect(dashboard).not.toMatch(/price\s*:\s*x\.total\s*\|\|\s*150/);
    expect(dashboard).toContain('const patientId = apt?.patient_id');
  });

  it('contains doctor financial and clinical surfaces when server contracts are absent', () => {
    expect(dashboard).not.toContain('setWallet({ available: 4200, escrow: 1500, dues: 800 });');
    expect(dashboard).not.toContain("patient_name: 'أحمد السالم'");
    expect(dashboard).not.toContain("patientName: AR ? 'أحمد محمد'");
    expect(dashboard).not.toContain('https://example.com/report1.pdf');
    expect(dashboard).toContain('Wallet data could not be loaded. No substitute balances or transactions are shown.');
    expect(dashboard).toContain('Claims are unavailable from this screen');
    expect(dashboard).toContain('Calendar sync is not enabled');
    expect(dashboard).toContain("if (!response.ok) throw new Error('ping rejected');");
    expect(dashboard).toContain("if (!response.ok) throw new Error('no-show rejected');");
  });

  it('does not invent doctor schedules, referrals, sick leave identifiers, QR claims, or success states after server failure', () => {
    expect(dashboard).not.toContain("{ id: 'apt1', patient: AR ? 'سارة المطيري'");
    expect(dashboard).not.toContain("{ id: 'ref1', patientName: apt?.patient || (AR ? 'أحمد محمد السالم'");
    expect(dashboard).not.toContain("patient_id: apt?.patient_id || 'test'");
    expect(dashboard).not.toContain("/provider/requests/${apt?.id || 'new'}/sick-leave");
    expect(dashboard).not.toContain("x.patient_name || (AR ? 'مريض نبض' : 'Nabdah Patient')");
    expect(dashboard).not.toContain("x.insurance_provider || 'Cash'");
    expect(dashboard).not.toContain('Graceful fallback for demo/offline');
    expect(dashboard).not.toContain('unique QR code verifiable by employers');
    expect(dashboard).not.toContain("name_ar: 'ترخيص الهيئة السعودية للتخصصات الصحية'");
    expect(dashboard).not.toContain('images.unsplash.com/photo-1629909613654');
    expect(dashboard).not.toContain("show(AR ? 'تم رفع المستند بنجاح وهو قيد المراجعة'");
    expect(dashboard).not.toContain("show(AR ? 'تم إضافة الصورة بنجاح'");
    expect(dashboard).toContain(".catch(() => setApts([]));");
    expect(dashboard).toContain('A linked request and patient are required to issue sick leave.');
    expect(dashboard).toContain('No referrals are shown until referral history is connected to a verified server contract.');
    expect(dashboard).toContain('Referral sent after server confirmation.');
    expect(dashboard).toContain('Qualifications are unavailable until the professional-document contract is verified.');
    expect(dashboard).toContain('Media is unavailable until the storage and upload contract is verified.');
  });

  it('contains real provider intake actions and refreshes after mutations', () => {
    expect(dashboard).toContain('/provider/jobs/queue?status=incoming&kind=consultation');
    expect(dashboard).toContain('/provider/jobs/');
    expect(dashboard).toContain('/provider/stats/today');
    expect(dashboard).toContain('fetchQueue();');
  });

  it('uses accessible, RTL-aware shared buttons with controlled feedback rather than emoji-only actions', () => {
    const ui = read('src/components/ui.tsx');
    expect(ui).toContain('accessibilityRole="button"');
    expect(ui).toContain('accessibilityState={{ disabled: !!(disabled || loading), busy: !!loading }}');
    expect(ui).toContain("flexDirection:isRTL?'row-reverse':'row'");
    expect(ui).toContain("if (Platform.OS !== 'web') Vibration.vibrate(18);");
  });

  it('does not fabricate chat history, delivery success, calls, or attachments without a verified contract', () => {
    const shared = read('src/screens/shared/SharedScreens.tsx');
    expect(shared).not.toContain("text: AR ? 'مرحباً دكتور، أود الاستفسار عن حالتي'");
    expect(shared).not.toContain("text: AR ? 'أهلاً بك، تفضل'");
    expect(shared).not.toContain('// optimistic UI send');
    expect(shared).toContain('setMessages([]);');
    expect(shared).toContain('Sending messages is unavailable until this screen is bound to a verified chat contract.');
    expect(shared).toContain('Voice calling is not available from this screen.');
    expect(shared).toContain('Video calling is not available from this screen.');
    expect(shared).toContain('secure upload contract is verified');
  });

  it('fails closed for pharmacy chat rather than opening an unauthenticated socket or fabricating messages and invoices', () => {
    const pharmacyChat = read('src/screens/shared/PharmacyChatResponder.tsx');
    expect(pharmacyChat).not.toContain("from 'socket.io-client'");
    expect(pharmacyChat).not.toContain('pharmacy:message:send');
    expect(pharmacyChat).not.toContain("text: 'تم إنشاء الفاتورة'");
    expect(pharmacyChat).not.toContain("id: Date.now()");
    expect(pharmacyChat).toContain('verified, secure pharmacy-chat contract');
    expect(pharmacyChat).toContain('لن نعرض رسائل أو فواتير محلية');
  });

  it('does not present local notification, support-ticket, device, or security-state changes as server-backed operations', () => {
    const shared = read('src/screens/shared/SharedScreens.tsx');
    expect(shared).not.toContain("setNotifs(prev => prev.map(n => ({ ...n, read: true }))");
    expect(shared).not.toContain("subject_ar: 'مشكلة في الدفع'");
    expect(shared).not.toContain("Ticket submitted — reply within 24h");
    expect(shared).not.toContain("name: 'iPhone 15 Pro'");
    expect(shared).not.toContain("show(v ? (AR ? 'تم تفعيل 2FA'");
    expect(shared).toContain('Read-state updates are unavailable until a server contract is verified.');
    expect(shared).toContain('No tickets are shown until support history is connected to a verified server contract.');
    expect(shared).toContain('Ticket creation is unavailable until a support contract and secure data retention are verified.');
    expect(shared).toContain('Device management and security settings are unavailable until they are connected to verified session and device contracts.');
  });

  it('does not ship fake pharmacy/radiology terminal actions', () => {
    expect(pharmacyDashboard).not.toContain('Simulate Drug Scan');
    expect(pharmacyDashboard).not.toContain('طلب وصفة #B-9901');
    expect(pharmacyDashboard).toContain("client.get('/provider/pharmacy/broadcasts')");
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${orderId}/i-have-all');
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${rejectOrderId}/reject');
    expect(pharmacyDashboard).not.toContain('/pharmacy/orders/${rejectOrderId}/reject');
    expect(pharmacyDashboard).toContain("client.get('/provider/pharmacy/allocations', { params: { status: 'completed' } })");
    expect(radiologyDashboard).not.toContain('Coming with S3 integration');
    expect(radiologyDashboard).not.toContain("'https://storage.nabdah.com/reports/' + order.id + '.pdf'");
    expect(radiologyDashboard).toContain('HTTPS URL for the signed PDF report');
  });

  it('uses the broadcast allocation contract for pharmacy acceptance and rejection', () => {
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${orderId}/i-have-all');
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${rejectOrderId}/reject');
    expect(pharmacyDashboard).not.toContain('/provider/pharmacy/orders/${orderId}/accept');
    expect(pharmacyDashboard).toContain('res.data?.allocation?.id');
    expect(pharmacyDashboard).toContain('No local order state changed.');
  });

  it('uses supported lab sample/report contracts without placeholder clinical output', () => {
    const labDashboard = read('src/screens/lab/LabDashboard.tsx');
    expect(labDashboard).toContain("client.post('/labs/samples/register'");
    expect(labDashboard).toContain("stage: 'result_ready'");
    expect(labDashboard).toContain('verified_result_data_required');
    expect(labDashboard).toContain('sample_rejection_requires_verified_qc_workflow');
    expect(labDashboard).not.toContain("{ file: 'lab_report_signature.pdf' }");
    expect(labDashboard).not.toContain("stage: 'result_uploaded'");
    expect(labDashboard).not.toContain("stage: 'sample_rejected'");
    expect(labDashboard).not.toContain("value:'7.2'");
  });

  it('uses Expo Camera for barcode scans without the deprecated scanner package', () => {
    const labDashboard = read('src/screens/lab/LabDashboard.tsx');
    const facilityDashboard = read('src/screens/facility/FacilityDashboard.tsx');
    expect(manifest.dependencies['expo-barcode-scanner']).toBeUndefined();
    expect(labDashboard).toContain("from 'expo-camera'");
    expect(labDashboard).toContain('CameraView');
    expect(labDashboard).toContain('onBarcodeScanned');
    expect(facilityDashboard).toContain('onBarcodeScanned');
    expect(labDashboard).not.toContain('expo-barcode-scanner');
    expect(facilityDashboard).not.toContain('expo-barcode-scanner');
  });

  it('uses Expo Audio for provider alerts without the unmaintained expo-av package', () => {
    expect(manifest.dependencies['expo-av']).toBeUndefined();
    expect(manifest.dependencies['expo-audio']).toBeDefined();
    expect(dashboard).toContain("from 'expo-audio'");
    expect(dashboard).toContain('createAudioPlayer');
    expect(dashboard).toContain('player.loop = true');
    expect(pharmacyDashboard).toContain("from 'expo-audio'");
    expect(pharmacyDashboard).toContain('createAudioPlayer');
    expect(dashboard).not.toContain("from 'expo-av'");
    expect(pharmacyDashboard).not.toContain("from 'expo-av'");
  });

  it('uses a verified bank and server payout reference before presenting a withdrawal request', () => {
    const shared = read('src/screens/shared/SharedScreens.tsx');
    const nursing = read('src/screens/nursing/NursingDashboard.tsx');
    expect(shared).toContain("bank?.review_status === 'approved'");
    expect(shared).toContain('idempotency_key: requestKey');
    expect(shared).toContain('payout_request_reference_missing');
    expect(shared).toContain('This is not a completed transfer.');
    expect(nursing).toContain('idempotency_key: `nursing_payout_');
    expect(nursing).toContain('payout_request_reference_missing');
  });

  it('uses the canonical home-care visit queue and response contract for nursing intake', () => {
    const nursing = read('src/screens/nursing/NursingDashboard.tsx');
    expect(nursing).toContain("client.get('/home-care/visits')");
    expect(nursing).toContain('`/home-care/visits/${order.id}/respond`');
    expect(nursing).not.toContain("'/nursing/jobs/active'");
    expect(nursing).not.toContain('`/home-care/bookings/${order.id}/respond`');
  });

  it('binds ambulance claims and tracking to a selected verified vehicle', () => {
    const ambulance = read('src/screens/ambulance/AmbulanceDashboard.tsx');
    expect(ambulance).toContain("client.post(`/emergency/${id}/claim`, { vehicle_id: selectedVehicleId })");
    expect(ambulance).toContain('selectedVehicleId');
    expect(ambulance).toContain('vehicle_id: vehicleId');
    expect(ambulance).toContain('No approved available ambulance vehicle exists.');
  });

  it('uses server-backed availability rather than a locally online provider or pharmacy', () => {
    expect(authContext).toContain('isOnline: false');
    expect(pharmacyDashboard).toContain('const { user, toggleOnline } = useAuth();');
    expect(pharmacyDashboard).not.toContain('const [isOnline, setIsOnline] = useState(true);');
  });

  it('does not mark cash collection or begin a consultation in the doctor UI without a server mutation', () => {
    expect(dashboard).not.toContain('Payment locked. Starting consultation.');
    expect(dashboard).not.toContain('تم قفل حالة الدفع وبدء الاستشارة');
    expect(dashboard).toContain('setError(true);');
  });

  it('isolates native maps behind a web-safe component', () => {
    expect(registrations).not.toContain("from 'react-native-maps'");
    expect(registrations).toContain('PlatformMap');
    expect(platformMapWeb).toContain('Interactive map is available in the native app.');
  });

  it('does not seed provider registration with commercial or geographic values', () => {
    expect(registrations).not.toMatch(/clinicPrice:'300'|homePrice:'500'|videoPrice:'200'/);
    expect(registrations).not.toMatch(/priceVisit: '150'|priceHour: '80'|priceDay: '800'|priceMonth: '8000'/);
    expect(registrations).not.toContain('lat: 24.7136');
    expect(registrations).not.toContain('lng: 46.6753');
    expect(registrations).not.toContain("cashOnly: true");
  });

  it('keeps all six provider locales key-complete and applies RTL only to Arabic', () => {
    const constants = read('src/constants/index.ts');
    const sharedLocales = read('src/i18n/sharedLocales.ts');
    const extractKeys = (source, startPattern, endPattern) => {
      const start = source.indexOf(startPattern);
      const end = source.indexOf(endPattern, start);
      expect(start).toBeGreaterThanOrEqual(0);
      expect(end).toBeGreaterThan(start);
      return new Set([...source.slice(start + startPattern.length, end).matchAll(/\b(\w+)\s*:/g)].map(([, key]) => key));
    };
    const arabicKeys = extractKeys(constants, 'ar: {', '\n en: {');

    expect(constants).toContain("export type Lang = 'ar' | 'en' | 'ur' | 'hi' | 'bn' | 'fil';");
    expect(constants).toContain('...providerSharedLocales');
    expect(arabicKeys.size).toBeGreaterThan(90);
    for (const locale of ['ur', 'hi', 'bn', 'fil']) {
      const localeKeys = extractKeys(sharedLocales, `  ${locale}: {`, '\n  },');
      expect(localeKeys).toEqual(arabicKeys);
    }

    expect(authContext).toContain("const SUPPORTED_LANGUAGES: readonly Lang[] = ['ar', 'en', 'ur', 'hi', 'bn', 'fil'];");
    expect(authContext).toContain("I18nManager.forceRTL(l === 'ar')");
    expect(authContext).toContain("I18nManager.forceRTL(saved === 'ar')");
    expect(authContext).toContain("isRTL: lang === 'ar'");
    expect(authContext).toContain('set(SUPPORTED_LANGUAGES[(currentIndex + 1) % SUPPORTED_LANGUAGES.length]);');
  });
});
