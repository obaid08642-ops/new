const fs = require('node:fs');
const path = require('node:path');

describe('Provider App release contracts', () => {
  const root = process.cwd();
  const dashboard = fs.readFileSync(path.join(root, 'src/screens/doctor/DoctorDashboard.tsx'), 'utf8');
  const pharmacyDashboard = fs.readFileSync(path.join(root, 'src/screens/pharmacy/PharmacyDashboard.tsx'), 'utf8');
  const radiologyDashboard = fs.readFileSync(path.join(root, 'src/screens/radiology/RadiologyDashboard.tsx'), 'utf8');
  const authContext = fs.readFileSync(path.join(root, 'src/context/index.tsx'), 'utf8');
  const platformMapWeb = fs.readFileSync(path.join(root, 'src/components/PlatformMap.web.tsx'), 'utf8');
  const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
  const registrations = [
    'doctor/DoctorRegistration.tsx',
    'pharmacy/PharmacyRegistration.tsx',
    'lab/LabRegistration.tsx',
    'radiology/RadiologyRegistration.tsx',
    'nursing/NursingRegistration.tsx',
  ].map(file => fs.readFileSync(path.join(root, 'src/screens', file), 'utf8')).join('\n');
  const config = JSON.parse(fs.readFileSync(path.join(root, 'app.json'), 'utf8')).expo;

  it('has explicit production API and native platform identifiers', () => {
    expect(config.extra.apiBaseUrl).toBe('https://api.nabd.plus/api/v1');
    expect(config.android.package).toBe('com.nabd.plus.provider');
    expect(config.ios.bundleIdentifier).toBe('com.nabd.plus.provider');
    expect(config.userInterfaceStyle).toBe('automatic');
  });

  it('does not ship an insecure runtime API override or legacy endpoint domain', () => {
    const constants = read('src/constants/index.ts');
    const client = read('src/api/client.ts');
    const auth = read('src/context/index.tsx');
    const login = read('src/screens/auth/AuthScreens.tsx');
    const httpClient = read('src/services/HttpClient.ts');
    expect(constants).toContain("const PRODUCTION_API_BASE = 'https://api.nabd.plus/api/v1'");
    expect(constants).toContain('Unsafe provider API configuration');
    expect(constants).not.toContain('LOCAL_DEV_API');
    expect(constants).not.toContain('10.0.2.2');
    expect(client).not.toContain('CUSTOM_API_IP');
    expect(auth).not.toContain('CUSTOM_API_IP');
    expect(login).not.toContain('Override API IP');
    expect(httpClient).toContain('baseURL: API_BASE');
    for (const source of [constants, client, auth, login, httpClient]) expect(source).not.toMatch(/nabdahplus\.(sa|com)/);
  });

  it('routes pending, rejected and suspended provider states away from operational dashboards', () => {
    const app = read('App.tsx');
    const context = read('src/context/index.tsx');
    const pending = read('src/screens/auth/PendingDashboard.tsx');
    expect(context).toContain("if (normalized === 'approved' || normalized === 'active')");
    expect(context).toContain("setAppState('pending')");
    expect(app).toContain("appState === 'pending' || appState === 'rejected' || appState === 'suspended'");
    expect(pending).toContain('Refresh review status');
    expect(pending).not.toContain("label={AR ? 'استكشاف التطبيق' : 'Explore App'}");
  });

  it('does not fabricate patient identity or financial values in intake mapping', () => {
    expect(dashboard).not.toContain('test_patient');
    expect(dashboard).not.toContain("national_id || '1029384756'");
    expect(dashboard).not.toContain("dob || '1980-05-12'");
    expect(dashboard).not.toMatch(/price\s*:\s*x\.total\s*\|\|\s*150/);
    expect(dashboard).toContain('const patientId = apt?.patient_id');
  });

  it('contains real provider intake actions and refreshes after mutations', () => {
    expect(dashboard).toContain('/provider/jobs/queue?status=incoming&kind=consultation');
    expect(dashboard).toContain('/provider/jobs/');
    expect(dashboard).toContain('/provider/stats/today');
    expect(dashboard).toContain('fetchQueue();');
  });

  it('does not ship fake pharmacy/radiology terminal actions', () => {
    expect(pharmacyDashboard).not.toContain('Simulate Drug Scan');
    expect(pharmacyDashboard).not.toContain('طلب وصفة #B-9901');
    expect(pharmacyDashboard).toContain("client.get('/provider/pharmacy/broadcasts')");
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${orderId}/i-have-all');
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${rejectOrderId}/reject');
    expect(pharmacyDashboard).not.toContain('/pharmacy/orders/${rejectOrderId}/reject');
    expect(pharmacyDashboard).toContain("client.get('/provider/pharmacy/allocations', { params: { status: 'completed' } })");
    expect(radiologyDashboard).not.toContain('Coming with S3 integration');
    expect(radiologyDashboard).not.toContain("'https://storage.nabdah.com/reports/' + order.id + '.pdf'");
    expect(radiologyDashboard).toContain('HTTPS URL for the signed PDF report');
  });

  it('uses the broadcast allocation contract for pharmacy acceptance and rejection', () => {
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${orderId}/i-have-all');
    expect(pharmacyDashboard).toContain('/provider/pharmacy/broadcasts/${rejectOrderId}/reject');
    expect(pharmacyDashboard).not.toContain('/provider/pharmacy/orders/${orderId}/accept');
    expect(pharmacyDashboard).toContain('res.data?.allocation?.id');
    expect(pharmacyDashboard).toContain('No local order state changed.');
  });

  it('uses supported lab sample/report contracts without placeholder clinical output', () => {
    const labDashboard = read('src/screens/lab/LabDashboard.tsx');
    expect(labDashboard).toContain("client.post('/labs/samples/register'");
    expect(labDashboard).toContain("stage: 'result_ready'");
    expect(labDashboard).toContain('verified_result_data_required');
    expect(labDashboard).toContain('sample_rejection_requires_verified_qc_workflow');
    expect(labDashboard).not.toContain("{ file: 'lab_report_signature.pdf' }");
    expect(labDashboard).not.toContain("stage: 'result_uploaded'");
    expect(labDashboard).not.toContain("stage: 'sample_rejected'");
    expect(labDashboard).not.toContain("value:'7.2'");
  });

  it('uses a verified bank and server payout reference before presenting a withdrawal request', () => {
    const shared = read('src/screens/shared/SharedScreens.tsx');
    const nursing = read('src/screens/nursing/NursingDashboard.tsx');
    expect(shared).toContain("bank?.review_status === 'approved'");
    expect(shared).toContain('idempotency_key: requestKey');
    expect(shared).toContain('payout_request_reference_missing');
    expect(shared).toContain('This is not a completed transfer.');
    expect(nursing).toContain('idempotency_key: `nursing_payout_');
    expect(nursing).toContain('payout_request_reference_missing');
  });

  it('uses the canonical home-care visit queue and response contract for nursing intake', () => {
    const nursing = read('src/screens/nursing/NursingDashboard.tsx');
    expect(nursing).toContain("client.get('/home-care/visits')");
    expect(nursing).toContain('`/home-care/visits/${order.id}/respond`');
    expect(nursing).not.toContain("'/nursing/jobs/active'");
    expect(nursing).not.toContain('`/home-care/bookings/${order.id}/respond`');
  });

  it('uses server-backed availability rather than a locally online provider or pharmacy', () => {
    expect(authContext).toContain('isOnline: false');
    expect(pharmacyDashboard).toContain('const { user, toggleOnline } = useAuth();');
    expect(pharmacyDashboard).not.toContain('const [isOnline, setIsOnline] = useState(true);');
  });

  it('does not mark cash collection or begin a consultation in the doctor UI without a server mutation', () => {
    expect(dashboard).not.toContain('Payment locked. Starting consultation.');
    expect(dashboard).not.toContain('تم قفل حالة الدفع وبدء الاستشارة');
    expect(dashboard).toContain('setError(true);');
  });

  it('isolates native maps behind a web-safe component', () => {
    expect(registrations).not.toContain("from 'react-native-maps'");
    expect(registrations).toContain('PlatformMap');
    expect(platformMapWeb).toContain('Interactive map is available in the native app.');
  });

  it('does not seed provider registration with commercial or geographic values', () => {
    expect(registrations).not.toMatch(/clinicPrice:'300'|homePrice:'500'|videoPrice:'200'/);
    expect(registrations).not.toMatch(/priceVisit: '150'|priceHour: '80'|priceDay: '800'|priceMonth: '8000'/);
    expect(registrations).not.toContain('lat: 24.7136');
    expect(registrations).not.toContain('lng: 46.6753');
    expect(registrations).not.toContain("cashOnly: true");
  });
});
