import { registerRootComponent } from 'expo';
import App from './App';

// M0-09: explicit entry point — replaces the legacy node_modules/expo/AppEntry.js
// reference which breaks with modern Expo SDK / monorepo layouts.
registerRootComponent(App);
