import { setupPushNotifications } from "./src/utils/PushNotifications";
/**
 * NABDAH PLUS — App.tsx
 * Phase 0-5: Doctor + Facility + Pharmacy + Lab/Radiology + Nursing
 */
import React, { useState, useCallback, useEffect } from 'react';
import { LogBox } from 'react-native';

LogBox.ignoreLogs([
  'expo-notifications: Android Push notifications',
  '`expo-notifications` functionality is not fully supported in Expo Go',
  'Expo AV has been deprecated'
]);
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { RootProvider, useAuth, useTheme } from './src/context';
import { SplashScreen, WelcomeScreen, LoginScreen, ForgotPasswordScreen } from './src/screens/auth/AuthScreens';
import { PendingDashboard } from './src/screens/auth/PendingDashboard';

// ── Lazy screen loader (Expo Go hardening) ──────────────────────────────────
// Previously every dashboard/registration screen was imported eagerly here, so
// ONE module touching an unavailable native API at import time (e.g. expo-av /
// expo-camera / maps in Expo Go) aborted the whole bundle evaluation and the
// app died with "main has not been registered". Now each screen module is
// require()d on first render; a failing screen shows an isolated error instead
// of killing the app.
import { View, Text, TouchableOpacity } from 'react-native';

// NOTE: Metro requires literal string paths in require() — each loader below
// carries its own literal so bundling works; the module factory only executes
// when the screen is first rendered (deferred evaluation), not at app boot.
function lazyScreen(loader: () => any, label: string) {
  let cached: any = undefined;
  return function LazyScreen(props: any) {
    if (cached === undefined) {
      try { cached = loader(); }
      catch (e: any) { console.error(`[LazyScreen] Failed to load ${label}:`, e?.message || e); cached = null; }
    }
    const C = cached;
    if (!C) {
      return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: '#F8FAFC' }}>
          <Text style={{ fontSize: 16, fontWeight: '700', color: '#0F172A', textAlign: 'center' }}>تعذر تحميل هذه الشاشة</Text>
          <Text style={{ fontSize: 13, color: '#64748B', textAlign: 'center', marginTop: 8 }}>
            بعض الميزات الأصلية (كاميرا/خرائط/صوت) تحتاج نسخة Development Build ولا تعمل داخل Expo Go.
          </Text>
        </View>
      );
    }
    return <C {...props} />;
  };
}

const DoctorRegistration          = lazyScreen(() => require('./src/screens/doctor/DoctorRegistration').DoctorRegistration, 'DoctorRegistration');
const DoctorDashboardNavigator    = lazyScreen(() => require('./src/screens/doctor/DoctorDashboard').DoctorDashboardNavigator, 'DoctorDashboard');
const FacilityRegistration        = lazyScreen(() => require('./src/screens/facility/FacilityRegistration').FacilityRegistration, 'FacilityRegistration');
const FacilityDashboardNavigator  = lazyScreen(() => require('./src/screens/facility/FacilityDashboard').FacilityDashboardNavigator, 'FacilityDashboard');
const PharmacyRegistration        = lazyScreen(() => require('./src/screens/pharmacy/PharmacyRegistration').PharmacyRegistration, 'PharmacyRegistration');
const PharmacyDashboardNavigator  = lazyScreen(() => require('./src/screens/pharmacy/PharmacyDashboard').PharmacyDashboardNavigator, 'PharmacyDashboard');
const LabRegistration             = lazyScreen(() => require('./src/screens/lab/LabRegistration').LabRegistration, 'LabRegistration');
const LabDashboardNavigator       = lazyScreen(() => require('./src/screens/lab/LabDashboard').LabDashboardNavigator, 'LabDashboard');
const RadiologyRegistration       = lazyScreen(() => require('./src/screens/radiology/RadiologyRegistration').RadiologyRegistration, 'RadiologyRegistration');
const RadiologyDashboardNavigator = lazyScreen(() => require('./src/screens/radiology/RadiologyDashboard').RadiologyDashboardNavigator, 'RadiologyDashboard');
const NursingRegistration         = lazyScreen(() => require('./src/screens/nursing/NursingRegistration').NursingRegistration, 'NursingRegistration');
const AmbulanceRegistration       = lazyScreen(() => require('./src/screens/ambulance/AmbulanceRegistration').AmbulanceRegistration, 'AmbulanceRegistration');
const NursingDashboardNavigator   = lazyScreen(() => require('./src/screens/nursing/NursingDashboard').NursingDashboardNavigator, 'NursingDashboard');
const AmbulanceDashboardNavigator = lazyScreen(() => require('./src/screens/ambulance/AmbulanceDashboard').AmbulanceDashboardNavigator, 'AmbulanceDashboard');
const MedicalJobsScreen           = lazyScreen(() => require('./src/screens/shared/SharedScreens').MedicalJobsScreen, 'MedicalJobsScreen');
const MedicalDrugIndexScreen      = lazyScreen(() => require('./src/screens/shared/SharedScreens').MedicalDrugIndexScreen, 'MedicalDrugIndexScreen');

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

function AppNavigator() {
  const { isLoggedIn, user, logout, appState } = useAuth();
  const { theme } = useTheme();
  const [pType, setPType]   = useState('doctor');

  if (appState === 'checking') {
    return <SplashScreen onDone={() => {}} />;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator id={undefined as any} screenOptions={{ headerShown: false, contentStyle: { backgroundColor: theme.bg } }}>
        {appState === 'logged_in' ? (
          <Stack.Screen name="Dashboard">
            {(props) => {
              const t = (user?.providerType ?? pType).toLowerCase();
              const doLogout = async () => { await logout(); };
              if (t === 'doctor')   return <DoctorDashboardNavigator   onLogout={doLogout} />;
              if (t === 'facility' || t === 'hospital') return <FacilityDashboardNavigator onLogout={doLogout} />;
              if (t === 'pharmacy' || t === 'pharmacist') return <PharmacyDashboardNavigator onLogout={doLogout} />;
              if (t === 'lab') return <LabDashboardNavigator onLogout={doLogout} />;
              if (t === 'radiology') return <RadiologyDashboardNavigator onLogout={doLogout} />;
              if (t === 'nursing' || t === 'nurse' || t === 'home_care')  return <NursingDashboardNavigator  onLogout={doLogout} />;
              if (t === 'ambulance' || t === 'emergency' || t === 'driver' || t === 'delivery') return <AmbulanceDashboardNavigator onLogout={doLogout} />;
              return <PendingDashboard providerType={t} onExplore={() => {}} onLogout={doLogout} />;
            }}
          </Stack.Screen>
        ) : (
          <>
            <Stack.Screen name="Welcome">
              {({ navigation }) => <WelcomeScreen onSelectType={t => { setPType(t); navigation.navigate('Register'); }} onLogin={() => navigation.navigate('Login')} onGuestJobs={() => navigation.navigate('GuestJobs')} onGuestDrugIndex={() => navigation.navigate('GuestDrugIndex')} />}
            </Stack.Screen>
            <Stack.Screen name="Login">
              {({ navigation }) => <LoginScreen onSuccess={() => {}} onBack={() => navigation.goBack()} onForgot={() => navigation.navigate('Forgot')} onRegister={() => navigation.navigate('Welcome')} />}
            </Stack.Screen>
            <Stack.Screen name="Forgot">
              {({ navigation }) => <ForgotPasswordScreen onBack={() => navigation.goBack()} onSuccess={() => navigation.goBack()} />}
            </Stack.Screen>
            <Stack.Screen name="Register">
              {({ navigation }) => {
                if (pType === 'doctor')   return <DoctorRegistration   onBack={() => navigation.goBack()} onDone={() => navigation.navigate('Pending')} />;
                if (pType === 'facility') return <FacilityRegistration onBack={() => navigation.goBack()} onDone={() => navigation.navigate('Pending')} />;
                if (pType === 'pharmacy') return <PharmacyRegistration onBack={() => navigation.goBack()} onDone={() => navigation.navigate('Pending')} />;
                if (pType === 'lab') return <LabRegistration providerType={pType} onBack={() => navigation.goBack()} onDone={() => navigation.navigate('Pending')} />;
                if (pType === 'radiology') return <RadiologyRegistration onBack={() => navigation.goBack()} onDone={() => navigation.navigate('Pending')} />;
                if (pType === 'nursing')  return <NursingRegistration  onBack={() => navigation.goBack()} onDone={() => navigation.navigate('Pending')} />;
                if (pType === 'ambulance') return <AmbulanceRegistration onBack={() => navigation.goBack()} onDone={() => navigation.navigate('Pending')} />;
                return <PendingDashboard providerType={pType} onExplore={() => {}} onLogout={() => navigation.goBack()} />;
              }}
            </Stack.Screen>
            <Stack.Screen name="Pending">
              {({ navigation }) => <PendingDashboard providerType={pType} onExplore={() => {}} onLogout={() => navigation.navigate('Welcome')} />}
            </Stack.Screen>
            <Stack.Screen name="GuestJobs">
              {({ navigation }) => <MedicalJobsScreen onBack={() => navigation.goBack()} />}
            </Stack.Screen>
            <Stack.Screen name="GuestDrugIndex">
              {({ navigation }) => <MedicalDrugIndexScreen onBack={() => navigation.goBack()} />}
            </Stack.Screen>
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}


class AppErrorBoundary extends React.Component<{ children: React.ReactNode }, { error: string | null }> {
  state = { error: null as string | null };
  static getDerivedStateFromError(e: any) { return { error: String(e?.message || e) }; }
  componentDidCatch(e: any) { try { console.error('AppErrorBoundary', e); } catch {} }
  render() {
    if (this.state.error) {
      const { View, Text, ScrollView } = require('react-native');
      return (
        <View style={{ flex: 1, backgroundColor: '#0F172A', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <Text style={{ color: '#FFF', fontSize: 20, fontWeight: '800', marginBottom: 10 }}>Nabd Provider</Text>
          <Text style={{ color: '#FCA5A5', fontSize: 13, textAlign: 'center' }}>حدث خطأ أثناء التحميل: {this.state.error}</Text>
          <Text style={{ color: '#94A3B8', fontSize: 12, marginTop: 12, textAlign: 'center' }}>أعد تشغيل التطبيق، وإن استمر الخطأ أرسل لنا هذه الرسالة.</Text>
        </View>
      );
    }
    return this.props.children as any;
  }
}

export default function App() {
  React.useEffect(() => {
    setupPushNotifications().catch(() => { /* push unavailable (Expo Go) — non-critical */ });
  }, []);
  return (
    <AppErrorBoundary>
      <SafeAreaProvider>
        <RootProvider>
          <AppNavigator />
        </RootProvider>
      </SafeAreaProvider>
    </AppErrorBoundary>
  );
}
