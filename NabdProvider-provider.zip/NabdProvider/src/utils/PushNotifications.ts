// @ts-nocheck
// expo-notifications touches native modules at import time — guarded so the app
// still boots in Expo Go (SDK 53+ removed remote push there).
let Notifications: any = null;
try {
  Notifications = require('expo-notifications');
} catch {
  Notifications = null;
}
import * as Device from 'expo-device';
import { Platform } from 'react-native';

if (Notifications) {
  try {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
        shouldShowBanner: true,
      }),
    });
  } catch { /* native module not ready — skip handler */ }
}

export async function setupPushNotifications(): Promise<void> {
  if (!Notifications) return; // Expo Go / native module missing — skip silently
  if (!Device.isDevice) return; // Simulator — skip silently

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') return;

  try {
    await Notifications.getExpoPushTokenAsync({
      projectId: process.env.EXPO_PUBLIC_PROJECT_ID || 'dummy-project-id'
    });
    // Token obtained — backend registration handled by notifications.ts
  } catch (e) {
    // Push token unavailable (Expo Go limitation / simulator) — silently skip
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'Default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#4F46E5',
    });
  }
}
