// Jest setup for NabdProvider — mocks for native modules not available in jsdom.
jest.mock('react-native/src/private/animated/NativeAnimatedHelper');

jest.mock('expo-av', () => ({
  Audio: {
    Recording: { createAsync: jest.fn() },
    Sound: { createAsync: jest.fn() },
    setAudioModeAsync: jest.fn(),
    requestPermissionsAsync: jest.fn(async () => ({ granted: true })),
  },
}));

jest.mock('react-native-webview', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    WebView: (props) => React.createElement(View, props),
    default: (props) => React.createElement(View, props),
  };
});

jest.mock('@livekit/react-native', () => ({
  registerGlobals: jest.fn(),
  VideoView: () => null,
  AudioSession: {
    startAudioSession: jest.fn(async () => {}),
    stopAudioSession: jest.fn(async () => {}),
    configureAudio: jest.fn(async () => {}),
  },
  useTracks: () => [],
  useRoomContext: () => null,
}));

jest.mock('livekit-client', () => ({
  Room: jest.fn().mockImplementation(() => ({
    on: jest.fn(),
    connect: jest.fn(async () => {}),
    disconnect: jest.fn(),
    localParticipant: {
      setMicrophoneEnabled: jest.fn(async () => {}),
      setCameraEnabled: jest.fn(async () => {}),
      enableCameraAndMicrophone: jest.fn(async () => {}),
    },
  })),
  RoomEvent: { TrackSubscribed: 'trackSubscribed', TrackUnsubscribed: 'trackUnsubscribed', LocalTrackPublished: 'localTrackPublished', Disconnected: 'disconnected' },
  VideoPresets: {
    h180: { resolution: { width: 320, height: 180 } },
    h360: { resolution: { width: 640, height: 360 } },
    h720: { resolution: { width: 1280, height: 720 } },
  },
  AudioPresets: { speech: { maxBitrate: 24000 }, music: { maxBitrate: 64000 } },
  Track: { Kind: { Video: 'video', Audio: 'audio' } },
}));

jest.mock('expo-document-picker', () => ({
  getDocumentAsync: jest.fn(async () => ({ canceled: true })),
}));

jest.mock('expo-image-picker', () => ({
  requestMediaLibraryPermissionsAsync: jest.fn(async () => ({ granted: true })),
  launchImageLibraryAsync: jest.fn(async () => ({ canceled: true })),
}));

jest.mock('expo-file-system/legacy', () => ({
  readAsStringAsync: jest.fn(async () => ''),
}));

jest.mock('socket.io-client', () => ({
  io: jest.fn(() => ({ on: jest.fn(), emit: jest.fn(), disconnect: jest.fn(), connect: jest.fn() })),
}));
