/**
 * Clinical workflows — RequestTestScreen (doctor issues lab referral).
 * Verifies the REAL API contract: POST /provider/doctor-referrals/issue-referrals-and-prescription
 * with { patientId, doctorId, labTests } — no fake-success paths.
 */
import React from 'react';
import renderer, { act } from 'react-test-renderer';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// ── Context mocks ────────────────────────────────────────────────────────────
const mockShow = jest.fn();
jest.mock('../src/context', () => ({
  useTheme: () => ({ theme: require('../src/constants').LIGHT, mode: 'light' }),
  useLang: () => ({ lang: 'ar' }),
  useAuth: () => ({ user: { id: 'doc_1', role: 'doctor' } }),
  useToast: () => ({ show: mockShow }),
}));

// ── API client mock ──────────────────────────────────────────────────────────
const mockPost = jest.fn(async (..._a: any[]) => ({ data: { ok: true } }));
const mockGet = jest.fn(async (..._a: any[]) => ({ data: {} }));
jest.mock('../src/api/client', () => ({
  __esModule: true,
  default: { post: (...a: any[]) => mockPost(...a), get: (...a: any[]) => mockGet(...a) },
}));

import { RequestTestScreen } from '../src/screens/doctor/DoctorDashboard';

const initialMetrics = {
  frame: { x: 0, y: 0, width: 390, height: 844 },
  insets: { top: 0, left: 0, right: 0, bottom: 0 },
};

function renderScreen(apt: any) {
  let tree: renderer.ReactTestRenderer;
  act(() => {
    tree = renderer.create(
      <SafeAreaProvider initialMetrics={initialMetrics}>
        <RequestTestScreen apt={apt} onBack={() => {}} />
      </SafeAreaProvider>
    );
  });
  return tree!;
}

function findByText(root: renderer.ReactTestInstance, pred: (t: string) => boolean) {
  return root.findAll((n) => {
    if (typeof n.children?.[0] === 'string') return pred(n.children[0] as string);
    const joined = n.children.filter((c) => typeof c === 'string').join('');
    return joined.length > 0 && pred(joined);
  });
}

describe('RequestTestScreen — lab referral contract', () => {
  beforeEach(() => {
    mockPost.mockClear();
    mockGet.mockClear();
    mockShow.mockClear();
  });

  it('posts the referral with patientId, doctorId and selected lab tests', async () => {
    const apt = { id: 'apt_1', patient_id: 'pat_1', patient: 'محمد', initialType: 'lab' };
    const tree = renderScreen(apt);

    // Select the first lab test (CBC — first entry in LAB_TESTS)
    const root = tree.root;
    const cbcNodes = findByText(root, (t) => t.includes('صورة دم') || t.toLowerCase().includes('cbc'));
    expect(cbcNodes.length).toBeGreaterThan(0);

    // walk up to the touchable card and press it
    let node: renderer.ReactTestInstance | null = cbcNodes[0];
    while (node && !(node.props && typeof node.props.onPress === 'function')) node = node.parent;
    expect(node).toBeTruthy();
    await act(async () => { node!.props.onPress(); });

    // press the send button
    const sendNodes = findByText(root, (t) => t.includes('إرسال الطلب'));
    expect(sendNodes.length).toBeGreaterThan(0);
    let sendBtn: renderer.ReactTestInstance | null = sendNodes[0];
    while (sendBtn && !(sendBtn.props && typeof sendBtn.props.onPress === 'function')) sendBtn = sendBtn.parent;
    expect(sendBtn).toBeTruthy();
    await act(async () => { await sendBtn!.props.onPress(); });

    expect(mockPost).toHaveBeenCalledTimes(1);
    const [url, payload] = mockPost.mock.calls[0] as unknown as [string, any];
    expect(url).toBe('/provider/doctor-referrals/issue-referrals-and-prescription');
    expect(payload.patientId).toBe('pat_1');
    expect(payload.doctorId).toBe('doc_1');
    expect(Array.isArray(payload.labTests)).toBe(true);
    expect(payload.labTests.length).toBe(1);
    expect(payload.radScans).toEqual([]);
  });

  it('blocks sending when no test is selected', async () => {
    const apt = { id: 'apt_1', patient_id: 'pat_1', patient: 'محمد', initialType: 'lab' };
    const tree = renderScreen(apt);
    const root = tree.root;
    const sendNodes = findByText(root, (t) => t.includes('إرسال الطلب'));
    let sendBtn: renderer.ReactTestInstance | null = sendNodes[0];
    while (sendBtn && !(sendBtn.props && typeof sendBtn.props.onPress === 'function')) sendBtn = sendBtn.parent;
    await act(async () => { await sendBtn!.props.onPress(); });
    // guard blocks the request and surfaces an honest error
    expect(mockPost).not.toHaveBeenCalled();
    expect(mockShow).toHaveBeenCalledWith(expect.stringContaining('اختر'), 'error');
  });

  it('shows an honest error when the referral POST fails', async () => {
    mockPost.mockRejectedValueOnce({ response: { data: { message: 'server_error' } }, message: 'server_error' });
    const apt = { id: 'apt_1', patient_id: 'pat_1', patient: 'محمد', initialType: 'lab' };
    const tree = renderScreen(apt);
    const root = tree.root;

    const cbcNodes = findByText(root, (t) => t.includes('صورة دم') || t.toLowerCase().includes('cbc'));
    let node: renderer.ReactTestInstance | null = cbcNodes[0];
    while (node && !(node.props && typeof node.props.onPress === 'function')) node = node.parent;
    await act(async () => { node!.props.onPress(); });

    const sendNodes = findByText(root, (t) => t.includes('إرسال الطلب'));
    let sendBtn: renderer.ReactTestInstance | null = sendNodes[0];
    while (sendBtn && !(sendBtn.props && typeof sendBtn.props.onPress === 'function')) sendBtn = sendBtn.parent;
    await act(async () => { await sendBtn!.props.onPress(); });

    expect(mockPost).toHaveBeenCalledTimes(1);
    expect(mockShow).toHaveBeenCalledWith('server_error', 'error');
  });
});
