import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, TextInput, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as LegacyFS from 'expo-file-system/legacy';
import client from '../../api/client';
import { sendEmailOtp, verifyEmailOtp } from '../../api/otp';
import { useTheme, useLang, useToast } from '../../context';
import { translateProviderPair, translateProviderTemplate } from '../../i18n/providerTextTranslations';

export function RegistrationSuccess({ onDone, email, providerType = 'provider' }: { onDone: () => void; email?: string; providerType?: string }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const { show } = useToast();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
  
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [verified, setVerified] = useState(false);
  const [contractLoading, setContractLoading] = useState(false);

  const handleSendOtp = async () => {
    if (!email) { show(tr('لا يوجد بريد إلكتروني مسجل', 'No email on file'), 'error'); return; }
    setLoading(true);
    try {
      await sendEmailOtp(email);
      setOtpSent(true);
      show(tr('تم إرسال رمز التحقق إلى بريدك الإلكتروني', 'Verification code sent to email'), 'success');
    } catch {
      show(tr('تعذر إرسال الرمز — حاول بعد قليل', 'Could not send code — try again shortly'), 'error');
    } finally { setLoading(false); }
  };

  const handleVerify = async () => {
    if (!otp || otp.length < 6) {
      show(tr('الرمز غير صحيح', 'Invalid code'), 'error');
      return;
    }
    setLoading(true);
    try {
      const ok = await verifyEmailOtp(email || '', otp);
      if (ok) {
        setVerified(true);
        show(tr('تم تأكيد البريد الإلكتروني بنجاح', 'Email verified successfully'), 'success');
      } else {
        show(tr('الرمز غير صحيح أو منتهي', 'Code is incorrect or expired'), 'error');
      }
    } catch {
      show(tr('تعذر التحقق — حاول مجدداً', 'Verification failed — try again'), 'error');
    } finally { setLoading(false); }
  };

  /** Download the signed partnership contract PDF (only when admin granted visibility). */
  const downloadContract = async () => {
    setContractLoading(true);
    try {
      const res = await client.get('/provider-onboarding/contract');
      const b64 = res.data?.pdf_base64;
      if (!b64) throw new Error('empty');
      const name = `nabd-contract-${Date.now()}.pdf`;
      if (Platform.OS === 'android') {
        const perm = await LegacyFS.StorageAccessFramework.requestDirectoryPermissionsAsync();
        if (!perm.granted) throw new Error('no_perm');
        const uri = await LegacyFS.StorageAccessFramework.createFileAsync(perm.directoryUri, name.replace('.pdf', ''), 'application/pdf');
        await LegacyFS.writeAsStringAsync(uri, b64, { encoding: LegacyFS.EncodingType.Base64 });
      } else {
        await LegacyFS.writeAsStringAsync(LegacyFS.documentDirectory + name, b64, { encoding: LegacyFS.EncodingType.Base64 });
      }
      show(tr('تم حفظ العقد بنجاح', 'Contract saved successfully'), 'success');
    } catch (e: any) {
      const st = e?.response?.status;
      if (st === 403) show(tr('العقد غير متاح بعد — يمكن للإدارة إتاحته لك من لوحة المراجعة', 'Contract not shared yet — admin can enable it from the review panel'), 'error');
      else show(tr('تعذر تحميل العقد', 'Could not download the contract'), 'error');
    } finally { setContractLoading(false); }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 24 }}>
        
        <View style={{ width: 80, height: 80, borderRadius: 40, backgroundColor: theme.primary + '20', justifyContent: 'center', alignItems: 'center', marginBottom: 24 }}>
          <Ionicons name={verified ? "checkmark-circle" : "mail-unread"} size={48} color={theme.primary} />
        </View>

        <Text style={{ fontSize: 24, fontWeight: '700', color: theme.text, marginBottom: 12, textAlign: 'center' }}>
          {tr('تم إرسال طلبك بنجاح!', 'Application Submitted!')}
        </Text>
        
        <Text style={{ fontSize: 16, color: theme.textSub, textAlign: 'center', marginBottom: 32, lineHeight: 24 }}>
          {tr('طلبك قيد المراجعة حالياً من قبل الإدارة. سيتم إشعارك فور الموافقة.', 'Your application is under review by admin. You will be notified upon approval.')}
        </Text>

        {!verified ? (
          <View style={{ width: '100%', backgroundColor: theme.card, padding: 20, borderRadius: 16, borderWidth: 1, borderColor: theme.border, marginBottom: 24 }}>
            <Text style={{ fontSize: 16, fontWeight: '600', color: theme.text, marginBottom: 8 }}>
              {tr('تأكيد البريد الإلكتروني', 'Verify Email Address')}
            </Text>
            <Text style={{ fontSize: 14, color: theme.textSub, marginBottom: 16 }}>
              {email ? (trT("يرجى تأكيد بريدك الإلكتروني: {0}", "Please verify your email: {0}", [email])) : (tr('يرجى تأكيد بريدك الإلكتروني لضمان التواصل.', 'Please verify your email for communication.'))}
            </Text>

            {!otpSent ? (
              <TouchableOpacity 
                onPress={handleSendOtp}
                disabled={loading}
                style={{ backgroundColor: theme.primary, padding: 14, borderRadius: 12, alignItems: 'center', flexDirection: 'row', justifyContent: 'center' }}>
                {loading ? <ActivityIndicator color="#fff" /> : (
                  <>
                    <Ionicons name="send" size={20} color="#fff" style={{ marginRight: 8 }} />
                    <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600' }}>
                      {tr('إرسال رمز التفعيل', 'Send Verification Code')}
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            ) : (
              <View>
                <TextInput
                  value={otp}
                  onChangeText={(v) => setOtp(v.replace(/\D/g, '').slice(0, 6))}
                  placeholder={tr('أدخل الرمز المكون من 6 أرقام', 'Enter 6-digit code')}
                  keyboardType="number-pad"
                  maxLength={6}
                  autoComplete={Platform.OS === 'android' ? 'sms-otp' : 'one-time-code'}
                  textContentType="oneTimeCode"
                  importantForAutofill="yes"
                  style={{ backgroundColor: theme.bg, borderWidth: 1, borderColor: theme.border, borderRadius: 12, padding: 14, fontSize: 18, textAlign: 'center', letterSpacing: 4, marginBottom: 16, color: theme.text, writingDirection: 'ltr' }}
                />
                <TouchableOpacity 
                  onPress={handleVerify}
                  disabled={loading}
                  style={{ backgroundColor: theme.primary, padding: 14, borderRadius: 12, alignItems: 'center' }}>
                  {loading ? <ActivityIndicator color="#fff" /> : (
                    <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600' }}>
                      {tr('تأكيد الرمز', 'Verify Code')}
                    </Text>
                  )}
                </TouchableOpacity>
              </View>
            )}
          </View>
        ) : (
          <View style={{ width: '100%', backgroundColor: theme.card, padding: 16, borderRadius: 12, borderWidth: 1, borderColor: theme.border, marginBottom: 24, flexDirection: 'row', alignItems: 'center' }}>
            <Ionicons name="checkmark-circle" size={24} color={theme.success} style={{ marginRight: 12 }} />
            <Text style={{ fontSize: 14, color: theme.success, fontWeight: '600' }}>
              {tr('البريد الإلكتروني مؤكد', 'Email Verified')}
            </Text>
          </View>
        )}

        <TouchableOpacity
          onPress={downloadContract}
          disabled={contractLoading}
          style={{ width: '100%', backgroundColor: theme.primary, padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 12, flexDirection: 'row', justifyContent: 'center' }}>
          {contractLoading ? <ActivityIndicator color="#fff" /> : (
            <>
              <Ionicons name="document-text" size={20} color="#fff" style={{ marginRight: 8 }} />
              <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600' }}>
                {tr('تحميل عقد الشراكة الموقّع', 'Download Signed Partnership Contract')}
              </Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity 
          onPress={() => {
            if (typeof onDone === 'function') {
              onDone();
            } else {
              console.warn('onDone is not a function');
            }
          }}
          style={{ width: '100%', backgroundColor: theme.card, padding: 16, borderRadius: 12, alignItems: 'center', borderWidth: 1, borderColor: theme.border }}>
          <Text style={{ color: theme.text, fontSize: 16, fontWeight: '600' }}>
            {tr('العودة للصفحة الرئيسية', 'Return to Home')}
          </Text>
        </TouchableOpacity>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}
