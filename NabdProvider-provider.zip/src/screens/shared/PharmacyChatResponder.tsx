// @ts-nocheck
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { useLang, useTheme } from '../../context';
import { translateProviderPair } from '../../i18n/providerTextTranslations';

export const PharmacyChatResponder = ({ route, navigation }: any) => {
  const { threadId, patientName } = route.params;
  const { theme } = useTheme();
  const { lang } = useLang();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);

  return (
    <KeyboardAvoidingView style={[styles.container, { backgroundColor: theme.bg }]} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[styles.header, { borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={{color: theme.primary, fontSize: 18}}>{tr('رجوع', 'Back')}</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>{AR ? `محادثة مع: ${patientName}` : `Chat with: ${patientName}`}</Text>
      </View>

      <View style={styles.unavailable}>
        <Text style={[styles.unavailableTitle, { color: theme.text }]}>{tr('المحادثة غير متاحة حالياً', 'Messaging is currently unavailable')}</Text>
        <Text style={[styles.unavailableBody, { color: theme.textMuted }]}>
          {tr('لن نعرض رسائل أو فواتير محلية حتى يربط هذا المسار بعقد محادثة صيدلية موثق وآمن.', 'No local messages or invoices are shown until this route is connected to a verified, secure pharmacy-chat contract.')}
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 20, paddingTop: 60, borderBottomWidth: 1 },
  title: { fontSize: 18, fontWeight: 'bold', marginLeft: 20 },
  unavailable: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28 },
  unavailableTitle: { fontSize: 18, fontWeight: '700', textAlign: 'center', marginBottom: 10 },
  unavailableBody: { fontSize: 14, lineHeight: 22, textAlign: 'center', maxWidth: 360 }
});
