/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║ NABDAH PLUS – PHASE 1 · DOCTOR DASHBOARD & ALL SCREENS ║
 * ║ Dashboard · Appointments · Consultation · E-Prescription ║
 * ║ Referral · Sick Leave · Patient File · Settings · Wallet ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { io } from 'socket.io-client';
import { AppointmentStatus } from '../../types/contracts';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet,
 Animated, FlatList, Alert, Dimensions, Platform, Modal, TextInput,
 RefreshControl, Switch, ActivityIndicator, KeyboardAvoidingView, Linking } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme, useLang, useAuth, useToast } from '../../context';
import DateTimePicker from '@react-native-community/datetimepicker';
import { createAudioPlayer, type AudioPlayer } from 'expo-audio';
import {
 NBtn, NCard, NInput, NStatCard, NAvatar, NBadge,
 NHeader, NScroll, NSheet, NSearch, NToggle, NSettingsRow,
 NSecHeader, NConfirm, NEmpty, NSkeleton, NOnlineToggle,
 NBottomNav, NDivider, NPriceInput, NProfileImageUploader
} from '../../components/ui';
import { I, IBg } from '../../components/icons';
import { SP, R, FS, FW, SPECIALTIES, API_BASE } from '../../constants';
import { buildHeaders } from '../../security/Security';
import client from '../../api/client';
import { WithdrawalWorkflow, MedicalJobsScreen, MedicalDrugIndexScreen, StatisticsReports, GlobalSystemSettings, ChatSystem, InsuranceConfigScreen as SharedInsuranceConfigScreen } from '../shared/SharedScreens';
import { DoctorHeader } from './components/DoctorHeader';
import { DoctorStatsRow } from './components/DoctorStatsRow';
import { DoctorUrgentRequests } from './components/DoctorUrgentRequests';
import { DoctorQueueList } from './components/DoctorQueueList';
import { FacilityInvitationsScreen } from './FacilityInvitationsScreen';
import {
 PromotionsDashboard, CreateCampaignScreen, ProfileWebConfig,
 SubscriptionsAdsScreen, AffiliatePortal, ReputationHub,
 LiveOrderAlarmModal, CrmHub, RevenueInsights, AiMedicalCopilot,
 SmartOutboundReferralNetwork, SosDispatchScreen, GpsRouterScreen
} from '../shared/BlueprintScreens';

const { width: W } = Dimensions.get('window');

// Connected to backend APIs for doctor requests and today appointments

// ══════════════════════════════════════════════════════════════════════════════
// DOCTOR DASHBOARD NAVIGATOR
// ══════════════════════════════════════════════════════════════════════════════
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { translateProviderPair, translateProviderTemplate } from '../../i18n/providerTextTranslations';
const Stack = createNativeStackNavigator();

export function DoctorDashboardNavigator({ onLogout }: { onLogout: () => void }) {
 const [activeTab, setActiveTab] = useState('home');
 const { lang } = useLang();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

 const [alarmVisible, setAlarmVisible] = useState(false);

 const tabs = [
 { key: 'home', icon: 'home', label: tr('الرئيسية', 'Home') },
 { key: 'schedule', icon: 'calendar', label: tr('المواعيد', 'Schedule') },
 { key: 'chat', icon: 'chat', label: tr('المحادثات', 'Chats') },
 { key: 'wallet', icon: 'wallet', label: tr('المحفظة', 'Wallet') },
 { key: 'settings', icon: 'settings', label: tr('الإعدادات', 'Settings') },
 ];

 return (
   <Stack.Navigator id={undefined as any} screenOptions={{ headerShown: false }}>
     <Stack.Screen name="MainTabs">
       {({ navigation }) => {
         const navigateTo = (s: string, param?: any) => navigation.navigate(s, { param });
         return (
           <View style={{ flex: 1 }}>
             {activeTab === 'home' && <DoctorHomeTab onNavigate={navigateTo} onTriggerAlarm={() => setAlarmVisible(true)} />}
             {activeTab === 'schedule' && <DoctorScheduleTab onNavigate={navigateTo} />}
             {activeTab === 'chat' && <ChatSystem onBack={() => setActiveTab('home')} />}
             {activeTab === 'wallet' && <DoctorWalletTab onNavigate={navigateTo} />}
             {activeTab === 'settings' && <DoctorSettingsTab onLogout={onLogout} onNavigate={navigateTo} />}
             {activeTab === 'drugs' && <MedicalDrugIndexScreen onBack={() => setActiveTab('home')} />}
             {activeTab === 'jobs' && <MedicalJobsScreen onBack={() => setActiveTab('home')} />}
             <NBottomNav tabs={tabs} active={activeTab} onPress={setActiveTab} />
             <LiveOrderAlarmModal
               visible={alarmVisible}
               onAccept={() => { setAlarmVisible(false); navigateTo('sos_dispatch'); }}
               onDecline={() => setAlarmVisible(false)}
             />
           </View>
         );
       }}
     </Stack.Screen>

     <Stack.Screen name="appointment_detail">{({ navigation, route }: any) => <AppointmentDetailScreen apt={route.params?.param} onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="consultation">{({ navigation, route }: any) => <LiveConsultationScreen apt={route.params?.param} onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="prescription">{({ navigation, route }: any) => <EPrescriptionScreen apt={route.params?.param} onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="sick_leave">{({ navigation, route }: any) => <SickLeaveScreen apt={route.params?.param} onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="medical_report">{({ navigation, route }: any) => <MedicalReportScreen apt={route.params?.param} onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="referral">{({ navigation, route }: any) => <ReferralScreen apt={route.params?.param} onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="request_test">{({ navigation, route }: any) => <RequestTestScreen apt={route.params?.param} onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="patient_file">{({ navigation, route }: any) => <PatientFileScreen patient={route.params?.param} onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="no_show">{({ navigation }: any) => <NoShowManagementScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="withdrawal_workflow">{({ navigation }: any) => <WithdrawalWorkflow onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="revenue_insights">{({ navigation }: any) => <StatisticsReports onBack={() => navigation.goBack()} providerType="doctor" />}</Stack.Screen>
     <Stack.Screen name="availability_engine">{({ navigation }: any) => <DoctorAvailabilityScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="service_management">{({ navigation }: any) => <DoctorServiceManagementScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="promotions">{({ navigation }: any) => <PromotionsDashboard onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="create_promo">{({ navigation }: any) => <CreateCampaignScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="web_config">{({ navigation }: any) => <ProfileWebConfig onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="subscriptions_ads">{({ navigation }: any) => <SubscriptionsAdsScreen onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="affiliate">{({ navigation }: any) => <AffiliatePortal onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="reputation">{({ navigation }: any) => <ReputationHub onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="crm">{({ navigation }: any) => <CrmHub onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="ai_copilot">{({ navigation }: any) => <AiMedicalCopilot onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="outbound_referral">{({ navigation }: any) => <SmartOutboundReferralNetwork onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="sos_dispatch">{({ navigation }: any) => <SosDispatchScreen onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="gps_router">{({ navigation, route }: any) => <GpsRouterScreen patient={route.params?.param} onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="profile_edit">{({ navigation }: any) => <DoctorProfileEditScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="insurance_config">{({ navigation }: any) => <SharedInsuranceConfigScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="certificates_config">{({ navigation }: any) => <CertificatesConfigScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="media_config">{({ navigation }: any) => <MediaConfigScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="virtual_waiting_room">{({ navigation }: any) => <VirtualWaitingRoomScreen onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="pre_visit_chat">{({ navigation, route }: any) => <PreVisitChatScreen apt={route.params?.param} onBack={() => navigation.goBack()} onNavigate={(s: string, p?: any) => navigation.navigate(s, { param: p })} />}</Stack.Screen>
     <Stack.Screen name="medical_jobs">{({ navigation }: any) => <MedicalJobsScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="drug_index">{({ navigation }: any) => <MedicalDrugIndexScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="location_config">{({ navigation }: any) => <DoctorLocationScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
     <Stack.Screen name="inbound_reports">{({ navigation }: any) => <InboundMedicalReportsScreen onBack={() => navigation.goBack()} />}</Stack.Screen>
   </Stack.Navigator>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// HOME TAB
// ══════════════════════════════════════════════════════════════════════════════
function DoctorHomeTab({ onNavigate, onTriggerAlarm }: { onNavigate: (s: string, p?: any) => void; onTriggerAlarm: () => void }) {
 const insets = useSafeAreaInsets();
 const { theme } = useTheme();
 const { lang } = useLang();
 const { user, toggleOnline } = useAuth();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [refreshing, setRefreshing] = useState(false);
 const [requests, setRequests] = useState<any[]>([]);
 const [todayApts, setTodayApts] = useState<any[]>([]);
 const [stats, setStats] = useState({ todayCount: 0, revenue: 0, pendingCount: 0 });
 const [error, setError] = useState(false);
 const { show } = useToast();

 const [sound, setSound] = useState<AudioPlayer | null>(null);
 const [insuranceModalReq, setInsuranceModalReq] = useState<any>(null);
 const [approvalStatus, setApprovalStatus] = useState('كلية');
 const [patientCopay, setPatientCopay] = useState('');
 const [insuranceCoverage, setInsuranceCoverage] = useState('');
 const [approvalCode, setApprovalCode] = useState('');

 async function playRingtone() {
    try {
      const player = createAudioPlayer(require('../../../assets/audio/rad_dispatch_alert.mp3'));
      player.loop = true;
      setSound(player);
      player.play();
      setTimeout(() => {
        player.pause();
        setSound((current) => current === player ? null : current);
      }, 45000);
    } catch (e) {
      console.warn("Could not play ringtone", e);
    }
  }

  async function stopRingtone() {
    if (sound) { sound.pause(); setSound(null); }
  }

  useEffect(() => {
    return sound ? () => { sound.remove(); } : undefined;
  }, [sound]);

  useEffect(() => {
    let socketInstance: any = null;
    if (user?.id) {
      const cleanUrl = API_BASE.replace('/api', '').replace('/v1', '');
      socketInstance = io(cleanUrl, { 
        transports: ['websocket'],
        auth: { token: (user as any)?.token || '' }
      });
      socketInstance.on('connect', () => socketInstance?.emit('joinProviderRoom', user.id));
      socketInstance.on('incoming_urgent_request', (payload: any) => {
        setRequests(prev => [payload, ...prev]);
        playRingtone();
        onTriggerAlarm();
      });
    }
    return () => { if (socketInstance) socketInstance.disconnect(); };
  }, [user?.id]);

 const fetchQueue = useCallback(async () => {
 setError(false);
 try {
	const resIncoming = await client.get('/provider/jobs/queue?status=incoming&kind=consultation');
	setRequests((resIncoming.data || []).map((x: any) => ({
		id: x.id, kind: x.kind || 'consultation', patient: x.patient_name || '—',
        age: x.age ?? null, type: x.service_type || 'video', price: x.total ?? x.price ?? 0,
        time: x.scheduled_at ? new Date(x.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (tr('غير محدد', 'Unscheduled')),
	        avatar: '', complaint: x.title_ar || '', insurance: x.insurance_provider || '—',
        paid: x.payment_status === 'PAID', urgent: !!x.is_urgent,
         policyClass: x.policy_class || null, nationalId: x.national_id || null, dob: x.dob || null
  })));

 const resToday = await client.get('/provider/jobs/queue?status=active');
 setTodayApts((resToday.data || []).map((x: any) => ({
	 id: x.id, patient: x.patient_name || '—',
     type: x.service_type || 'video', time: x.scheduled_at ? new Date(x.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (tr('غير محدد', 'Unscheduled')),
	     status: x.status || 'unknown', price: x.total ?? x.price ?? 0, insurance: x.insurance_provider || '—',
     age: x.age ?? null, avatar: ''
 })));

 const resStats = await client.get('/provider/stats/today');
 if (resStats.data) setStats(resStats.data);
	 } catch (err) {
	  // Keep the prior data out of the way and expose a retryable error state.
	  setError(true);
	  show(tr('تعذر جلب البيانات. يرجى التأكد من اتصالك بالإنترنت.', 'Failed to fetch data.'), 'error');
	 }
 }, [AR]);

 useEffect(() => { fetchQueue(); }, [fetchQueue]);

 const onRefresh = async () => { setRefreshing(true); await fetchQueue(); setRefreshing(false); };

	const handleAccept = async (req: any) => {
	try {
	await client.post(`/provider/jobs/${req.kind || 'consultation'}/${req.id}/accept`);
 setRequests(prev => prev.filter(r => r.id !== req.id));
 show(tr('تم قبول الطلب بنجاح', 'Request accepted successfully'), 'success');
 fetchQueue();
 stopRingtone();
 } catch (e) { show(tr('حدث خطأ أثناء القبول', 'Error accepting request'), 'error'); }
 };

	const handleReject = async (req: any) => {
	try {
	await client.post(`/provider/jobs/${req.kind || 'consultation'}/${req.id}/reject`);
 setRequests(prev => prev.filter(r => r.id !== req.id));
 show(tr('تم رفض الطلب', 'Request rejected'), 'info');
 stopRingtone();
 } catch (e) { show(tr('حدث خطأ', 'Error'), 'error'); }
 };

 const submitInsuranceGatekeeper = async () => {
   if (!approvalCode.trim() || !patientCopay.trim()) {
     show(tr('يرجى تعبئة كافة الحقول المطلوبة', 'Please fill all required fields'), 'error');
     return;
   }
   try {
     await client.post(`/provider/jobs/consultation/${insuranceModalReq.id}/insurance`, {
       status: approvalStatus, copay: parseFloat(patientCopay), coverage: parseFloat(insuranceCoverage || '0'), approval_code: approvalCode
     });
     setInsuranceModalReq(null);
     show(tr('تم إرسال الطلب للمريض لدفع نسبة التحمل', 'Request sent to patient for Co-Pay'), 'success');
     fetchQueue();
   } catch (err) {
     show(tr('حدث خطأ أثناء رفع الاعتماد', 'Error submitting approval'), 'error');
   }
 };

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NHeader title={tr('الرئيسية', 'Home')} right={
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, alignItems: 'center' }}>
 <TouchableOpacity onPress={onTriggerAlarm} style={{ padding: SP.xs }}>
 <I name="bell" size={24} color={theme.text} />
 </TouchableOpacity>
 <NOnlineToggle value={!!user?.isOnline} onToggle={toggleOnline} />
 </View>
 } />

 <ScrollView refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}
 contentContainerStyle={{ padding: SP.md, paddingBottom: 100 }}>
 
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', flexWrap: 'wrap', gap: SP.md, marginBottom: SP.lg }}>
 <NStatCard icon="" label={tr('مواعيد اليوم', "Today's Apts")} value={String(stats.todayCount)} color={theme.primary} style={{ width: '47%' }} />
 <NStatCard icon="" label={tr('طلبات جديدة', 'New Requests')} value={String(stats.pendingCount)} color="#FF9800" style={{ width: '47%' }} />
 </View>

 {error && (
   <NCard style={{ alignItems: 'center', padding: SP.xxl, marginBottom: SP.lg, borderColor: theme.danger }}>
     <Text style={{ color: theme.danger, textAlign: 'center', marginBottom: SP.md }}>{tr('تعذر جلب البيانات', 'Failed to load data')}</Text>
     <NBtn label={tr('إعادة المحاولة', 'Retry')} onPress={fetchQueue} size="sm" />
   </NCard>
 )}

 <NSecHeader title={tr('طلبات جديدة', 'New Requests')} action={tr('عرض الكل', 'View All')} onAction={() => onNavigate('schedule')} />

 {requests.length === 0 ? (
 <NCard style={{ alignItems: 'center', padding: SP.xxl, marginBottom: SP.lg }}>
 <Text style={{ color: theme.textSub, textAlign: 'center' }}>{tr('لا توجد طلبات جديدة حالياً', 'No new requests right now')}</Text>
 </NCard>
 ) : (
 requests.map(req => {
   const isOnline = req.type === 'video' || req.type === 'online';
   const isClinic = req.type === 'clinic';
   const typeBadge = isOnline ? '[🔴 استشارة أونلاين]' : isClinic ? '[🔵 حجز عيادة]' : '[🟢 زيارة منزلية]';
   
   const isCashOnline = req.insurance === 'Cash' && req.paid;
   const isCashClinic = req.insurance === 'Cash' && !req.paid;
   const paymentBadge = isCashOnline ? '[💳 كاش - مدفوع أونلاين]' : isCashClinic ? '[💵 كاش - الدفع بالعيادة]' : `[🛡️ تأمين طبي: ${req.insurance}]`;

   return (
 <NCard key={req.id} style={{ marginBottom: SP.md }} accent={req.urgent ? '#F44336' : undefined}>
 {req.urgent && <NBadge label={tr(' عاجل', ' Urgent')} variant="danger" style={{ marginBottom: SP.sm }} />}
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, marginBottom: SP.md }}>
 <NAvatar name={req.patient} size={48} />
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>{req.patient}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginTop: 2, fontWeight: FW.bold }}>{typeBadge}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginTop: 2 }}>{paymentBadge}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.primary, marginTop: 2 }}>⏰ {req.time}</Text>
 </View>
 </View>

 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: SP.md, flexWrap: 'wrap', gap: SP.sm }}>
 <NBtn label={tr('رفض', 'Reject')} variant="secondary" size="sm" full={false} style={{ paddingHorizontal: SP.lg }}
 onPress={() => handleReject(req)} />

	 {isCashClinic ? (
	   <NBtn label={tr('قبول', 'Accept')} size="sm" full={false} style={{ paddingHorizontal: SP.xl }} onPress={() => handleAccept(req)} />
	 ) : req.insurance !== 'Cash' ? (
   <NBtn label={tr('قبول واستكمال إجراءات التأمين', 'Accept & Process Insurance')} size="sm" full={false} onPress={() => setInsuranceModalReq(req)} />
 ) : (
   <NBtn label={tr('قبول', 'Accept')} size="sm" full={false} style={{ paddingHorizontal: SP.xl }} onPress={() => handleAccept(req)} />
 )}
 </View>
 </NCard>
 );
 })
 )}

 <View style={{ marginTop: SP.lg }}>
 <NSecHeader title={tr('جدول اليوم', "Today's Schedule")} action={tr('الجميع', 'All')} onAction={() => onNavigate('schedule')} />
 </View>

 {todayApts.length === 0 ? (
 <NCard style={{ alignItems: 'center', padding: SP.xxl }}><Text style={{ color: theme.textSub, textAlign: 'center' }}>{tr('لا توجد مواعيد مؤكدة اليوم', 'No confirmed appointments today')}</Text></NCard>
 ) : (
 todayApts.map(apt => (
 <TouchableOpacity key={apt.id} onPress={() => onNavigate('consultation', apt)} style={{ padding: SP.md, backgroundColor: theme.card, borderRadius: R.md, marginBottom: SP.sm, flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md }}>
 <Text style={{ fontSize: FS.md, color: theme.text }}>{apt.patient} - {apt.time}</Text>
 </TouchableOpacity>
 ))
 )}

 <View style={{ marginTop: SP.lg }}>
 <NSecHeader title={tr('منصات نبض بلس', 'Nabdah Modules')} />
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, flexWrap: 'wrap' }}>
   <TouchableOpacity 
     onPress={() => onNavigate('medical_jobs')}
     style={{ flex: 1, backgroundColor: theme.primary, borderRadius: R.md, padding: SP.lg, alignItems: 'center' }}>
     <I name="profile" size={32} color="#FFF" />
     <Text style={{ color: '#FFF', fontWeight: FW.bold, marginTop: SP.sm, textAlign: 'center' }}>
       {tr('الوظائف الطبية', 'Medical Jobs')}
     </Text>
   </TouchableOpacity>
   <TouchableOpacity 
     onPress={() => onNavigate('drug_index')}
     style={{ flex: 1, backgroundColor: theme.info, borderRadius: R.md, padding: SP.lg, alignItems: 'center' }}>
     <I name="document" size={32} color="#FFF" />
     <Text style={{ color: '#FFF', fontWeight: FW.bold, marginTop: SP.sm, textAlign: 'center' }}>
       {tr('دليل الأدوية', 'Drug Index')}
     </Text>
   </TouchableOpacity>
   <TouchableOpacity 
     onPress={() => onNavigate('inbound_reports')}
     style={{ width: '100%', backgroundColor: theme.success, borderRadius: R.md, padding: SP.lg, alignItems: 'center', marginTop: SP.sm }}>
     <I name="folder" size={32} color="#FFF" />
     <Text style={{ color: '#FFF', fontWeight: FW.bold, marginTop: SP.sm, textAlign: 'center' }}>
       {tr('التقارير الطبية الواردة (نتائج الأشعة والتحاليل)', 'Inbound Medical Reports (Radiology & Labs)')}
     </Text>
   </TouchableOpacity>
 </View>
 </View>

 </ScrollView>

 {/* Gatekeeper Modal */}
 <NSheet visible={!!insuranceModalReq} onClose={() => setInsuranceModalReq(null)} title={tr(' بوابة التأمين الطبي (Gatekeeper)', ' Insurance Gatekeeper')} height={700}>
  <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }} keyboardVerticalOffset={100}>
  <ScrollView style={{ padding: SP.md }} contentContainerStyle={{ paddingBottom: 100 }} keyboardShouldPersistTaps="handled">
  <NCard style={{ marginBottom: SP.md, backgroundColor: theme.primaryLight, borderColor: theme.primary, borderWidth: 1 }}>
  <Text style={{ fontSize: FS.sm, fontWeight: FW.bold, color: theme.primary, textAlign: AR ? 'right' : 'left', marginBottom: 4 }}>
  {tr('المريض:', 'Patient:')} {insuranceModalReq?.patient}
  </Text>
  <View style={{ flexDirection: AR ? 'row-reverse' : 'row', flexWrap: 'wrap', gap: SP.md, marginTop: SP.xs }}>
    <View style={{ width: '45%' }}>
      <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('رقم الهوية:', 'National ID:')}</Text>
      <Text style={{ fontSize: FS.sm, color: theme.text, textAlign: AR ? 'right' : 'left', fontWeight: FW.bold }}>{insuranceModalReq?.nationalId}</Text>
    </View>
    <View style={{ width: '45%' }}>
      <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('تاريخ الميلاد:', 'DOB:')}</Text>
      <Text style={{ fontSize: FS.sm, color: theme.text, textAlign: AR ? 'right' : 'left', fontWeight: FW.bold }}>{insuranceModalReq?.dob}</Text>
    </View>
    <View style={{ width: '45%' }}>
      <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('بوليصة:', 'Policy:')}</Text>
      <Text style={{ fontSize: FS.sm, color: theme.text, textAlign: AR ? 'right' : 'left', fontWeight: FW.bold }}>{insuranceModalReq?.insurance}</Text>
    </View>
    <View style={{ width: '45%' }}>
      <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('فئة التأمين:', 'Class:')}</Text>
      <Text style={{ fontSize: FS.sm, color: theme.text, textAlign: AR ? 'right' : 'left', fontWeight: FW.bold }}>{insuranceModalReq?.policyClass}</Text>
    </View>
  </View>
  <View style={{ marginTop: SP.sm, paddingTop: SP.sm, borderTopWidth: 1, borderTopColor: 'rgba(0,0,0,0.1)' }}>
    <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('سبب الاستشارة:', 'Complaint:')}</Text>
    <Text style={{ fontSize: FS.sm, color: theme.text, textAlign: AR ? 'right' : 'left', fontWeight: FW.bold, marginTop: 2 }}>{insuranceModalReq?.complaint || (tr('غير متوفر', 'N/A'))}</Text>
  </View>
  </NCard>
  <Text style={{ fontSize: FS.sm, fontWeight: FW.bold, color: theme.text, marginBottom: SP.sm, textAlign: AR ? 'right' : 'left' }}>{tr('حالة الموافقة من نفييس:', 'NPHIES Approval Status:')}</Text>
  <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.sm, marginBottom: SP.lg }}>
  {['كلية', 'جزئية', 'مرفوضة'].map(s => (
  <TouchableOpacity key={s} onPress={() => setApprovalStatus(s)} style={{ flex: 1, padding: SP.md, borderRadius: R.md, backgroundColor: approvalStatus === s ? theme.primary : theme.surface2, alignItems: 'center' }}>
  <Text style={{ color: approvalStatus === s ? '#FFF' : theme.text }}>{s}</Text>
  </TouchableOpacity>
  ))}
  </View>
  <NInput label={tr('نسبة تحمل المريض (SAR)', 'Patient Co-Pay (SAR)')} value={patientCopay} onChange={setPatientCopay} kbType="numeric" placeholder="e.g. 50" icon="" />
  <NInput label={tr('تحمل شركة التأمين (SAR)', 'Insurance Coverage (SAR)')} value={insuranceCoverage} onChange={setInsuranceCoverage} kbType="numeric" placeholder="e.g. 150" icon="" />
  <NInput label={tr('رقم الموافقة المرجعي (Approval Code)', 'Approval Code')} value={approvalCode} onChange={setApprovalCode} placeholder="e.g. NPH-9213" icon="" />
  <NBtn label={tr(' إرسال للمريض لدفع نسبة التحمل', ' Send to Patient for Co-Pay')} onPress={submitInsuranceGatekeeper} style={{ marginTop: SP.md, marginBottom: SP.xxl }} />
  </ScrollView>
  </KeyboardAvoidingView>
  </NSheet>
 </View>
 );
}

// ════
// ══════════════════════════════════════════════════════════════════════════════
// SCHEDULE TAB
// ══════════════════════════════════════════════════════════════════════════════
function DoctorScheduleTab({ onNavigate }: { onNavigate: (s: string, p?: any) => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [view, setView] = useState<'day'|'week'|'list'>('list');
 const [filter, setFilter] = useState<'all'|'video'|'clinic'|'home'>('all');
 const [apts, setApts] = useState<any[]>([]);

 const filters = [
 { k:'all', ar:'الكل', en:'All' },
 { k:'video', ar:'فيديو', en:'Video' },
 { k:'clinic', ar:'عيادة', en:'Clinic' },
 { k:'home', ar:'منزلية', en:'Home' },
 ] as const;

 useEffect(() => {
 client.get('/provider/jobs/queue?status=active&kind=consultation')
 .then(res => {
      setApts((res.data || []).map((x: any) => ({
      id: x.id,
      appointment_id: x.kind === 'consultation' ? x.id : undefined,
      patient_id: x.patient_id,
      server_state: x.domain_state,
      patient: x.patient_name || '—',
      time: x.scheduled_at ? new Date(x.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '',
      type: x.service_type || 'video',
      status: x.domain_state === 'IN_PROGRESS' || x.universal_state === AppointmentStatus.IN_PROGRESS ? AppointmentStatus.IN_PROGRESS : 'confirmed',
      price: x.total ?? x.price ?? 0,
      raw: x
      })));
 })
 .catch(() => setApts([]));
 }, [AR]);

 const filtered = filter === 'all' ? apts : apts.filter(a => a.type === filter);

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <View style={[styles.topBar, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
 <Text style={{ fontSize: FS.xl, fontWeight: FW.bold, color: theme.text }}>
 {tr(' المواعيد', ' Schedule')}
 </Text>
 <TouchableOpacity onPress={() => onNavigate('no_show')}
 style={[styles.iconBtn, { backgroundColor: theme.surface2 }]}>
 <I name="user-x" size={20} color={theme.text} />
 </TouchableOpacity>
 </View>

 {/* View toggles */}
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.sm, paddingHorizontal: SP.lg, paddingTop: SP.lg, paddingBottom: SP.xs, alignItems: 'center' }}>
 {(['day','week','list'] as const).map(v => (
 <TouchableOpacity key={v} onPress={() => setView(v)}
 style={[styles.viewChip, {
 backgroundColor: view === v ? theme.primary : theme.surface2,
 borderColor: view === v ? theme.primary : theme.border,
 alignItems: 'center', justifyContent: 'center', height: 36
 }]}>
 <Text style={{ color: view === v ? '#FFF' : theme.text, fontSize: FS.sm }}>
 {v === 'day' ? (tr('يوم', 'Day')) : v === 'week' ? (tr('أسبوع', 'Week')) : (tr('قائمة', 'List'))}
 </Text>
 </TouchableOpacity>
 ))}
 </View>

 {/* Filter chips */}
 <View style={{ height: 44 }}>
  <ScrollView horizontal showsHorizontalScrollIndicator={false}
  contentContainerStyle={{ paddingHorizontal: SP.lg, gap: SP.sm, alignItems: 'center' }}>
  {filters.map(f => (
  <TouchableOpacity key={f.k} onPress={() => setFilter(f.k as any)}
  style={[styles.filterChip, {
  backgroundColor: filter === f.k ? theme.primary : theme.surface2,
  borderColor: filter === f.k ? theme.primary : theme.border,
  alignItems: 'center', justifyContent: 'center', height: 32, paddingVertical: 0
  }]}>
 <Text style={{ color: filter === f.k ? '#FFF' : theme.text, fontSize: FS.sm }}>
 {AR ? f.ar : f.en}
 </Text>
 </TouchableOpacity>
 ))}
 </ScrollView>
 </View>

 <FlatList
 data={filtered}
 keyExtractor={i => i.id}
 contentContainerStyle={{ padding: SP.lg, paddingBottom: 100 }}
 ListEmptyComponent={<NEmpty title={tr('لا توجد مواعيد', 'No appointments')} sub={tr('اختر تاريخاً أو نوعاً آخر.', 'Try selecting another date or type.')} icon="calendar" />}
 renderItem={({ item }) => (
 <TouchableOpacity onPress={() => onNavigate('appointment_detail', item)}>
 <NCard style={{ marginBottom: SP.md }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
 <View style={[styles.timeTag, { backgroundColor: theme.primaryLight }]}>
 <Text style={{ fontSize: FS.xs, color: theme.primary, fontWeight: FW.bold }}>{item.time}</Text>
 </View>
 <NAvatar name={item.patient} size={40} />
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.semi, color: theme.text,
 textAlign: AR ? 'right' : 'left' }}>{item.patient}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>
 {item.type === 'video'?'':item.type==='clinic'?'':''} {item.price} {tr('ر', 'SAR')}
 </Text>
 </View>
 <NBadge
 label={item.status === 'confirmed' ? (tr('مؤكد', 'Confirmed')) : item.status === AppointmentStatus.IN_PROGRESS ? (tr('جارٍ', 'Active')) : (tr('انتظار', 'Pending'))}
 variant={item.status === 'confirmed' ? 'success' : item.status === AppointmentStatus.IN_PROGRESS ? 'warning' : 'info'}
 size="xs" />
 </View>
 </NCard>
 </TouchableOpacity>
 )}
 />
 </View>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// APPOINTMENT DETAIL
// ══════════════════════════════════════════════════════════════════════════════
function AppointmentDetailScreen({ apt, onBack, onNavigate }:
 { apt: any; onBack: () => void; onNavigate: (s: string, p?: any) => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);

 return (
 <NScroll>
 <NHeader title={tr('تفاصيل الموعد', 'Appointment Details')} onBack={onBack} />

 {/* Patient Info */}
 <NCard style={{ marginBottom: SP.xl }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.lg, marginBottom: SP.lg }}>
 <NAvatar name={apt?.patient || '—'} size={60} />
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.xl, fontWeight: FW.bold, color: theme.text,
 textAlign: AR ? 'right' : 'left' }}>{apt?.patient || '—'}</Text>
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{apt?.age != null ? `${apt.age} ${tr('سنة', 'yrs')}` : tr('العمر غير متاح من الخادم', 'Age unavailable from server')}</Text>
 {apt?.insurance ? <NBadge label={apt.insurance} variant="primary" size="xs" style={{ marginTop: SP.xs }} /> : <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginTop: SP.xs }}>{tr('بيانات التأمين غير متاحة من الخادم', 'Insurance data unavailable from server')}</Text>}
 </View>
 </View>


 {[
 { icon:'clock', ar:'وقت الموعد', en:'Time', val:apt?.time || tr('غير متاح من الخادم', 'Unavailable from server') },
 { icon:'video', ar:'نوع الخدمة', en:'Type', val:apt?.type === 'video' ? (tr('استشارة فيديو', 'Video Consult')) : apt?.type === 'clinic' ? (tr('كشف عيادة', 'Clinic')) : apt?.type === 'home' ? (tr('زيارة منزلية', 'Home Visit')) : tr('غير متاح من الخادم', 'Unavailable from server') },
 { icon:'dollarSign', ar:'الرسوم', en:'Fee', val:apt?.price != null ? `${apt.price} ${tr('ريال', 'SAR')}` : tr('غير متاح من الخادم', 'Unavailable from server') },
 { icon:'fileText', ar:'الشكوى', en:'Complaint', val:apt?.complaint || tr('غير متاح من الخادم', 'Unavailable from server') },
 ].map((row, i) => (
 <View key={i} style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md,
 paddingVertical: SP.sm, borderBottomWidth: i < 3 ? StyleSheet.hairlineWidth : 0, borderBottomColor: theme.border, alignItems: 'center' }}>
 <I name={row.icon} size={18} color={theme.textSub} />
 <Text style={{ color: theme.textSub, fontSize: FS.sm, flex: 0.8, textAlign: AR?'right':'left' }}>{AR?row.ar:row.en}</Text>
  <Text style={{ flex: 1, color: theme.text, fontSize: FS.sm, fontWeight: FW.med, textAlign: AR?'right':'left' }}>{row.val}</Text>
  </View>
  ))}
  </NCard>
  <NBtn label={tr('ابدأ الاستشارة', 'Start Consultation')} onPress={() => onNavigate('consultation', apt)} style={{ marginTop: SP.xl }} />
  <NBtn label={tr('إصدار وصفة إلكترونية', 'Issue e-prescription')} variant="outline" onPress={() => onNavigate('prescription', apt)} disabled={!(apt?.appointment_id && apt?.patient_id && apt?.server_state === 'IN_PROGRESS')} style={{ marginTop: SP.sm }} />
  </NScroll>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// ACTIVE CONSULTATION (WAITING ROOM & EXAM)
// ══════════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════════
// ACTIVE CONSULTATION (WAITING ROOM & EXAM)
// ══════════════════════════════════════════════════════════════════════════════
function LiveConsultationScreen({ apt, onBack }: { apt: any; onBack: () => void; onNavigate: (s: string, p?: any) => void }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const AR = lang === 'ar';
  const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
  return (
    <NScroll>
      <NHeader title={tr('الاستشارة السريرية', 'Clinical consultation')} onBack={onBack} />
      <NCard style={{ backgroundColor: theme.surface, gap: SP.md }}>
        <NAvatar name={apt?.patient || '—'} size={56} />
        <Text style={{ color: theme.text, fontWeight: FW.bold, textAlign: AR ? 'right' : 'left' }}>
          {apt?.patient || tr('مريض غير محدد', 'Unspecified patient')}
        </Text>
        <Text style={{ color: theme.textSub, lineHeight: 22, textAlign: AR ? 'right' : 'left' }}>
          {tr(
            'الاستشارة غير متاحة في هذه الشاشة حتى يكتمل عقد خادمي موثق يربط الطبيب والموعد والمريض، ويؤمّن الرسائل والسجل الطبي والمكالمة والحفظ والتدقيق.',
            'Consultation is unavailable on this screen until a verified server contract binds provider, appointment, and patient and secures messaging, clinical history, calling, persistence, and audit.',
          )}
        </Text>
        <Text style={{ color: theme.danger, lineHeight: 22, textAlign: AR ? 'right' : 'left' }}>
          {tr('لن نعرض رسائل أو حقائق سريرية أو حالة مكالمة محلية بوصفها عملية حية.', 'No local messages, clinical facts, or call state are shown as a live operation.')}
        </Text>
      </NCard>
      <NBtn label={tr('رجوع', 'Back')} onPress={onBack} style={{ marginTop: SP.xl }} />
    </NScroll>
  );
}

function EPrescriptionScreen({ apt, onBack }: { apt: any; onBack: () => void }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const { show } = useToast();
  const AR = lang === 'ar';
  const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
  const [query, setQuery] = useState('');
  const [catalogue, setCatalogue] = useState<any[]>([]);
  const [selectedMedicineId, setSelectedMedicineId] = useState('');
  const [manualNameAr, setManualNameAr] = useState('');
  const [manualNameEn, setManualNameEn] = useState('');
  const [dose, setDose] = useState('');
  const [durationDays, setDurationDays] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [loadingCatalogue, setLoadingCatalogue] = useState(false);
  const [issuing, setIssuing] = useState(false);
  const appointmentId = String(apt?.appointment_id || '');
  const patientId = String(apt?.patient_id || '');
  const hasVerifiedAppointment = Boolean(appointmentId && patientId && apt?.server_state === 'IN_PROGRESS');

  const loadCatalogue = async () => {
    const term = query.trim();
    if (!term) return;
    setLoadingCatalogue(true);
    try {
      const res = await client.get('/medicines', { params: { search: term, limit: 20 } });
      const rows = Array.isArray(res.data) ? res.data : (Array.isArray(res.data?.items) ? res.data.items : []);
      setCatalogue(rows);
    } catch {
      setCatalogue([]);
      show(tr('تعذر تحميل كتالوج الأدوية المعتمدة', 'Could not load the approved medicine catalogue'), 'error');
    } finally {
      setLoadingCatalogue(false);
    }
  };

  const issuePrescription = async () => {
    if (!hasVerifiedAppointment) {
      show(tr('يلزم موعد نشط مملوك للطبيب ومريض موثق قبل إصدار الوصفة', 'A provider-owned in-progress appointment and verified patient are required'), 'error');
      return;
    }
    const duration = Number(durationDays);
    if (!dose.trim() || !Number.isFinite(duration) || duration <= 0) {
      show(tr('أدخل الجرعة ومدة علاج صحيحتين', 'Enter a valid dose and treatment duration'), 'error');
      return;
    }
    const item = selectedMedicineId
      ? { medicine_id: selectedMedicineId, dose: dose.trim(), duration_days: duration }
      : { manual_name_ar: manualNameAr.trim(), manual_name_en: manualNameEn.trim(), dose: dose.trim(), duration_days: duration };
    if (!selectedMedicineId && !manualNameAr.trim() && !manualNameEn.trim()) {
      show(tr('اختر دواءً معتمداً أو أدخل اسماً يدوياً للمراجعة', 'Select an approved medicine or enter a manual name for review'), 'error');
      return;
    }
    setIssuing(true);
    try {
      await client.post('/prescriptions/create', {
        appointment_id: appointmentId,
        patient_id: patientId,
        diagnosis: diagnosis.trim() || undefined,
        items: [item],
      });
      show(
        selectedMedicineId
          ? tr('تم إنشاء الوصفة بعد تأكيد الخادم', 'Prescription created after server confirmation')
          : tr('تم إنشاء الوصفة؛ الصنف اليدوي بانتظار مراجعة الصيدلية وبديل معتمد', 'Prescription created; the manual item awaits pharmacy review and an approved substitute'),
        'success',
      );
      onBack();
    } catch (e: any) {
      const msg = e?.response?.data?.message;
      show(typeof msg === 'string' ? msg : tr('تعذر إنشاء الوصفة؛ راجع الموعد والدواء', 'Could not create prescription; verify the appointment and medicine'), 'error');
    } finally {
      setIssuing(false);
    }
  };

  return (
    <NScroll>
      <NHeader title={tr('الوصفة الطبية الإلكترونية', 'Electronic prescription')} onBack={onBack} />
      <NCard style={{ backgroundColor: theme.surface, gap: SP.md }}>
        <NAvatar name={apt?.patient || '—'} size={56} />
        <Text style={{ color: theme.text, fontWeight: FW.bold, textAlign: AR ? 'right' : 'left' }}>{apt?.patient || '—'}</Text>
        {!hasVerifiedAppointment && <Text style={{ color: theme.danger, lineHeight: 22, textAlign: AR ? 'right' : 'left' }}>{tr('إصدار الوصفة محجوب: لم يثبت الموعد النشط أو ملكية المريض من الخادم.', 'Issuance is blocked: the active appointment or patient ownership is not server-verified.')}</Text>}
        <NInput label={tr('ابحث في كتالوج الأدوية المعتمدة', 'Search approved medicine catalogue')} value={query} onChange={setQuery} icon="" />
        <NBtn label={tr('بحث', 'Search')} variant="outline" onPress={loadCatalogue} loading={loadingCatalogue} disabled={loadingCatalogue || !query.trim()} />
        {catalogue.map((medicine: any) => (
          <TouchableOpacity key={medicine.id} onPress={() => { setSelectedMedicineId(medicine.id); setManualNameAr(''); setManualNameEn(''); }} style={{ padding: SP.sm, borderRadius: R.sm, backgroundColor: selectedMedicineId === medicine.id ? theme.primaryLight : theme.surface2 }}>
            <Text style={{ color: theme.text, textAlign: AR ? 'right' : 'left' }}>{AR ? (medicine.name_ar || medicine.name_en) : (medicine.name_en || medicine.name_ar)}</Text>
          </TouchableOpacity>
        ))}
        <Text style={{ color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('أو سجل دواءً استثنائياً للمراجعة؛ لن يدخل الكتالوج ولن يُصرف دون بديل معتمد.', 'Or record an exceptional medicine for review; it will not enter the catalogue or be dispensed without an approved substitute.')}</Text>
        <NInput label={tr('اسم الدواء اليدوي بالعربية', 'Manual medicine name (Arabic)')} value={manualNameAr} onChange={(value: string) => { setManualNameAr(value); setSelectedMedicineId(''); }} icon="" />
        <NInput label={tr('اسم الدواء اليدوي بالإنجليزية', 'Manual medicine name (English)')} value={manualNameEn} onChange={(value: string) => { setManualNameEn(value); setSelectedMedicineId(''); }} icon="" />
        <NInput label={tr('الجرعة', 'Dose')} value={dose} onChange={setDose} icon="" required />
        <NInput label={tr('المدة بالأيام', 'Duration in days')} value={durationDays} onChange={setDurationDays} kbType="numeric" icon="" required />
        <NInput label={tr('التشخيص (اختياري)', 'Diagnosis (optional)')} value={diagnosis} onChange={setDiagnosis} icon="" />
        <NBtn label={tr('إنشاء الوصفة', 'Create prescription')} onPress={issuePrescription} loading={issuing} disabled={issuing || !hasVerifiedAppointment} style={{ marginTop: SP.sm }} />
      </NCard>
    </NScroll>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
export function SickLeaveScreen({ apt, onBack }:
 { apt: any; onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [days, setDays] = useState('3');
 const [from, setFrom] = useState(new Date().toISOString().split('T')[0]);
 const [diag, setDiag] = useState('');
 const [issued, setIssued] = useState(false);

 if (issued) {
 return (
 <View style={{ flex: 1, backgroundColor: theme.bg, padding: SP.xl, justifyContent: 'center', alignItems: 'center' }}>
 <Text style={{ fontSize: 80, marginBottom: SP.xl }}></Text>
 <Text style={{ fontSize: FS['2xl'], fontWeight: FW.bold, color: theme.text, textAlign: 'center', marginBottom: SP.md }}>
 {tr('تم إصدار الإجازة المرضية', 'Sick Leave Issued')}
 </Text>
 <NCard style={{ width: '100%', marginBottom: SP.xl, backgroundColor: theme.successBg }}>
 <Text style={{ fontSize: FS.sm, color: theme.success, textAlign: AR ? 'right' : 'left', lineHeight: 24 }}>
 {trT(" إجازة مرضية لمدة {0} أيام\\n من: {1}\\n رمز QR فريد للتحقق", " {0}-day sick leave\\n From: {1}\\n Unique QR code for verification", [days, from])}
 </Text>
 </NCard>
 <Text style={{ fontSize: FS['5xl'] }}></Text>
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: 'center', marginTop: SP.md }}>
 {tr('تم إرسال الإجازة للمريض عبر QR Code ورسالة نصية', 'Sick leave sent to patient via QR Code & SMS')}
 </Text>
 <NBtn label={tr('رجوع', 'Back')} onPress={onBack} style={{ marginTop: SP.xxl }} />
 </View>
 );
 }

 return (
 <NScroll>
 <NHeader title={tr(' إجازة مرضية رقمية', ' Digital Sick Leave')} onBack={onBack} />

 <NCard style={{ marginBottom: SP.xl, flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, alignItems: 'center' }}>
 <NAvatar name={apt?.patient ?? '—'} size={44} />
 <View>
 <Text style={{ fontWeight: FW.bold, color: theme.text }}>{apt?.patient ?? '—'}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>{tr('تاريخ اليوم:', 'Today:')} {from}</Text>
 </View>
 </NCard>

 <NInput label={tr('التشخيص', 'Diagnosis')}  placeholder={tr('سبب الإجازة الطبية', 'Medical reason for leave')}
 value={diag} onChange={setDiag} icon="" required />

 <NInput label={tr('تاريخ البداية', 'Start Date')} placeholder="YYYY-MM-DD"
 value={from} onChange={setFrom} icon="" />

 <View style={{ marginBottom: SP.lg }}>
 <Text style={{ fontSize: FS.sm, fontWeight: FW.semi, color: theme.text,
 textAlign: AR ? 'right' : 'left', marginBottom: SP.sm }}>
 {tr('عدد الأيام', 'Number of Days')}
 </Text>
 <View style={{ flexDirection: 'row', gap: SP.sm, flexWrap: 'wrap' }}>
 {['1','2','3','5','7','10','14'].map(d => (
 <TouchableOpacity key={d} onPress={() => setDays(d)}
 style={[styles.dayChip2, {
 backgroundColor: days === d ? theme.primary : theme.surface2,
 borderColor: days === d ? theme.primary : theme.border,
 }]}>
 <Text style={{ color: days === d ? '#FFF' : theme.text, fontWeight: FW.bold }}>
 {d} {AR ? (d==='1'?'يوم':'أيام') : (d==='1'?'day':'days')}
 </Text>
 </TouchableOpacity>
 ))}
 </View>
 </View>

 <NCard style={{ backgroundColor: theme.infoBg, marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.sm, color: theme.info, textAlign: AR ? 'right' : 'left', lineHeight: 20 }}>
 {tr('لن تُصدر الإجازة إلا بعد تأكيد الخادم للطلب والمريض والعقد التشغيلي المعتمد.', 'The leave is issued only after the server confirms the request, patient, and approved operational contract.')}
 </Text>
 </NCard>

 <NBtn label={tr(' إصدار وإرسال الإجازة', ' Issue & Send Sick Leave')}
 disabled={!diag.trim()}
 onPress={async () => {
   if (!apt?.id || !apt?.patient_id) {
     show(tr('لا يمكن إصدار إجازة دون طلب ومريض مرتبطين.', 'A linked request and patient are required to issue sick leave.'), 'error');
     return;
   }
   try {
     await client.post(`/provider/requests/${apt.id}/sick-leave`, {
       patient_id: apt.patient_id,
       diagnosis: diag,
       start_date: from,
       duration_days: parseInt(days)
     });
     show(tr('تم إصدار الإجازة المرضية بنجاح', 'Sick leave issued successfully'), 'success');
     setIssued(true);
   } catch (err) {
     show(tr('تعذر إصدار الإجازة المرضية من الخادم.', 'The server could not issue the sick leave.'), 'error');
   }
 }} />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// REFERRAL SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function ReferralScreen({ apt, onBack }:
 { apt: any; onBack: () => void }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const { show } = useToast();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
  const [spec, setSpec] = useState('');
  const [reason, setReason] = useState('');
  const [urgent, setUrgent] = useState(false);
  const [viewMode, setViewMode] = useState<'create'|'track'>('create');
  const referrals: any[] = [];
 
  return (
  <NScroll>
  <NHeader title={tr(' تحويل مريض', ' Patient Referral')} onBack={onBack} />
 
  {/* Tab Switcher */}
  <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, paddingHorizontal: SP.xl, marginBottom: SP.lg }}>
  <TouchableOpacity onPress={() => setViewMode('create')} style={{ flex: 1, paddingVertical: SP.sm, borderBottomWidth: 2, borderBottomColor: viewMode === 'create' ? theme.primary : 'transparent', alignItems: 'center' }}>
  <Text style={{ color: viewMode === 'create' ? theme.primary : theme.textSub, fontWeight: FW.bold }}>{tr('إنشاء تحويل', 'Create Referral')}</Text>
  </TouchableOpacity>
  <TouchableOpacity onPress={() => setViewMode('track')} style={{ flex: 1, paddingVertical: SP.sm, borderBottomWidth: 2, borderBottomColor: viewMode === 'track' ? theme.primary : 'transparent', alignItems: 'center' }}>
  <Text style={{ color: viewMode === 'track' ? theme.primary : theme.textSub, fontWeight: FW.bold }}>{tr('متابعة التحويلات', 'Track Referrals')}</Text>
  </TouchableOpacity>
  </View>

  {viewMode === 'track' ? (
  <View style={{ paddingHorizontal: SP.xl }}>
  {referrals.length === 0 ? <NEmpty title={tr('لا توجد إحالات معروضة حتى يتم ربط سجل الإحالات بعقد خادم موثق.', 'No referrals are shown until referral history is connected to a verified server contract.')} icon="document" /> : referrals.map(r => (
  <NCard key={r.id} style={{ marginBottom: SP.md }}>
  <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SP.xs }}>
  <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text }}>{r.patientName}</Text>
  <NBadge label={AR ? r.statusAr : r.status.toUpperCase()} variant={r.status === AppointmentStatus.COMPLETED ? 'success' : r.status === 'accepted' ? 'primary' : 'warning'} size="xs" />
  </View>
  <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('الجهة:', 'Target:')} {r.target}</Text>
  <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{r.test} — {r.date}</Text>
  </NCard>
  ))}
  </View>
  ) : (
  <View>
  <NCard style={{ marginBottom: SP.xl, flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, alignItems: 'center' }}>
  <NAvatar name={apt?.patient ?? '—'} size={44} />
  <View>
  <Text style={{ fontWeight: FW.bold, color: theme.text }}>{apt?.patient ?? '—'}</Text>
  <Text style={{ fontSize: FS.xs, color: theme.textSub }}>{new Date().toLocaleDateString('ar-SA')}</Text>
  </View>
  </NCard>

  <View style={{ marginBottom: SP.lg }}>
  <Text style={{ fontSize: FS.sm, fontWeight: FW.semi, color: theme.text, textAlign: AR ? 'right' : 'left', marginBottom: SP.sm }}>
  {tr('تحويل إلى تخصص', 'Refer to Specialty')}<Text style={{ color: theme.danger }}> *</Text>
  </Text>
  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: SP.sm }}>
  {SPECIALTIES.slice(0, 12).map(s => (
  <TouchableOpacity key={s.id} onPress={() => setSpec(s.id)}
  style={[styles.specChip, {
  backgroundColor: spec === s.id ? theme.primaryLight : theme.surface2,
  borderColor: spec === s.id ? theme.primary : theme.border,
  }]}>
  <Text style={{ fontSize: 16 }}>{s.icon}</Text>
  <Text style={{ fontSize: FS.xs, color: spec === s.id ? theme.primary : theme.text,
  fontWeight: spec === s.id ? FW.bold : FW.reg }}>
  {AR ? s.ar : s.en}
  </Text>
  </TouchableOpacity>
  ))}
  </View>
  </View>


  <NInput label={tr('سبب التحويل', 'Reason for Referral')}
  placeholder={tr('اشرح سبب التحويل ومعلومات ذات صلة...', 'Explain the reason and relevant information...')}
  value={reason} onChange={setReason} multi lines={4} icon="" required />

  <NToggle label={tr(' تحويل عاجل', ' Urgent Referral')}
  sub={tr('يتطلب موعداً خلال 24-48 ساعة', 'Requires appointment within 24-48 hours')}
  value={urgent} onChange={setUrgent} />

  <View style={{ height: SP.xl }} />

  <NBtn label={tr(' إرسال التحويل', ' Send Referral')}
  disabled={!spec || !reason.trim()}
  onPress={async () => {
  try {
  if (!apt?.patient_id) {
    show(tr('لا يمكن إنشاء الإحالة دون مريض مرتبط', 'Cannot create a referral without a linked patient'), 'error');
    return;
  }
  await client.post('/provider/features/referrals', {
  target_type: spec,
  notes: reason,
  patient_id: apt.patient_id,
  urgent
  });
  show(tr('تم إرسال التحويل بعد تأكيد الخادم.', 'Referral sent after server confirmation.'), 'success');
  setSpec('');
  setReason('');
  } catch(e) {
  show(tr('حدث خطأ أثناء إرسال التحويل', 'Failed to send referral'), 'error');
  }
  }} />
  </View>
  )}
  </NScroll>
  );
}



// ══════════════════════════════════════════════════════════════════════════════
// REQUEST TEST SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function RequestTestScreen({ apt, onBack }:
 { apt: any; onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [type, setType] = useState<'lab'|'radiology'|'nursing'>(apt?.initialType || 'lab');
 const [selected, setSelected] = useState<string[]>([]);
 const [notes, setNotes] = useState('');

 const { LAB_TESTS, RAD_SCANS, NURSING_SVCS } = require('../../constants');
 const items = type === 'lab' ? LAB_TESTS : type === 'radiology' ? RAD_SCANS : NURSING_SVCS;

 const toggle = (id: string) => {
 setSelected(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
 };

 return (
 <NScroll>
 <NHeader title={tr('🩺 طلب خدمات طبية', '🩺 Request Medical Services')} onBack={onBack} />

 {/* Type toggle */}
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.sm, marginBottom: SP.xl }}>
 {[{ k:'lab', ar:' تحاليل', en:' Lab Tests' }, { k:'radiology', ar:' أشعة', en:' Radiology' }, { k:'nursing', ar:' تمريض', en:' Nursing' }].map(t => (
 <TouchableOpacity key={t.k} onPress={() => { setType(t.k as any); setSelected([]); }}
 style={[{ flex:1, paddingVertical:SP.md, borderRadius:R.lg, borderWidth:1.5, alignItems:'center' }, {
 backgroundColor: type===t.k ? theme.primary : theme.surface2,
 borderColor: type===t.k ? theme.primary : theme.border,
 }]}>
 <Text style={{ color: type===t.k ? '#FFF' : theme.text, fontWeight: FW.semi, fontSize: FS.sm }}>
 {AR ? t.ar : t.en}
 </Text>
 </TouchableOpacity>
 ))}
 </View>

 {selected.length > 0 && (
 <NCard style={{ backgroundColor: theme.successBg, marginBottom: SP.lg }}>
 <Text style={{ color: theme.success, fontSize: FS.sm, textAlign: AR ? 'right' : 'left' }}>
 {selected.length} {tr('بنود مختارة', 'items selected')}
 </Text>
 </NCard>
 )}

 {items.map((item: any) => (
 <TouchableOpacity key={item.id} onPress={() => toggle(item.id)}>
 <NCard style={{ marginBottom: SP.sm }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
 <View style={[styles.insureCheck, {
 backgroundColor: selected.includes(item.id) ? theme.primary : 'transparent',
 borderColor: selected.includes(item.id) ? theme.primary : theme.border,
 }]}>
 {selected.includes(item.id) && <Text style={{ color:'#FFF',fontSize:11,fontWeight:'700' }}></Text>}
 </View>
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.md, color: theme.text, fontWeight: FW.med,
 textAlign: AR ? 'right' : 'left' }}>{AR ? item.ar : item.en}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, marginTop: 2 }}>
 ⏱ {item.hours} {tr('ساعة', 'hr')}{item.fasting ? ` · ${tr('صيام مطلوب', 'Fasting required')}` : ''}
 </Text>
 </View>
 </View>
 </NCard>
 </TouchableOpacity>
 ))}

 <View style={{ height: SP.xl }} />
 <NInput label={tr('تعليمات إضافية', 'Additional Instructions')}
 value={notes} onChange={setNotes} multi lines={3} icon="" />

 <NBtn label={tr(' إرسال الطلب', ' Send Request')}
 disabled={selected.length === 0}
 onPress={async () => { 
 try {
      const patientId = apt?.patient_id;
      if (!patientId) {
        show(tr('لا يمكن إرسال الطلب دون مريض مرتبط بالاستشارة', 'Cannot request services without a linked patient'), 'error');
        return;
      }
      const endpoint = type === 'lab' ? '/labs/bookings' : type === 'radiology' ? '/radiology/bookings' : '/home-care/bookings';
      await client.post(endpoint, {
        items: selected,
        notes: notes,
        patient_id: patientId
      });
 show(trT("تم إرسال طلب {0} فحص ", "{0} test(s) requested ", [selected.length]),'success'); 
 onBack(); 
 } catch(e) {
 show(tr('حدث خطأ أثناء إرسال الطلب', 'Failed to submit request'),'error');
 }
 }} />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// PATIENT FILE SCREEN
// ══════════════════════════════════════════════════════════════════════════════
function PatientFileScreen({ patient, onBack }:
 { patient: any; onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [activeSection, setActive] = useState('overview');

 // Client CRM States
 const [isVip, setIsVip] = useState(patient?.insurance?.includes('VIP') || false);
 const [isBlocked, setIsBlocked] = useState(false);
 const [isFavorite, setIsFavorite] = useState(false);
 const [customTags, setCustomTags] = useState<string[]>(
 AR ? ['مريض دائم', 'متابعة سكري'] : ['Regular Patient', 'Diabetes Follow-up']
 );
 const [newTag, setNewTag] = useState('');
 const [crmNotes, setCrmNotes] = useState<Array<{ id: string; date: string; text: string }>>([
 { id: '1', date: '2026-06-10', text: tr('يحتاج معاملة خاصة وتهيئة سريعة قبل الدخول', 'Needs special care and fast checkout on entry') },
 { id: '2', date: '2026-06-15', text: tr('يفضل الزيارات المنزلية الصباحية', 'Prefers morning home visits') }
 ]);
 const [newNote, setNewNote] = useState('');

 const sections = [
 { k:'overview', ar:'نظرة عامة', en:'Overview' },
 { k:'crm', ar:'إدارة العميل (CRM)', en:'Client CRM' },
 { k:'visits', ar:'الزيارات', en:'Visits' },
 { k:'rx', ar:'الوصفات', en:'Rx' },
 { k:'labs', ar:'التحاليل', en:'Labs' },
 { k:'allergies',ar:'الحساسية', en:'Allergies' },
 ];

 const handleAddTag = () => {
 if (!newTag.trim()) return;
 if (customTags.includes(newTag.trim())) {
 show(tr('الوسم مضاف بالفعل', 'Tag already exists'), 'warning');
 return;
 }
 setCustomTags([...customTags, newTag.trim()]);
 setNewTag('');
 show(tr('تم إضافة الوسم', 'Tag added successfully'), 'success');
 };

 const handleRemoveTag = (tag: string) => {
 setCustomTags(customTags.filter(t => t !== tag));
 show(tr('تم حذف الوسم', 'Tag removed'), 'info');
 };

 const handleAddNote = () => {
 if (!newNote.trim()) return;
 const dateStr = new Date().toISOString().split('T')[0];
 setCrmNotes([{ id: Date.now().toString(), date: dateStr, text: newNote.trim() }, ...crmNotes]);
 setNewNote('');
 show(tr('تم حفظ ملاحظة CRM', 'CRM Note saved'), 'success');
 };

 const handleToggleVip = (val: boolean) => {
 setIsVip(val);
 show(val ? (tr('تم ترقية المريض إلى VIP ', 'Patient upgraded to VIP ')) : (tr('تم إلغاء حالة VIP', 'VIP status removed')), 'success');
 };

 const handleToggleFavorite = (val: boolean) => {
 setIsFavorite(val);
 show(val ? (tr('تم الإضافة للمفضلة ', 'Added to favorites ')) : (tr('تم الإزالة من المفضلة', 'Removed from favorites')), 'success');
 };

 const handleToggleBlocked = (val: boolean) => {
 setIsBlocked(val);
 show(val ? (tr('تم إدراج المريض في الحظر ', 'Patient added to blocklist ')) : (tr('تم إلغاء الحظر', 'Patient unblocked')), 'warning');
 };

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NScroll>
 <NHeader title={tr(' ملف المريض', ' Patient File')} onBack={onBack} />

 {/* Patient info */}
 <NCard style={{ marginBottom: SP.xl }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.lg, alignItems: 'center' }}>
 <NAvatar name={patient?.patient ?? 'مريض'} size={60} />
 <View style={{ flex: 1 }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.xs }}>
 <Text style={{ fontSize: FS.xl, fontWeight: FW.bold, color: theme.text,
 textAlign: AR ? 'right' : 'left' }}>{patient?.patient ?? 'أحمد محمد'}</Text>
 {isFavorite && <Text style={{ fontSize: FS.xl }}></Text>}
 </View>
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>
 {tr('العمر: 34 سنة | ذكر | فصيلة الدم: A+', 'Age: 34 | Male | Blood: A+')}
 </Text>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', flexWrap: 'wrap', gap: SP.sm, marginTop: SP.xs }}>
 
 <NBadge label={tr('مزمن: سكري', 'Chronic: Diabetes')} variant="warning" size="xs" />
 {isVip && <NBadge label="VIP " variant="success" size="xs" />}
 {isBlocked && <NBadge label={tr('محظور ', 'Blocked ')} variant="danger" size="xs" />}
 </View>
 </View>
 </View>
 </NCard>

 {/* Sections */}
 <ScrollView horizontal showsHorizontalScrollIndicator={false}
 contentContainerStyle={{ gap: SP.sm, paddingBottom: SP.sm, marginBottom: SP.xl }}>
 {sections.map(sec => (
 <TouchableOpacity key={sec.k} onPress={() => setActive(sec.k)}
 style={[styles.secTab, {
 backgroundColor: activeSection === sec.k ? theme.primary : theme.surface2,
 borderColor: activeSection === sec.k ? theme.primary : theme.border,
 }]}>
 <Text style={{ color: activeSection === sec.k ? '#FFF' : theme.text, fontSize: FS.sm, fontWeight: FW.semi }}>
 {AR ? sec.ar : sec.en}
 </Text>
 </TouchableOpacity>
 ))}
 </ScrollView>

 {/* Content by section */}
 {activeSection === 'overview' && (
 <View style={{ gap: SP.md }}>
 {[
 { ar:'أمراض مزمنة', en:'Chronic Conditions', val:'سكري النوع 2، ضغط الدم' },
 { ar:'الأدوية الحالية', en:'Current Medications', val:'Metformin 500mg، Lisinopril 10mg' },
 { ar:'الحساسية', en:'Allergies', val:'بنسيلين (Penicillin)' },
 { ar:'آخر زيارة', en:'Last Visit', val:'2025-03-15' },
 { ar:'عدد الزيارات', en:'Total Visits', val:'12 زيارة' },
 ].map((row, i) => (
 <NCard key={i} style={{ padding: SP.lg }}>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{AR ? row.ar : row.en}</Text>
 <Text style={{ fontSize: FS.md, fontWeight: FW.semi, color: theme.text,
 textAlign: AR ? 'right' : 'left', marginTop: SP.xs }}>{row.val}</Text>
 </NCard>
 ))}
 </View>
 )}

 {activeSection === 'crm' && (
 <View style={{ gap: SP.xl }}>
 {/* Toggles */}
 <NCard style={{ gap: SP.lg }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
 ️ {tr('حالة العميل والتصنيفات', 'Client Status & Category')}
 </Text>
 <NToggle
 label={tr('علامة عميل VIP ', 'VIP Client Badge ')}
 sub={tr('تمييز المريض ببطاقة عميل خاص في النظام', 'Highlight patient as high-priority VIP')}
 value={isVip}
 onChange={handleToggleVip}
 />
 <NDivider style={{ marginVertical: SP.xs }} />
 <NToggle
 label={tr('إضافة للمفضلة ', 'Add to Favorites ')}
 sub={tr('إظهار نجمة بجانب المريض لسهولة الوصول', 'Show star badge for quick identification')}
 value={isFavorite}
 onChange={handleToggleFavorite}
 />
 <NDivider style={{ marginVertical: SP.xs }} />
 <NToggle
 label={tr('حظر هذا المريض ', 'Block this Patient ')}
 sub={tr('منع المريض من إرسال طلبات حجز جديدة إليك', 'Prevent patient from booking future slots with you')}
 value={isBlocked}
 onChange={handleToggleBlocked}
 />
 </NCard>

 {/* Block Warning Card */}
 {isBlocked && (
 <NCard style={{ backgroundColor: theme.dangerBg, borderColor: theme.danger }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
 <Text style={{ fontSize: 24 }}></Text>
 <Text style={{ flex: 1, fontSize: FS.sm, color: theme.danger, fontWeight: FW.bold, textAlign: AR ? 'right' : 'left' }}>
 {tr('المريض محظور حالياً ولا يمكنه تقديم طلب استشارة أو كشف لديك.', 'Patient is currently blocked and cannot send you consultation requests.')}
 </Text>
 </View>
 </NCard>
 )}

 {/* Custom CRM Tags */}
 <NCard style={{ gap: SP.md }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
 ️ {tr('الأوسمة والوسوم المخصصة', 'Custom CRM Tags')}
 </Text>
 
 {/* Tags List */}
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', flexWrap: 'wrap', gap: SP.xs, marginVertical: SP.xs }}>
 {customTags.map((tag, idx) => (
 <TouchableOpacity
 key={idx}
 onPress={() => handleRemoveTag(tag)}
 style={{
 flexDirection: AR ? 'row-reverse' : 'row',
 alignItems: 'center',
 backgroundColor: theme.primaryLight,
 paddingHorizontal: SP.md,
 paddingVertical: 4,
 borderRadius: R.full,
 gap: 4
 }}
 >
 <Text style={{ color: theme.primary, fontSize: FS.xs, fontWeight: FW.bold }}>{tag}</Text>
 <Text style={{ color: theme.primary, fontSize: 10 }}>×</Text>
 </TouchableOpacity>
 ))}
 {customTags.length === 0 && (
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>
 {tr('لا توجد وسوم مخصصة حالياً.', 'No custom tags applied.')}
 </Text>
 )}
 </View>

 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, alignItems: 'center' }}>
 <View style={{ flex: 1 }}>
 <NInput
 placeholder={tr('أضف وسماً (مثال: متعاون، مدخن)', 'Add tag (e.g. Cooperative, Smoker)')}
 value={newTag}
 onChange={setNewTag}
 />
 </View>
 <TouchableOpacity
 onPress={handleAddTag}
 style={{
 backgroundColor: theme.primary,
 width: 44,
 height: 44,
 borderRadius: R.md,
 alignItems: 'center',
 justifyContent: 'center'
 }}
 >
 <Text style={{ color: '#FFF', fontSize: 24, fontWeight: FW.bold }}>+</Text>
 </TouchableOpacity>
 </View>
 </NCard>

 {/* Provider Private Notes */}
 <NCard style={{ gap: SP.md }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
 {tr('ملاحظات العيادة الخاصة', 'Private CRM Clinic Notes')}
 </Text>

 <NInput
 placeholder={tr('اكتب ملاحظة خاصة عن المريض (سرية ولن تظهر له)...', 'Write a private note (confidential, hidden from patient)...')}
 value={newNote}
 onChange={setNewNote}
 multi
 lines={3}
 />
 <NBtn
 label={tr('حفظ الملاحظة', 'Save Note')}
 onPress={handleAddNote}
 disabled={!newNote.trim()}
 />

 <NDivider style={{ marginVertical: SP.sm }} />

 <View style={{ gap: SP.md }}>
 {crmNotes.map(note => (
 <View
 key={note.id}
 style={{
 backgroundColor: theme.surface2,
 padding: SP.md,
 borderRadius: R.md,
 borderLeftWidth: AR ? 0 : 3,
 borderRightWidth: AR ? 3 : 0,
 borderColor: theme.primary
 }}
 >
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', marginBottom: 4 }}>
 <Text style={{ fontSize: 10, color: theme.textSub }}>{note.date}</Text>
 <Text style={{ fontSize: 10, color: theme.primary, fontWeight: FW.bold }}>{tr('طبيب', 'Doctor')}</Text>
 </View>
 <Text style={{ fontSize: FS.sm, color: theme.text, textAlign: AR ? 'right' : 'left', lineHeight: 18 }}>
 {note.text}
 </Text>
 </View>
 ))}
 </View>
 </NCard>
 </View>
 )}

 {activeSection === 'visits' && (
 <View>
 {[
 { date:'2025-03-15', type:'video', diagnosis:'ضغط دم مرتفع', doctor:'د. محمد' },
 { date:'2025-01-20', type:'clinic', diagnosis:'فحص روتيني سكري', doctor:'د. محمد' },
 { date:'2024-11-05', type:'home', diagnosis:'التهاب مجاري بولية', doctor:'د. محمد' },
 ].map((visit, i) => (
 <NCard key={i} style={{ marginBottom: SP.md }}>
 <Text style={{ fontSize: FS.xs, color: theme.primary }}>{visit.date}</Text>
 <Text style={{ fontSize: FS.md, fontWeight: FW.semi, color: theme.text,
 textAlign: AR ? 'right' : 'left', marginVertical: SP.xs }}>{visit.diagnosis}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>
 {visit.type === 'video' ? '' : visit.type === 'clinic' ? '' : ''} {visit.doctor}
 </Text>
 </NCard>
 ))}
 </View>
 )}
 </NScroll>
 </View>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// NO-SHOW MANAGEMENT SCREEN
// ══════════════════════════════════════════════════════════════════════════════
function NoShowManagementScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [cancelFee, setCancelFee] = useState('50');
 const [noShowFee, setNoShowFee] = useState('100');
 const [waitlist, setWaitlist] = useState(true);
 const [autoRemind, setAutoRemind] = useState(true);

 return (
 <NScroll>
 <NHeader title={tr(' إدارة الغياب والإلغاء', ' No-Show Management')} onBack={onBack} />

 <NCard style={{ marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text,
 marginBottom: SP.lg, textAlign: AR ? 'right' : 'left' }}>
 {tr('رسوم الإلغاء والغياب', 'Cancellation & No-Show Fees')}
 </Text>
 <NPriceInput label={tr('رسوم الإلغاء المتأخر (أقل من 2 ساعة)', 'Late Cancel Fee (< 2hr)')}
 value={cancelFee} onChange={setCancelFee} />
 <NPriceInput label={tr('رسوم الغياب التام (No-Show)', 'No-Show Fee')}
 value={noShowFee} onChange={setNoShowFee} />
 <NCard style={{ backgroundColor: theme.infoBg, padding: SP.md }}>
 <Text style={{ fontSize: FS.xs, color: theme.info, lineHeight: 18 }}>
 {tr(' تساعد رسوم الإلغاء على تقليل الغياب بنسبة 40% وفق إحصاءات المنصة.', ' Cancellation fees reduce no-shows by 40% per platform statistics.')}
 </Text>
 </NCard>
 </NCard>

 <NCard style={{ marginBottom: SP.xl }}>
 <NToggle label={tr(' قائمة الانتظار الذكية', ' Smart Waitlist')}
 sub={tr('ملء المواعيد الملغاة تلقائياً من قائمة الانتظار', 'Auto-fill cancelled slots from waitlist')}
 value={waitlist} onChange={setWaitlist} />
 <NToggle label={tr(' تذكيرات متعددة المراحل', ' Multi-Stage Reminders')}
 sub={tr('قبل 24 ساعة، ساعتين، 30 دقيقة', '24hr, 2hr, 30min before appointment')}
 value={autoRemind} onChange={setAutoRemind} />
 </NCard>

 {/* Recent no-shows */}
 <NSecHeader title={tr('حالات الغياب الأخيرة', 'Recent No-Shows')} />
 {['أحمد السالم', 'سارة المطيري', 'فيصل الحربي'].map((name, i) => (
 <NCard key={i} style={{ marginBottom: SP.sm, flexDirection: AR ? 'row-reverse' : 'row',
 alignItems: 'center', gap: SP.md, padding: SP.lg }}>
 <NAvatar name={name} size={36} />
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.md, color: theme.text, textAlign: AR ? 'right' : 'left' }}>{name}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>{tr('غياب', 'No-Show')} · 2025-0{i+2}-{10+i}</Text>
 </View>
 <NBadge label={`${noShowFee} ${tr('ر', 'SAR')}`} variant="danger" size="xs" />
 </NCard>
 ))}

 <View style={{ height: SP.xl }} />
 <NBtn label={tr(' حفظ الإعدادات', ' Save Settings')}
 onPress={() => { show(tr('تم حفظ إعدادات الغياب', 'Settings saved'), 'success'); onBack(); }} />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// WALLET TAB
// ══════════════════════════════════════════════════════════════════════════════
function DoctorWalletTab({ onNavigate }: { onNavigate: (s: string) => void }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
  
  const [wallet, setWallet] = useState({ available: 0, escrow: 0, dues: 0 });
  const [transactions, setTransactions] = useState<any[]>([]);
  const [walletError, setWalletError] = useState(false);
  
  useEffect(() => {
    const fetchWallet = async () => {
      try {
        const res = await client.get('/provider/wallet');
        if (res.data) setWallet(res.data);
        const txRes = await client.get('/provider/wallet/transactions');
        setTransactions(txRes.data || []);
      } catch (err) {
        setWallet({ available: 0, escrow: 0, dues: 0 });
        setTransactions([]);
        setWalletError(true);
      }
    };
    fetchWallet();
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <View style={[styles.topBar, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
        <Text style={{ fontSize: FS.xl, fontWeight: FW.bold, color: theme.text }}>
          {tr('المحفظة والإيرادات', 'Wallet & Revenue')}
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: SP.lg, gap: SP.md }}>
        {walletError && (
          <NCard style={{ backgroundColor: theme.danger + '15' }}>
            <Text style={{ color: theme.danger, textAlign: AR ? 'right' : 'left' }}>{tr('تعذر تحميل المحفظة. لا تُعرض أي أرصدة أو عمليات بديلة.', 'Wallet data could not be loaded. No substitute balances or transactions are shown.')}</Text>
          </NCard>
        )}
        <NStatCard label={tr('الرصيد المتاح للسحب', 'Available for Withdrawal')} value={`${wallet.available} SAR`} icon="wallet" />
        <NStatCard label={tr('مبالغ معلقة التأمين', 'Insurance Escrow')} value={`${wallet.escrow} SAR`} icon="shield" color={theme.warn} />
        <NStatCard label={tr('مستحقات المنصة / المديونية', 'Nabdah Dues')} value={`${wallet.dues} SAR`} icon="info" color={theme.danger} />
        
        <NBtn label={tr('طلب سحب رصيد', 'Withdraw Funds')} icon="money" onPress={() => onNavigate('withdrawal_workflow')} style={{ marginTop: SP.md }} />
        <NBtn label={tr('التقارير والإحصائيات', 'Revenue Insights & Reports')} variant="outline" onPress={() => onNavigate('revenue_insights')} style={{ marginTop: SP.sm }} />
        
        <NCard style={{ marginTop: SP.xl, backgroundColor: theme.infoBg }}>
          <Text style={{ fontSize: FS.sm, color: theme.info, textAlign: AR ? 'right' : 'left', lineHeight: 20 }}>
            {tr('عمولة المنصة: 15% من كل معاملة يتم تحصيلها نقداً أو عبر التأمين.\nيتم إيقاف الحساب تلقائياً إذا تجاوزت المديونية -500 ريال.', 'Platform commission: 15% per transaction.\nAccount is automatically suspended if dues exceed -500 SAR.')}
          </Text>
        </NCard>

        <View style={{ marginTop: SP.xl }}>
          <NSecHeader title={tr('سجل العمليات الأخير', 'Recent Transactions')} />
        </View>
        {transactions.map(tx => (
          <NCard key={tx.id} style={{ marginBottom: SP.sm }}>
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View style={{ flex: 1, alignItems: AR ? 'flex-end' : 'flex-start' }}>
                <Text style={{ fontSize: FS.md, fontWeight: FW.semi, color: theme.text }}>{tx.title}</Text>
                <Text style={{ fontSize: FS.xs, color: theme.textSub, marginTop: 4 }}>{tx.date}</Text>
              </View>
              <Text style={{ fontSize: FS.lg, fontWeight: FW.bold, color: tx.type === 'CREDIT' ? theme.success : theme.danger }}>
                {tx.type === 'CREDIT' ? '+' : ''}{tx.amount} {tr('ر', 'SAR')}
              </Text>
            </View>
          </NCard>
        ))}
        {transactions.length === 0 && (
          <NEmpty title={tr('لا توجد عمليات', 'No Transactions')} sub={tr('لم تقم بأي عمليات مالية بعد', 'You have no financial transactions yet.')} icon="wallet" />
        )}
      </ScrollView>
    </View>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// CHAT TAB (placeholder — full chat in Phase 6)
// ══════════════════════════════════════════════════════════════════════════════

function DoctorChatTab() {
  const { theme } = useTheme();
  const { lang } = useLang();
  const { show } = useToast();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

  const [chats, setChats] = useState<any[]>([]);
  const [activeChat, setActiveChat] = useState<any | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchChats = async () => {
      setLoading(true);
      try {
        const res = await client.get('/chats/threads');
        setChats(res.data || []);
      } catch (err) {
        setChats([]);
        show(tr('تعذر تحميل المحادثات الطبية. لا تُعرض محادثات بديلة.', 'Medical chats could not be loaded. No substitute chats are shown.'), 'error');
      } finally {
        setLoading(false);
      }
    };
    fetchChats();
  }, []);

  const openChat = async (chat: any) => {
    setActiveChat(chat);
    try {
      const res = await client.get(`/chats/threads/${chat.id}/messages`);
      setMessages(res.data || []);
    } catch {
      setMessages([]);
    }
  };

  const sendMessage = async () => {
    if (!msg.trim() || !activeChat) return;
    const sentText = msg;
    try {
      await client.post(`/chats/threads/${activeChat.id}/messages`, { body: sentText });
      setMsg('');
      const refreshed = await client.get(`/chats/threads/${activeChat.id}/messages`);
      setMessages(refreshed.data || []);
    } catch {
      show(tr('لم تُثبت الرسالة من الخادم. حاول مرة أخرى.', 'The message was not confirmed by the server. Please try again.'), 'error');
    }
  };

  // ── Active Chat View ──────────────────────────────────────────────────────
  if (activeChat) {
    const isClosed = activeChat.status === 'CLOSED';
    return (
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: theme.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
        {/* Header */}
        <View style={[styles.topBar, { backgroundColor: theme.surface, borderBottomColor: theme.border, flexDirection: AR ? 'row-reverse' : 'row' }]}>
          <TouchableOpacity onPress={() => setActiveChat(null)} style={{ padding: SP.xs }}>
            <I name={AR ? 'chevronRight' : 'chevronLeft'} size={24} color={theme.primary} />
          </TouchableOpacity>
          <View style={{ flex: 1, flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
            <NAvatar name={activeChat.patient_name} size={40} />
            <View>
              <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text }}>{activeChat.patient_name}</Text>
              <Text style={{ fontSize: FS.xs, color: activeChat.status === 'OPEN' ? theme.success : theme.textSub }}>
                {activeChat.status === 'OPEN' ? (tr('محادثة نشطة', 'Active')) :
                 activeChat.status === 'FOLLOW_UP' ? (tr('متابعة', 'Follow-up')) : (tr('مغلقة', 'Closed'))}
              </Text>
            </View>
          </View>
          {!isClosed && (
            <TouchableOpacity onPress={() => show(tr('بدء المكالمة غير متاح من هذه الشاشة حتى يكتمل عقد الجلسة المعتمد.', 'Call start is unavailable here until the approved session contract is complete.'), 'error')} style={{ padding: SP.xs }}>
              <I name="video" size={22} color={theme.primary} />
            </TouchableOpacity>
          )}
        </View>

        {/* Messages */}
        <ScrollView contentContainerStyle={{ padding: SP.lg, paddingBottom: 20 }} showsVerticalScrollIndicator={false}>
          {messages.map(m => {
            const isMe = m.sender === 'provider';
            return (
              <View key={m.id} style={{ alignItems: isMe ? 'flex-end' : 'flex-start', marginBottom: SP.md }}>
                <View style={{
                  maxWidth: '80%', borderRadius: R.lg, padding: SP.md,
                  backgroundColor: isMe ? theme.primary : theme.card,
                  borderBottomRightRadius: isMe ? 4 : R.lg,
                  borderBottomLeftRadius: isMe ? R.lg : 4,
                }}>
                  <Text style={{ color: isMe ? '#FFF' : theme.text, fontSize: FS.md, lineHeight: 22, textAlign: AR ? 'right' : 'left' }}>{m.text}</Text>
                </View>
                <Text style={{ fontSize: 10, color: theme.textSub, marginTop: 2 }}>{m.time}</Text>
              </View>
            );
          })}
        </ScrollView>

        {/* Input */}
        {!isClosed ? (
          <View style={{ backgroundColor: theme.surface, borderTopColor: theme.border, borderTopWidth: 1, flexDirection: AR ? 'row-reverse' : 'row', paddingBottom: 24, padding: SP.md, gap: SP.sm }}>
            <TextInput
              style={{ flex: 1, backgroundColor: theme.surface2, borderRadius: R.xl, paddingHorizontal: SP.lg, paddingVertical: SP.sm, fontSize: FS.md, color: theme.text, textAlign: AR ? 'right' : 'left', maxHeight: 100 }}
              placeholder={tr('اكتب رسالة...', 'Type a message...')}
              placeholderTextColor={theme.textSub}
              value={msg} onChangeText={setMsg} multiline
            />
            <TouchableOpacity onPress={sendMessage} disabled={!msg.trim()}
              style={{ width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: msg.trim() ? theme.primary : theme.surface2 }}>
              <I name="forward" size={20} color={msg.trim() ? '#FFF' : theme.textSub} />
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ padding: SP.lg, backgroundColor: theme.surface2, alignItems: 'center' }}>
            <Text style={{ color: theme.textSub, fontSize: FS.sm }}>{tr('هذه المحادثة مغلقة (أرشيف طبي للقراءة فقط)', 'Conversation closed (read-only medical archive)')}</Text>
          </View>
        )}
      </KeyboardAvoidingView>
    );
  }

  // ── Chat List View ────────────────────────────────────────────────────────
  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <View style={[styles.topBar, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
        <Text style={{ fontSize: FS.xl, fontWeight: FW.bold, color: theme.text }}>
          {tr(' الرسائل والمحادثات', ' Messages & Chats')}
        </Text>
        <NBadge label={String(chats.reduce((a, c) => a + (c.unread || 0), 0))} variant="danger" size="xs" />
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: theme.textSub }}>{tr('جارٍ تحميل المحادثات...', 'Loading chats...')}</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: SP.lg, gap: SP.sm }}>
          {chats.map(c => {
            const isFollowUp = c.status === 'FOLLOW_UP';
            const isClosed = c.status === 'CLOSED';
            const isOpen = c.status === 'OPEN';
            return (
              <TouchableOpacity key={c.id} onPress={() => openChat(c)} activeOpacity={0.8}>
                <NCard style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md, padding: SP.lg, borderLeftWidth: isFollowUp ? 3 : 0, borderLeftColor: theme.primary, opacity: isClosed ? 0.7 : 1 }}>
                  <View style={{ position: 'relative' }}>
                    <NAvatar name={c.patient_name} size={50} />
                    {isOpen && <View style={{ position: 'absolute', bottom: 0, right: 0, width: 12, height: 12, borderRadius: 6, backgroundColor: theme.success, borderWidth: 2, borderColor: theme.card }} />}
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Text style={{ fontSize: FS.md, fontWeight: c.unread > 0 ? FW.bold : FW.reg, color: theme.text }}>{c.patient_name}</Text>
                      <NBadge
                        label={isOpen ? (tr('نشط', 'Open')) : isFollowUp ? (tr('متابعة', 'Follow-up')) : (tr('مغلق', 'Closed'))}
                        variant={isOpen ? 'success' : isFollowUp ? 'primary' : 'default'}
                        size="xs"
                      />
                    </View>
                    <Text style={{ fontSize: FS.sm, color: theme.textSub, marginTop: 4, textAlign: AR ? 'right' : 'left' }} numberOfLines={1}>
                      {c.last_message || (tr('اضغط للفتح', 'Tap to open'))}
                    </Text>
                  </View>
                  {c.unread > 0 && (
                    <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: theme.primary, alignItems: 'center', justifyContent: 'center' }}>
                      <Text style={{ color: '#FFF', fontSize: 11, fontWeight: 'bold' }}>{c.unread}</Text>
                    </View>
                  )}
                </NCard>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      )}
    </View>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SETTINGS TAB
// ══════════════════════════════════════════════════════════════════════════════

function DoctorSettingsTab({ onLogout, onNavigate }: { onLogout: () => void, onNavigate: (s: string) => void }) {
  const { theme, mode, toggle: toggleTheme } = useTheme();
  const { lang, toggle: toggleLang } = useLang();
  const { show } = useToast();
  const { user } = useAuth();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
  
  // Mock facility link state
  const isLinkedToFacility = !!(user as any)?.parent_facility_id;
  const facilityName = "مستشفى نبضة الطبي";

  const [clinicPrice, setClinicPrice] = useState('150');
  const [onlinePrice, setOnlinePrice] = useState('100');
  const [homePrice, setHomePrice] = useState('300');
  
  const [clinicActive, setClinicActive] = useState(true);
  const [onlineActive, setOnlineActive] = useState(true);
  const [homeActive, setHomeActive] = useState(false);

  // Mock facility permissions locking
  const isPricingLocked = isLinkedToFacility; // In real implementation, check permissions matrix

  const requestDeltaUpdate = async () => {
    try {
      await client.post('/provider/settings/delta', {
        newData: { 
          price_clinic: clinicPrice, price_online: onlinePrice, price_home: homePrice,
          active_clinic: clinicActive, active_online: onlineActive, active_home: homeActive
        }
      });
      show(tr('بانتظار موافقة الإدارة على التعديلات', 'Pending Admin Approval for Settings Delta'), 'info');
    } catch (err) {
      show(tr('فشل إرسال التعديل', 'Failed to push delta'), 'error');
    }
  };

  const handleUnlink = () => {
    // In real app: call API to nullify parent_facility_id
    show(tr('تم إرسال طلب فك الارتباط', 'Unlink request sent'), 'info');
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <NHeader title={tr('الإعدادات', 'Settings')} />
      <ScrollView contentContainerStyle={{ padding: SP.lg, gap: SP.md }}>
        
        {/* ── Facility Link ────────────────────────────────────────── */}
        {isLinkedToFacility ? (
          <NCard style={{ backgroundColor: theme.infoBg, borderColor: theme.info, borderWidth: 1 }}>
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
              <Text style={{ fontSize: 24 }}>🏛️</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: FS.sm, fontWeight: FW.bold, color: theme.info, textAlign: AR ? 'right' : 'left' }}>
                  {tr('مرتبط بمنشأة', 'Linked to Facility')}
                </Text>
                <Text style={{ fontSize: FS.xs, color: theme.info, textAlign: AR ? 'right' : 'left' }}>
                  {trT("تعمل حالياً ضمن طاقم {0}", "Currently working under {0}", [facilityName])}
                </Text>
              </View>
            </View>
            <TouchableOpacity onPress={handleUnlink} style={{ marginTop: SP.md, alignSelf: AR ? 'flex-start' : 'flex-end' }}>
              <Text style={{ color: theme.danger, fontWeight: FW.bold, fontSize: FS.xs }}>
                {tr('إنهاء الارتباط', 'Leave Facility')}
              </Text>
            </TouchableOpacity>
          </NCard>
        ) : (
          <NSettingsRow icon="document" label={tr('دعوات المنشآت (0)', 'Facility Invitations (0)')} onPress={() => onNavigate('facility_invitations')} />
        )}

        {/* ── Appearance & Language ─────────────────────────────────── */}
        <NSecHeader title={tr('المظهر واللغة', 'Appearance & Language')} />
        <NCard style={{ gap: SP.lg }}>
          <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
              <I name={mode === 'dark' ? 'moon' : 'sun'} size={20} color={theme.primary} />
              <Text style={{ fontSize: FS.md, color: theme.text }}>
                {AR ? (mode === 'dark' ? 'الوضع الليلي' : 'الوضع النهاري') : (mode === 'dark' ? 'Dark Mode' : 'Light Mode')}
              </Text>
            </View>
            <Switch value={mode === 'dark'} onValueChange={toggleTheme} trackColor={{ true: theme.primary }} />
          </View>
          <NDivider />
          <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
              <I name="globe" size={20} color={theme.primary} />
              <Text style={{ fontSize: FS.md, color: theme.text }}>
                {tr('اللغة: العربية', 'Language: English')}
              </Text>
            </View>
            <TouchableOpacity onPress={toggleLang}
              style={{ paddingHorizontal: SP.lg, paddingVertical: SP.sm, backgroundColor: theme.primaryLight, borderRadius: R.md }}>
              <Text style={{ color: theme.primary, fontWeight: FW.bold }}>{AR ? 'EN' : 'عربي'}</Text>
            </TouchableOpacity>
          </View>
        </NCard>

        {/* ── Services & Pricing ────────────────────────────────────── */}
        <NSecHeader title={tr('إعدادات الحساب', 'Account')} />
        <NCard style={{ marginBottom: SP.lg }}>
          <Text style={{ fontSize: FS.sm, fontWeight: FW.bold, marginBottom: SP.sm, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
            {tr('الخدمات المقدمة والأسعار', 'Services & Pricing')}
          </Text>
          
          <View style={{ gap: SP.md, opacity: isPricingLocked ? 0.6 : 1 }} pointerEvents={isPricingLocked ? 'none' : 'auto'}>
            {isPricingLocked && (
              <Text style={{ fontSize: FS.xs, color: theme.danger, marginBottom: SP.xs, textAlign: AR ? 'right' : 'left' }}>
                {tr('الأسعار والخدمات مقفلة ومتحكم بها من قبل المنشأة (مستشفى نبضة الطبي)', 'Pricing and services are locked and managed by the facility')}
              </Text>
            )}
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.sm }}>
                <Switch value={clinicActive} onValueChange={setClinicActive} trackColor={{ true: theme.primary }} />
                <Text style={{ color: theme.text, fontSize: FS.sm }}>{tr('كشف العيادة', 'Clinic Visit')}</Text>
              </View>
              <NInput label="" value={clinicPrice} onChange={setClinicPrice} kbType="numeric" style={{ width: 80, marginVertical: 0 }} editable={clinicActive} />
            </View>
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.sm }}>
                <Switch value={onlineActive} onValueChange={setOnlineActive} trackColor={{ true: theme.primary }} />
                <Text style={{ color: theme.text, fontSize: FS.sm }}>{tr('استشارة أونلاين', 'Online Consult')}</Text>
              </View>
              <NInput label="" value={onlinePrice} onChange={setOnlinePrice} kbType="numeric" style={{ width: 80, marginVertical: 0 }} editable={onlineActive} />
            </View>
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.sm }}>
                <Switch value={homeActive} onValueChange={setHomeActive} trackColor={{ true: theme.primary }} />
                <Text style={{ color: theme.text, fontSize: FS.sm }}>{tr('زيارة منزلية', 'Home Visit')}</Text>
              </View>
              <NInput label="" value={homePrice} onChange={setHomePrice} kbType="numeric" style={{ width: 80, marginVertical: 0 }} editable={homeActive} />
            </View>
          </View>
          
          {!isPricingLocked && <NBtn label={tr('حفظ التعديلات', 'Save Changes')} onPress={requestDeltaUpdate} style={{ marginTop: SP.md }} />}
        </NCard>

        {/* ── Profile & Configuration ───────────────────────────────── */}
        <NSecHeader title={tr('الملف الشخصي والإعدادات', 'Profile & Config')} />
        <NSettingsRow icon="user" label={tr('تعديل الملف الشخصي', 'Edit Profile')} onPress={() => onNavigate('profile_edit')} />
        <NSettingsRow icon="mapPin" label={tr('الموقع ونطاق التغطية', 'Location & Coverage')} onPress={() => onNavigate('location_config')} />
        <NSettingsRow icon="calendar" label={tr('مواعيد العمل (Scheduler)', 'Availability Engine')} onPress={() => onNavigate('availability_engine')} />
        <NSettingsRow icon="shield" label={tr('شركات التأمين', 'Insurance Config')} onPress={() => onNavigate('insurance_config')} />
        <GlobalSystemSettings />
        
        <NBtn label={tr('تسجيل الخروج', 'Logout')} onPress={onLogout} variant="outline" style={{ borderColor: theme.danger, marginTop: SP.lg }} labelStyle={{ color: theme.danger }} />
      </ScrollView>
    </View>
  );
}
export function InsuranceClaimScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 return (
  <NScroll>
   <NHeader title={tr('مطالبة تأمين', 'Insurance Claim')} onBack={onBack} />
   <View style={{ padding: SP.xl }}>
    <NCard style={{ gap: SP.md }}>
     <Text style={{ fontSize: FS.lg, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>{tr('المطالبة غير متاحة من هذه الشاشة', 'Claims are unavailable from this screen')}</Text>
     <Text style={{ color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('لا يمكن إدخال سياسة أو موافقة أو مبالغ تأمين من التطبيق. تتطلب المطالبة سياسة موثقة وطلب تأمين خادمياً قبل قرار المزود.', 'A policy, approval, or insurance amount cannot be entered from the app. A verified policy and a server-owned insurance request are required before a provider decision.')}</Text>
    </NCard>
   </View>
  </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// MEDICAL REPORT WRITER
// ══════════════════════════════════════════════════════════════════════════════
export function MedicalReportScreen({ apt, onBack }: { apt: any; onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [type, setType] = useState('');
 const [findings, setFindings] = useState('');
 const [conclusion, setConclusion] = useState('');
 const [recs, setRecs] = useState('');

 const REPORT_TYPES = [
 { ar: 'تقرير طبي عام', en: 'General Medical Report' },
 { ar: 'تقرير للعمل/الدراسة', en: 'Work / Study Report' },
 { ar: 'تقرير لتأمين السفر', en: 'Travel Insurance Report' },
 { ar: 'تقرير متابعة مزمن', en: 'Chronic Follow-up' },
 { ar: 'تقرير عيادي مفصّل', en: 'Detailed Clinical Report' },
 ];

 return (
 <NScroll>
 <NHeader title={tr(' كتابة تقرير طبي', ' Medical Report')} onBack={onBack} />

 <NCard style={{ marginBottom: SP.xl, flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, alignItems: 'center' }}>
 <NAvatar name={apt?.patient ?? 'مريض'} size={44} />
 <View>
 <Text style={{ fontWeight: FW.bold, color: theme.text }}>{apt?.patient ?? '—'}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>{new Date().toLocaleDateString('ar-SA')}</Text>
 </View>
 </NCard>

 <View style={{ marginBottom: SP.lg }}>
 <Text style={{ fontSize: FS.sm, fontWeight: FW.semi, color: theme.text,
 textAlign: AR ? 'right' : 'left', marginBottom: SP.sm }}>
 {tr('نوع التقرير', 'Report Type')}<Text style={{ color: theme.danger }}> *</Text>
 </Text>
 {REPORT_TYPES.map((t, i) => (
 <TouchableOpacity key={i} onPress={() => setType(AR ? t.ar : t.en)}
 style={[styles.rTypeRow, {
 backgroundColor: type === (AR ? t.ar : t.en) ? theme.primaryLight : theme.surface2,
 borderColor: type === (AR ? t.ar : t.en) ? theme.primary : theme.border,
 }]}>
 <Text style={{
 flex: 1, color: type === (AR ? t.ar : t.en) ? theme.primary : theme.text,
 fontWeight: type === (AR ? t.ar : t.en) ? FW.bold : FW.reg,
 textAlign: AR ? 'right' : 'left',
 }}>{AR ? t.ar : t.en}</Text>
 {type === (AR ? t.ar : t.en) && <Text style={{ color: theme.primary }}></Text>}
 </TouchableOpacity>
 ))}
 </View>

 <NInput
 label={tr('النتائج السريرية', 'Clinical Findings')}
 placeholder={tr('اذكر الأعراض والفحوصات والنتائج...', 'State symptoms, examinations and findings...')}
 value={findings} onChange={setFindings} multi lines={5} icon="" required
 />
 <NInput
 label={tr('الاستنتاج والتشخيص', 'Conclusion & Diagnosis')}
 placeholder={tr('التشخيص النهائي...', 'Final diagnosis...')}
 value={conclusion} onChange={setConclusion} multi lines={3} icon=""
 />
 <NInput
 label={tr('التوصيات والعلاج', 'Recommendations & Treatment')}
 placeholder={tr('العلاج والتوصيات...', 'Treatment and recommendations...')}
 value={recs} onChange={setRecs} multi lines={3} icon=""
 />

 <NCard style={{ backgroundColor: theme.infoBg, marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.sm, color: theme.info, textAlign: AR ? 'right' : 'left' }}>
  {tr('يُنشأ التقرير فقط بعد تحقق الخادم من الحجز والمريض المرتبطين. لا يظهر رمز تحقق أو اعتماد خارجي قبل اكتمال عقده المعتمد.', 'The report is issued only after the server verifies the linked request and patient. No verification QR or external accreditation is presented before its approved contract is complete.')}
 </Text>
 </NCard>

 <NBtn
 label={tr(' إصدار التقرير الطبي', ' Issue Medical Report')}
 disabled={!type || !findings.trim()}
 onPress={async () => {
   try {
     if (!apt?.id || !apt?.patient_id) {
       show(tr('لا يمكن إصدار التقرير دون حجز ومريض مرتبطين', 'Cannot issue a report without a linked appointment and patient'), 'error');
       return;
     }
     await client.post(`/provider/requests/${apt.id}/medical-report`, {
       patient_id: apt.patient_id,
       type, findings, conclusion, recommendations: recs
     });
     show(tr('تم إصدار التقرير الطبي ', 'Report issued '), 'success');
     onBack();
   } catch (err) {
     show(tr('حدث خطأ', 'Failed to issue report'), 'error');
   }
 }}
 />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// NOTIFICATIONS CENTER
// ══════════════════════════════════════════════════════════════════════════════
export function NotificationsScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [filter, setFilter] = useState<'all'|'unread'|'requests'|'payments'|'radiology_results'>('all');

 const [NOTIFS, setNOTIFS] = useState<any[]>([]);
  useEffect(() => {
    client.get('/provider/notifications').then(res => {
      setNOTIFS((res.data || []).map((n: any) => ({
        id: n.id || n._id,
        type: n.type?.toLowerCase().includes('radiology') ? 'radiology_result' : n.type?.toLowerCase().includes('payment') ? 'payment' : n.type?.toLowerCase().includes('system') ? 'system' : n.type?.toLowerCase().includes('review') ? 'review' : 'request',
        icon: n.type?.toLowerCase().includes('radiology') ? 'document-text' : n.type?.toLowerCase().includes('payment') ? 'cash' : 'notifications',
        ar: n.message_ar || n.message,
        en: n.message_en || n.message,
        time: new Date(n.createdAt).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
        unread: !n.read,
        metadata: n.metadata
      })));
    }).catch(() => {});
  }, []);

 const [DOCTORS, setDOCTORS] = useState<any[]>([]);
  useEffect(() => {
    client.get('/provider/directory')
      .then(res => setDOCTORS(res.data || []))
      .catch(() => {});
  }, []);

 const filters = [
 { k:'all', ar:'الكل', en:'All' },
 { k:'unread', ar:'غير مقروء',en:'Unread' },
 { k:'requests', ar:'طلبات', en:'Requests'},
 { k:'payments', ar:'مدفوعات', en:'Payments'},
 { k:'radiology_results', ar:'نتائج الأشعة', en:'Results'},
 ] as const;

 const filtered = filter === 'all' ? NOTIFS
 : filter === 'unread' ? NOTIFS.filter(n => n.unread)
 : filter === 'radiology_results' ? NOTIFS.filter(n => n.type === 'radiology_result')
 : NOTIFS.filter(n => n.type === filter.replace('s',''));

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <View style={[styles.topBar, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
 <TouchableOpacity onPress={onBack}>
 <Text style={{ color: theme.primary, fontSize: FS.md }}>{AR ? '→' : '←'}</Text>
 </TouchableOpacity>
 <Text style={{ fontSize: FS.xl, fontWeight: FW.bold, color: theme.text, flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center' }}>
 <I name="bell" size={24} color={theme.text} /> {tr('الإشعارات', 'Notifications')}
 </Text>
 <TouchableOpacity>
 <Text style={{ fontSize: FS.sm, color: theme.primary }}>{tr('مسح الكل', 'Clear All')}</Text>
 </TouchableOpacity>
 </View>

 <ScrollView horizontal showsHorizontalScrollIndicator={false}
 contentContainerStyle={{ paddingHorizontal: SP.lg, paddingVertical: SP.md, gap: SP.sm }}>
 {filters.map(f => (
 <TouchableOpacity key={f.k} onPress={() => setFilter(f.k as any)}
 style={[styles.filterChip2, {
 backgroundColor: filter === f.k ? theme.primary : theme.surface2,
 borderColor: filter === f.k ? theme.primary : theme.border,
 }]}>
 <Text style={{ color: filter === f.k ? '#FFF' : theme.text, fontSize: FS.sm }}>
 {AR ? f.ar : f.en}
 </Text>
 </TouchableOpacity>
 ))}
 </ScrollView>

 <FlatList
 data={filtered}
 keyExtractor={i => i.id}
 contentContainerStyle={{ padding: SP.lg, paddingBottom: 100 }}
 renderItem={({ item }) => (
 <TouchableOpacity onPress={() => {
    if (item.type === 'radiology_result' && item.metadata?.pdfUrl) {
      import('react-native').then(({ Linking }) => {
        if (typeof window !== 'undefined' && window.open) window.open(item.metadata.pdfUrl, '_blank');
        else Linking.openURL(item.metadata.pdfUrl);
      });
    }
 }}>
 <View style={[styles.notifRow, {
 backgroundColor: item.unread ? theme.primaryLight : theme.card,
 borderColor: item.unread ? theme.primary : theme.border,
 flexDirection: AR ? 'row-reverse' : 'row',
 }]}>
 <View style={[styles.notifIcon, { backgroundColor: theme.surface2, alignItems: 'center', justifyContent: 'center' }]}>
 <I name={item.icon as any} size={20} color={item.unread ? theme.primary : theme.textSub} />
 </View>
 <View style={{ flex: 1 }}>
 <Text style={{
 fontSize: FS.md, color: theme.text,
 fontWeight: item.unread ? FW.bold : FW.reg,
 textAlign: AR ? 'right' : 'left',
 }} numberOfLines={2}>
 {AR ? item.ar : item.en}
 </Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, marginTop: 2 }}>
 {item.time}
 </Text>
 </View>
 {item.unread && (
 <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: theme.primary, alignSelf: 'center' }} />
 )}
 </View>
 </TouchableOpacity>
 )}
 ItemSeparatorComponent={() => <View style={{ height: SP.sm }} />}
 />
 </View>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// CALENDAR SYNC SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function CalendarSyncScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 return (
  <NScroll>
   <NHeader title={tr('مزامنة التقويم', 'Calendar Sync')} onBack={onBack} />
   <View style={{ padding: SP.xl }}>
    <NCard style={{ gap: SP.md }}>
     <Text style={{ fontSize: FS.lg, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>{tr('مزامنة التقويم غير مفعلة', 'Calendar sync is not enabled')}</Text>
     <Text style={{ color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{tr('لا يمكن الادعاء بربط Google أو Apple أو تصدير المواعيد قبل اعتماد OAuth والخصوصية وعقد المزامنة.', 'Google/Apple connection and appointment export cannot be claimed before OAuth, privacy, and synchronization contracts are approved.')}</Text>
    </NCard>
   </View>
  </NScroll>
 );
 const [googleSync, setGoogle] = useState(false);
 const [appleSync, setApple] = useState(false);
 const [autoAdd, setAutoAdd] = useState(true);
 const [reminders, setReminders] = useState(true);

 return (
 <NScroll>
 <NHeader title={tr(' مزامنة التقويم', ' Calendar Sync')} onBack={onBack} />

 <NCard style={{ backgroundColor: theme.infoBg, marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.sm, color: theme.info, lineHeight: 20, textAlign: AR ? 'right' : 'left' }}>
 {tr('مزامنة مواعيدك تلقائياً مع Google Calendar أو Apple Calendar. جميع المواعيد الجديدة ستُضاف فوراً.', 'Sync your appointments automatically with Google or Apple Calendar. New bookings added instantly.')}
 </Text>
 </NCard>

 <NCard style={{ marginBottom: SP.xl }}>
 {/* Google Calendar */}
 <View style={[styles.calRow, { flexDirection: AR ? 'row-reverse' : 'row' }]}>
 <View style={styles.calIcon}>
 <Text style={{ fontSize: 28 }}></Text>
 </View>
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
 Google Calendar
 </Text>
 <Text style={{ fontSize: FS.xs, color: googleSync ? theme.success : theme.textSub }}>
 {googleSync ? (tr('مُتزامن ', 'Synced ')) : (tr('غير مُتزامن', 'Not synced'))}
 </Text>
 </View>
 <NBtn
 label={googleSync ? (tr('فصل', 'Disconnect')) : (tr('ربط', 'Connect'))}
 variant={googleSync ? 'danger' : 'primary'}
 size="sm" full={false}
 style={{ paddingHorizontal: SP.xl }}
 onPress={() => {
 setGoogle(g => !g);
 show(googleSync ? (tr('تم فصل Google Calendar', 'Google disconnected')) : (tr('تم ربط Google Calendar ', 'Google Calendar connected ')), googleSync ? 'info' : 'success');
 }}
 />
 </View>

 <NDivider />

 {/* Apple Calendar */}
 <View style={[styles.calRow, { flexDirection: AR ? 'row-reverse' : 'row' }]}>
 <View style={styles.calIcon}>
 <Text style={{ fontSize: 28 }}></Text>
 </View>
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
 Apple Calendar
 </Text>
 <Text style={{ fontSize: FS.xs, color: appleSync ? theme.success : theme.textSub }}>
 {appleSync ? (tr('مُتزامن ', 'Synced ')) : (tr('غير مُتزامن', 'Not synced'))}
 </Text>
 </View>
 <NBtn
 label={appleSync ? (tr('فصل', 'Disconnect')) : (tr('ربط', 'Connect'))}
 variant={appleSync ? 'danger' : 'primary'}
 size="sm" full={false}
 style={{ paddingHorizontal: SP.xl }}
 onPress={() => {
 setApple(a => !a);
 show(appleSync ? (tr('تم فصل Apple Calendar', 'Apple disconnected')) : (tr('تم ربط Apple Calendar ', 'Apple Calendar connected ')), appleSync ? 'info' : 'success');
 }}
 />
 </View>
 </NCard>

 <NCard style={{ marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text,
 marginBottom: SP.md, textAlign: AR ? 'right' : 'left' }}>
 {tr('️ إعدادات المزامنة', '️ Sync Settings')}
 </Text>
 <NToggle
 label={tr('إضافة المواعيد الجديدة تلقائياً', 'Auto-add new appointments')}
 sub={tr('كل حجز جديد يُضاف فوراً للتقويم', 'Each new booking auto-added to calendar')}
 value={autoAdd} onChange={setAutoAdd}
 />
 <NToggle
 label={tr('تفعيل تذكيرات التقويم', 'Enable calendar reminders')}
 sub={tr('تذكير قبل الموعد بـ 15 دقيقة', 'Reminder 15 minutes before appointment')}
 value={reminders} onChange={setReminders}
 />
 </NCard>

 <NBtn label={tr(' حفظ إعدادات المزامنة', ' Save Sync Settings')}
 onPress={() => { show(tr('تم حفظ إعدادات المزامنة', 'Sync settings saved'), 'success'); onBack(); }} />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// AVAILABILITY PULSE SCREEN (ميزة تنافسية — غير موجودة عند المنافسين)
// ══════════════════════════════════════════════════════════════════════════════
export function AvailabilityPulseScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [pulseOn, setPulse] = useState(false);
 const [minutes, setMinutes] = useState('5');
 const pulseAnim = useRef(new Animated.Value(1)).current;

 useEffect(() => {
 if (!pulseOn) return;
 const loop = Animated.loop(Animated.sequence([
 Animated.timing(pulseAnim, { toValue: 1.15, duration: 800, useNativeDriver: true }),
 Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
 ]));
 loop.start();
 return () => loop.stop();
 }, [pulseOn]);

 return (
 <NScroll>
 <NHeader title={tr(' نبضة التوفر الفوري', ' Availability Pulse')} onBack={onBack} />

 <NCard style={{ backgroundColor: theme.primaryLight, marginBottom: SP.xl, alignItems: 'center', padding: SP.xxl }}>
 <Animated.View style={{ transform: [{ scale: pulseOn ? pulseAnim : 1 }] }}>
 <View style={{
 width: 80, height: 80, borderRadius: 40,
 backgroundColor: pulseOn ? theme.primary : theme.surface2,
 alignItems: 'center', justifyContent: 'center',
 marginBottom: SP.lg,
 }}>
 <Text style={{ fontSize: 36 }}>{pulseOn ? '' : ''}</Text>
 </View>
 </Animated.View>
 <Text style={{ fontSize: FS.xl, fontWeight: FW.bold, color: theme.text, textAlign: 'center' }}>
 {pulseOn
 ? (trT("متاح الآن خلال {0} دقيقة", "Available within {0} min", [minutes]))
 : (tr('النبضة معطّلة', 'Pulse Off'))}
 </Text>
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: 'center', marginTop: SP.xs }}>
 {tr('يظهر للمرضى في التطبيق بأنك متاح بشكل فوري', 'Patients see you are instantly available right now')}
 </Text>
 </NCard>

 <NCard style={{ marginBottom: SP.xl }}>
 <NToggle
 label={tr(' تفعيل نبضة التوفر الفوري', ' Enable Availability Pulse')}
 sub={tr('يخبر المرضى بتوفرك الفوري ويزيد الطلب', 'Tells patients you are available now — boosts demand')}
 value={pulseOn} onChange={v => {
 setPulse(v);
 show(v ? (tr('نبضة التوفر مفعّلة ', 'Pulse activated ')) : (tr('نبضة التوفر معطّلة', 'Pulse off')), v ? 'success' : 'info');
 }}
 />

 {pulseOn && (
 <View style={{ marginTop: SP.lg }}>
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginBottom: SP.sm }}>
 {tr('متاح خلال:', 'Available within:')}
 </Text>
 <View style={{ flexDirection: 'row', gap: SP.sm }}>
 {['2','5','10','15','30'].map(m => (
 <TouchableOpacity key={m} onPress={() => setMinutes(m)}
 style={[styles.insChip, {
 backgroundColor: minutes === m ? theme.primary : theme.surface2,
 borderColor: minutes === m ? theme.primary : theme.border,
 }]}>
 <Text style={{ color: minutes === m ? '#FFF' : theme.text, fontWeight: FW.semi }}>
 {m} {tr('دق', 'min')}
 </Text>
 </TouchableOpacity>
 ))}
 </View>
 </View>
 )}
 </NCard>

 <NCard style={{ backgroundColor: theme.infoBg, marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.sm, color: theme.info, lineHeight: 20, textAlign: AR ? 'right' : 'left' }}>
  {tr('الأطباء الذين يفعّلون "نبضة التوفر" يحصلون على طلبات أكثر بنسبة 65% في وقت النشاط.', 'Doctors using Availability Pulse receive 65% more requests during active time.')}
 </Text>
 </NCard>

 <NBtn label={tr(' حفظ', ' Save')}
 onPress={() => { show(tr('تم حفظ الإعدادات', 'Settings saved'), 'success'); onBack(); }} />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// PROFESSIONAL NETWORK (Doximity-style — ميزة تنافسية)
// ══════════════════════════════════════════════════════════════════════════════
export function ProfessionalNetworkScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [search, setSearch] = useState('');

 const DOCTORS = [
 { id: '1', name: tr('د. خالد العنزي', 'Dr. Khaled Al-Anazi'), spec: tr('أمراض القلب والشرايين', 'Cardiology'), hospital: tr('مستشفى سليمان الحبيب', 'Sulaiman Al-Habib Hospital'), mutual: 3 },
 { id: '2', name: tr('د. سارة الشريف', 'Dr. Sarah Al-Sharif'), spec: tr('طب الأطفال حديثي الولادة', 'Pediatrics & Neonatology'), hospital: tr('مدينة الملك سعود الطبية', 'King Saud Medical City'), mutual: 5 },
 { id: '3', name: tr('د. عبد الرحمن الفوزان', 'Dr. Abdulrahman Al-Fouzan'), spec: tr('جراحة العظام والمفاصل', 'Orthopedic Surgery'), hospital: tr('مستشفى دلة', 'Dallah Hospital'), mutual: 0 }
 ];

 const filtered = DOCTORS.filter(d => 
 d.name.toLowerCase().includes(search.toLowerCase()) || 
 d.spec.toLowerCase().includes(search.toLowerCase()) ||
 d.hospital.toLowerCase().includes(search.toLowerCase())
 );

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NHeader title={tr(' الشبكة المهنية', ' Professional Network')} onBack={onBack} />
 <ScrollView contentContainerStyle={{ padding: SP.xl, paddingBottom: 100 }}>
 <NInput 
 label={tr('ابحث باسم الطبيب، التخصص، أو المستشفى', 'Search by doctor name, specialty, or hospital')} 
 value={search} 
 onChange={setSearch} 
 />
 {filtered.map(doc => (
 <NCard key={doc.id} style={{ marginBottom: SP.lg }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.md }}>
 <NAvatar name={doc.name} size={50} />
 <View style={{ alignItems: AR ? 'flex-end' : 'flex-start' }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text }}>{doc.name}</Text>
 <Text style={{ fontSize: FS.sm, color: theme.primary }}>{doc.spec}</Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>{doc.hospital}</Text>
 {doc.mutual > 0 && (
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>
  {doc.mutual} {tr('مشترك', 'mutual')}
 </Text>
 )}
 </View>
 </View>
 <View style={{ gap: SP.sm }}>
 <NBtn label={tr(' تواصل', ' Call')} size="xs" full={false}
 style={{ paddingHorizontal: SP.md }}
 onPress={() => show(tr('جاري الاتصال المشفّر...', 'Encrypted call...'), 'info')} />
 <NBtn label={tr('+ تواصل', '+ Connect')} size="xs" variant="outline" full={false}
 style={{ paddingHorizontal: SP.md }}
 onPress={() => show(tr('تم إرسال طلب التواصل', 'Connection request sent'), 'success')} />
 </View>
 </View>
 </NCard>
 ))}
 </ScrollView>
 </View>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// DOCTOR SERVICE MANAGEMENT SCREEN (Real API version)
// ══════════════════════════════════════════════════════════════════════════════
const MODE_MAP: Record<string, any> = {
 video: {
 nameAr: 'استشارة فيديو',
 nameEn: 'Video Consult',
 descAr: 'استشارة طبية عن بعد عبر مكالمة فيديو عالية الدقة',
 descEn: 'Telehealth medical consult via high-def video call'
 },
 voice: {
 nameAr: 'استشارة صوتية',
 nameEn: 'Audio Consult',
 descAr: 'استشارة طبية صوتية سريعة',
 descEn: 'Quick audio-only medical consultation'
 },
 clinic: {
 nameAr: 'كشف عيادة',
 nameEn: 'Clinic Visit',
 descAr: 'زيارة وحجز موعد بالعيادة الخاصة بالطبيب',
 descEn: 'In-person clinic visit at doctor\'s practice'
 },
 home: {
 nameAr: 'زيارة منزلية',
 nameEn: 'Home Visit',
 descAr: 'زيارة منزلية مخصصة للحالات المناسبة',
 descEn: 'Direct home visit for eligible patients'
 },
 chat: {
 nameAr: 'استشارة دردشة',
 nameEn: 'Chat Consult',
 descAr: 'استشارة طبية سريعة عبر المحادثة الفورية',
 descEn: 'Fast medical consultation via instant messaging'
 }
};

export function DoctorServiceManagementScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

 const [loading, setLoading] = useState(true);
 const [services, setServices] = useState<any[]>([]);

 const [showAddSheet, setShowAddSheet] = useState(false);
 const [newTitleAr, setNewTitleAr] = useState('');
 const [newTitleEn, setNewTitleEn] = useState('');
 const [newPrice, setNewPrice] = useState('');
 const [newDuration, setNewDuration] = useState('30');
 const [newDescAr, setNewDescAr] = useState('');
 const [newDescEn, setNewDescEn] = useState('');

 const [editingService, setEditingService] = useState<any | null>(null);
 const [editPrice, setEditPrice] = useState('');
 const [editDuration, setEditDuration] = useState('');

 const fetchServices = async () => {
 try {
 const res = await client.get('/provider/capabilities/doctor-sessions');
 const parsed = (res.data || []).map((item: any) => {
 const mode = item.consultation_type;
 const modeInfo = MODE_MAP[mode] || {
 nameAr: item.specialty || 'خدمة مخصصة',
 nameEn: item.specialty || 'Custom Service',
 descAr: 'خدمة مخصصة للطبيب',
 descEn: 'Custom service'
 };
 return {
 id: item.id || item._id,
 consultation_type: item.consultation_type,
 specialty: item.specialty,
 nameAr: modeInfo.nameAr,
 nameEn: modeInfo.nameEn,
 descAr: modeInfo.descAr,
 descEn: modeInfo.descEn,
 price: item.price,
 duration: item.duration_minutes,
 active: item.available
 };
 });
 setServices(parsed);
 } catch (e) {
 // Silent log skip
 show(tr('فشل تحميل الخدمات والأسعار من السيرفر', 'Failed to load services and prices from server'), 'error');
 } finally {
 setLoading(false);
 }
 };

 useEffect(() => {
 fetchServices();
 }, []);

 const toggleService = async (id: string, currentActive: boolean) => {
 try {
 const srv = services.find(s => s.id === id);
 if (!srv) return;
 
 const payload = {
 consultation_type: srv.consultation_type,
 specialty: srv.specialty || 'General Medicine',
 price: srv.price,
 duration_minutes: srv.duration,
 available: !currentActive
 };
 
 await client.post('/provider/capabilities/doctor-sessions', payload);
 setServices(prev => prev.map(s => s.id === id ? { ...s, active: !currentActive } : s));
 show(tr('تم تحديث حالة الخدمة', 'Service status updated'), 'success');
 } catch (e) {
 show(tr('فشل تحديث حالة الخدمة', 'Failed to update service status'), 'error');
 }
 };

 const handleAddService = async () => {
 if (!newPrice) {
 show(tr('يرجى إدخال السعر', 'Please enter price'), 'error');
 return;
 }
 try {
 const rawType = newTitleEn.toLowerCase().includes('video') ? 'video'
 : newTitleEn.toLowerCase().includes('voice') || newTitleEn.toLowerCase().includes('audio') ? 'voice'
 : newTitleEn.toLowerCase().includes('clinic') ? 'clinic'
 : newTitleEn.toLowerCase().includes('home') ? 'home'
 : 'chat';
 
 const payload = {
 consultation_type: rawType,
 specialty: 'General Medicine',
 price: parseFloat(newPrice) || 0,
 duration_minutes: parseInt(newDuration) || 30,
 available: true
 };
 
 await client.post('/provider/capabilities/doctor-sessions', payload);
 fetchServices();
 setShowAddSheet(false);
 setNewTitleAr('');
 setNewTitleEn('');
 setNewPrice('');
 setNewDuration('30');
 show(tr('تمت إضافة الخدمة بنجاح', 'Service added successfully'), 'success');
 } catch (e) {
 show(tr('فشل إضافة الخدمة', 'Failed to add service'), 'error');
 }
 };

 const handleDeleteService = async (id: string) => {
 try {
 await client.delete(`/provider/capabilities/doctor-sessions/${id}`);
 setServices(prev => prev.filter(s => s.id !== id));
 show(tr('تم حذف الخدمة', 'Service deleted'), 'success');
 } catch (e) {
 show(tr('فشل حذف الخدمة', 'Failed to delete service'), 'error');
 }
 };

 const openEdit = (srv: any) => {
 setEditingService(srv);
 setEditPrice(String(srv.price));
 setEditDuration(String(srv.duration));
 };

 const saveEdit = async () => {
 if (!editingService) return;
 try {
 const payload = {
 consultation_type: editingService.consultation_type,
 specialty: editingService.specialty || 'General Medicine',
 price: parseFloat(editPrice) || 0,
 duration_minutes: parseInt(editDuration) || 30,
 available: editingService.active
 };
 
 await client.post('/provider/capabilities/doctor-sessions', payload);
 setServices(prev => prev.map(s => s.id === editingService.id ? { ...s, price: parseFloat(editPrice) || 0, duration: parseInt(editDuration) || 30 } : s));
 setEditingService(null);
 show(tr('تم حفظ التعديلات', 'Changes saved successfully'), 'success');
 } catch (e) {
 show(tr('فشل حفظ التعديلات', 'Failed to save changes'), 'error');
 }
 };

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NHeader title={tr(' إدارة الخدمات والأسعار', ' Service Management')} onBack={onBack} />
 {loading ? (
 <ActivityIndicator size="large" color={theme.primary} style={{ marginTop: SP.xxl }} />
 ) : (
 <ScrollView contentContainerStyle={{ padding: SP.xl, paddingBottom: 100 }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.textSub }}>
 {tr('الخدمات المتاحة', 'Available Services')}
 </Text>
 <TouchableOpacity onPress={() => setShowAddSheet(true)} style={{ backgroundColor: theme.primary, paddingHorizontal: SP.lg, paddingVertical: SP.sm, borderRadius: R.md }}>
 <Text style={{ color: '#FFF', fontWeight: FW.bold }}> {tr('إضافة خدمة', 'Add Service')}</Text>
 </TouchableOpacity>
 </View>

 {services.map(s => (
 <NCard key={s.id} style={{ marginBottom: SP.lg, borderColor: s.active ? theme.primary : theme.border }} accent={s.active ? theme.primary : undefined}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SP.sm }}>
 <Text style={{ fontSize: FS.lg, fontWeight: FW.bold, color: theme.text }}>
 {AR ? s.nameAr : s.nameEn}
 </Text>
 <Switch value={s.active} onValueChange={() => toggleService(s.id, s.active)} trackColor={{ true: theme.primary }} />
 </View>
 
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginBottom: SP.md }}>
 {AR ? s.descAr : s.descEn}
 </Text>
 
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: theme.border, paddingTop: SP.md }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md }}>
 <Text style={{ fontSize: FS.sm, color: theme.text, fontWeight: FW.bold }}>
  {s.price} {tr('ريال', 'SAR')}
 </Text>
 <Text style={{ fontSize: FS.sm, color: theme.textSub }}>
 ⏱️ {s.duration} {tr('دقيقة', 'min')}
 </Text>
 </View>
 
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md }}>
 <TouchableOpacity onPress={() => openEdit(s)} style={{ padding: SP.xs }}>
 <Text style={{ color: theme.primary, fontSize: FS.sm }}>️ {tr('تعديل', 'Edit')}</Text>
 </TouchableOpacity>
 <TouchableOpacity onPress={() => handleDeleteService(s.id)} style={{ padding: SP.xs }}>
 <Text style={{ color: theme.danger, fontSize: FS.sm }}>️ {tr('حذف', 'Delete')}</Text>
 </TouchableOpacity>
 </View>
 </View>
 </NCard>
 ))}
 </ScrollView>
 )}

 {/* Edit Sheet */}
 <NSheet visible={!!editingService} onClose={() => setEditingService(null)} title={tr('️ تعديل الخدمة', '️ Edit Service')} height={380}>
 <View style={{ padding: SP.md }}>
 <NPriceInput label={tr('سعر الخدمة (SAR)', 'Service Price (SAR)')} value={editPrice} onChange={setEditPrice} />
 <NInput label={tr('مدة الخدمة بالدقائق', 'Service Duration (min)')} kbType="numeric" value={editDuration} onChange={setEditDuration} />
 <NBtn label={tr(' حفظ', ' Save')} onPress={saveEdit} style={{ marginTop: SP.md }} />
 </View>
 </NSheet>

 {/* Add Service Sheet */}
 <NSheet visible={showAddSheet} onClose={() => setShowAddSheet(false)} title={tr(' إضافة خدمة جديدة', ' Add Custom Service')} height={580}>
 <ScrollView contentContainerStyle={{ padding: SP.md }}>
 <NInput label={tr('اسم الخدمة (عربي)', 'Service Name (Arabic)')} value={newTitleAr} onChange={setNewTitleAr} required />
 <NInput label={tr('اسم الخدمة (إنجليزي)', 'Service Name (English)')} value={newTitleEn} onChange={setNewTitleEn} required />
 <NPriceInput label={tr('سعر الخدمة (SAR)', 'Service Price (SAR)')} value={newPrice} onChange={setNewPrice} required />
 <NInput label={tr('المدة بالدقائق', 'Duration (min)')} kbType="numeric" value={newDuration} onChange={setNewDuration} />
 <NInput label={tr('الوصف (عربي)', 'Description (Arabic)')} value={newDescAr} onChange={setNewDescAr} multi />
 <NInput label={tr('الوصف (إنجليزي)', 'Description (English)')} value={newDescEn} onChange={setNewDescEn} multi />
 <NBtn label={tr(' إضافة الخدمة', ' Add Service')} onPress={handleAddService} style={{ marginTop: SP.md }} />
 </ScrollView>
 </NSheet>
 </View>
 );
}



export function SubscriptionPlansScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

 interface Plan { id: string; nameAr: string; nameEn: string; price: string; period: string; sessions: string; discount: string; active: boolean; }
 const [plans, setPlans] = useState<Plan[]>([
 { id:'1', nameAr:'الباقة الشهرية', nameEn:'Monthly Plan', price:'500', period:'month', sessions:'3', discount:'16', active:true },
 { id:'2', nameAr:'الباقة الفصلية', nameEn:'Quarterly Plan',price:'1200',period:'quarter',sessions:'10','discount':'20',active:false},
 ]);

 const addPlan = () => {
 setPlans(prev => [...prev, { id: Date.now().toString(), nameAr: 'باقة جديدة', nameEn: 'New Plan', price: '0', period: 'month', sessions: '1', discount: '0', active: false }]);
 };

 return (
 <NScroll>
 <NHeader title={tr(' باقات الاشتراك', ' Subscription Plans')} onBack={onBack} />

 <NCard style={{ backgroundColor: theme.infoBg, marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.sm, color: theme.info, lineHeight: 20, textAlign: AR ? 'right' : 'left' }}>
 {tr('الباقات الاشتراكية تزيد الدخل الثابت وتبني ولاء المرضى. المرضى الذين يشتركون يزورون 3x أكثر.', 'Subscription plans increase steady income and build patient loyalty. Subscribers visit 3x more.')}
 </Text>
 </NCard>

 {plans.map((plan, i) => (
 <NCard key={plan.id} style={{ marginBottom: SP.md }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', marginBottom: SP.md }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text }}>
 {AR ? plan.nameAr : plan.nameEn}
 </Text>
 <Switch value={plan.active} onValueChange={v => setPlans(ps => ps.map(p => p.id===plan.id ? {...p,active:v} : p))}
 trackColor={{ false: theme.border, true: theme.primary }} thumbColor="#FFF" />
 </View>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md }}>
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, marginBottom: 2 }}>{tr('السعر (ريال)', 'Price (SAR)')}</Text>
 <Text style={{ fontSize: FS['2xl'], fontWeight: FW.xbold, color: theme.primary }}>{plan.price}</Text>
 </View>
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, marginBottom: 2 }}>{tr('الجلسات', 'Sessions')}</Text>
 <Text style={{ fontSize: FS['2xl'], fontWeight: FW.xbold, color: theme.text }}>{plan.sessions}</Text>
 </View>
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, marginBottom: 2 }}>{tr('الخصم', 'Discount')}</Text>
 <Text style={{ fontSize: FS['2xl'], fontWeight: FW.xbold, color: theme.success }}>{plan.discount}%</Text>
 </View>
 </View>
 {plan.active && (
 <NBadge label={tr(' مفعّلة', ' Active')} variant="success" size="sm" style={{ marginTop: SP.md }} />
 )}
 </NCard>
 ))}

 <NBtn label={tr('+ إضافة باقة جديدة', '+ Add New Plan')} variant="outline"
 onPress={addPlan} style={{ marginBottom: SP.lg }} />

 <NBtn label={tr(' حفظ الباقات', ' Save Plans')}
 onPress={() => { show(tr('تم حفظ باقات الاشتراك ', 'Plans saved '), 'success'); onBack(); }} />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// STATISTICS & REPORTS SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function StatisticsScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [period, setPeriod] = useState<'week'|'month'|'year'>('month');

 const PERIODS = [
 { k:'week', ar:'أسبوع', en:'Week' },
 { k:'month', ar:'شهر', en:'Month' },
 { k:'year', ar:'سنة', en:'Year' },
 ] as const;

 const STATS = period === 'week'
 ? { revenue: '4,200', apts: 18, rating: 4.8, newPts: 5, topService: tr('استشارة فيديو', 'Video') }
 : period === 'month'
 ? { revenue: '18,500', apts: 72, rating: 4.8, newPts: 22, topService: tr('استشارة فيديو', 'Video') }
 : { revenue: '224,000', apts: 860, rating: 4.9, newPts: 180, topService: tr('استشارة فيديو', 'Video') };

 // Mock bar chart data
 const BAR_DATA = period === 'week'
 ? [600,800,1100,750,1200,400,350]
 : period === 'month'
 ? [3200,4100,3800,5200,4700,2100,3900,4800,5100,3600,4400,3800]
 : [15000,17000,19000,18000,22000,20000,21000,24000,19000,18000,16000,22000];

 const maxBar = Math.max(...BAR_DATA);
 const LABELS_WEEK = AR ? ['أحد','اثن','ثلا','أرب','خمس','جمع','سبت'] : ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
 const LABELS_MONTH = AR ? Array.from({length:12},(_,i)=>`${i+1}`) : ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
 const LABELS = period === 'week' ? LABELS_WEEK : LABELS_MONTH;

 return (
 <NScroll>
 <NHeader title={tr(' الإحصائيات والتقارير', ' Statistics & Reports')} onBack={onBack} />

 {/* Period selector */}
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, marginBottom: SP.xl }}>
 {PERIODS.map(p => (
 <TouchableOpacity key={p.k} onPress={() => setPeriod(p.k as any)}
 style={[{ flex:1, paddingVertical:SP.md, borderRadius:R.lg, borderWidth:1.5, alignItems:'center' }, {
 backgroundColor: period===p.k ? theme.primary : theme.surface2,
 borderColor: period===p.k ? theme.primary : theme.border,
 }]}>
 <Text style={{ color: period===p.k ? '#FFF' : theme.text, fontWeight: FW.semi }}>
 {AR ? p.ar : p.en}
 </Text>
 </TouchableOpacity>
 ))}
 </View>

 {/* KPI Cards */}
 <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: SP.md, marginBottom: SP.xl }}>
 <NStatCard icon="" label={tr('الإيرادات', 'Revenue')} value={STATS.revenue} unit={tr('ر', 'SAR')} color="#4CAF50" style={{ width:'47%' }} />
 <NStatCard icon="" label={tr('المواعيد', 'Appointments')} value={String(STATS.apts)} color="#2196F3" style={{ width:'47%' }} />
 <NStatCard icon="" label={tr('التقييم', 'Rating')} value={String(STATS.rating)} color="#FFC107" style={{ width:'47%' }} />
 <NStatCard icon="" label={tr('مرضى جدد', 'New Patients')} value={String(STATS.newPts)} color="#9C27B0" style={{ width:'47%' }} />
 </View>

 {/* Bar Chart */}
 <NCard style={{ marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text,
 marginBottom: SP.lg, textAlign: AR ? 'right' : 'left' }}>
 {tr(' الإيرادات', ' Revenue Trend')}
 </Text>
 <ScrollView horizontal showsHorizontalScrollIndicator={false}>
 <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: SP.sm, height: 120 }}>
 {BAR_DATA.map((val, i) => (
 <View key={i} style={{ alignItems: 'center', width: 36 }}>
 <View style={{
 width: 28, height: Math.max(8, (val / maxBar) * 100),
 backgroundColor: theme.primary, borderRadius: 6, opacity: 0.8,
 }} />
 <Text style={{ fontSize: 9, color: theme.textSub, marginTop: 4 }}>
 {LABELS[i] ?? i+1}
 </Text>
 </View>
 ))}
 </View>
 </ScrollView>
 </NCard>

 {/* Service Breakdown */}
 <NCard style={{ marginBottom: SP.xl }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text,
 marginBottom: SP.lg, textAlign: AR ? 'right' : 'left' }}>
 {tr(' توزيع الخدمات', ' Service Breakdown')}
 </Text>
 {[
 { label: tr('استشارة فيديو', 'Video Consult'), pct: 55, color: '#2196F3' },
 { label: tr('كشف عيادة', 'Clinic Visit'), pct: 30, color: '#4CAF50' },
 { label: tr('زيارة منزلية', 'Home Visit'), pct: 15, color: '#FF9800' },
 ].map((item, i) => (
 <View key={i} style={{ marginBottom: SP.md }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', marginBottom: 4 }}>
 <Text style={{ fontSize: FS.sm, color: theme.text }}>{item.label}</Text>
 <Text style={{ fontSize: FS.sm, fontWeight: FW.bold, color: item.color }}>{item.pct}%</Text>
 </View>
 <View style={{ height: 8, backgroundColor: theme.surface2, borderRadius: R.full }}>
 <View style={{ height: 8, width: `${item.pct}%`, backgroundColor: item.color, borderRadius: R.full }} />
 </View>
 </View>
 ))}
 </NCard>

 <NBtn
 label={tr(' تصدير تقرير PDF', ' Export PDF Report')}
 variant="outline"
 icon=""
 onPress={() => show(tr('جاري إنشاء التقرير...', 'Generating report...'), 'info')}
 />
 </NScroll>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// DOCTOR AVAILABILITY SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function DoctorAvailabilityScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
 const [saving, setSaving] = useState(false);

 const [vacationMode, setVacationMode] = useState(false);
 const [weeklySchedule, setWeeklySchedule] = useState([
 { day: 'Sunday', dayAr: 'الأحد', active: true, splitShift: true, morningStart: '09:00', morningEnd: '13:00', eveningStart: '17:00', eveningEnd: '21:00' },
 { day: 'Monday', dayAr: 'الأثنين', active: true, splitShift: true, morningStart: '09:00', morningEnd: '13:00', eveningStart: '17:00', eveningEnd: '21:00' },
 { day: 'Tuesday', dayAr: 'الثلاثاء', active: true, splitShift: false, morningStart: '09:00', morningEnd: '17:00', eveningStart: '', eveningEnd: '' },
 { day: 'Wednesday', dayAr: 'الأربعاء', active: true, splitShift: true, morningStart: '09:00', morningEnd: '13:00', eveningStart: '17:00', eveningEnd: '21:00' },
 { day: 'Thursday', dayAr: 'الخميس', active: true, splitShift: true, morningStart: '09:00', morningEnd: '13:00', eveningStart: '17:00', eveningEnd: '21:00' },
 { day: 'Friday', dayAr: 'الجمعة', active: false, splitShift: false, morningStart: '', morningEnd: '', eveningStart: '', eveningEnd: '' },
 { day: 'Saturday', dayAr: 'السبت', active: false, splitShift: false, morningStart: '', morningEnd: '', eveningStart: '', eveningEnd: '' },
 ]);

 const [exceptions, setExceptions] = useState<any[]>([
 { id: '1', date: '2026-06-25', type: 'close_day', labelAr: 'إغلاق اليوم بالكامل', labelEn: 'Full Day Closed' },
 { id: '2', date: '2026-06-28', type: 'block_time', labelAr: 'حظر (13:00 - 15:00)', labelEn: 'Blocked (13:00 - 15:00)', start: '13:00', end: '15:00' },
 ]);

 const [showAddException, setShowAddException] = useState(false);
 const [exDate, setExDate] = useState('2026-06-30');
 const [exType, setExType] = useState<'close_day'|'block_time'|'exceptional_open'>('close_day');
 const [exStart, setExStart] = useState('12:00');
 const [exEnd, setExEnd] = useState('14:00');


 const toggleDay = (dayName: string) => {
 setWeeklySchedule(prev => prev.map(d => d.day === dayName ? { ...d, active: !d.active } : d));
 };

 const toggleSplit = (dayName: string) => {
 setWeeklySchedule(prev => prev.map(d => d.day === dayName ? { ...d, splitShift: !d.splitShift } : d));
 };

 const updateHours = (dayName: string, field: string, value: string) => {
 setWeeklySchedule(prev => prev.map(d => d.day === dayName ? { ...d, [field]: value } : d));
 };

 const [showPicker, setShowPicker] = useState(false);
 const [pickerTarget, setPickerTarget] = useState<{day: string, field: string}|null>(null);

 const onTimeChange = (event: any, selectedDate?: Date) => {
   if (Platform.OS === 'android') {
     setShowPicker(false);
   }
   if (selectedDate && pickerTarget) {
     const hours = selectedDate.getHours().toString().padStart(2, '0');
     const mins = selectedDate.getMinutes().toString().padStart(2, '0');
     updateHours(pickerTarget.day, pickerTarget.field, `${hours}:${mins}`);
   }
 };

 const openTimePicker = (day: string, field: string) => {
   setPickerTarget({ day, field });
   setShowPicker(true);
 };

  const handleSaveSchedule = async () => {
    setSaving(true);
    try {
      await client.post('/provider/settings/delta', { newData: { weeklySchedule, exceptions } });
      show(tr('تم حفظ جدول التوفر الأسبوعي', 'Weekly availability saved'), 'success');
      onBack();
    } catch (e) {
      show(tr('فشل حفظ الجدول', 'Failed to save schedule'), 'error');
    } finally {
      setSaving(false);
    }
  };

 const handleAddException = () => {
 const labelAr = exType === 'close_day' 
 ? 'إغلاق اليوم بالكامل' 
 : exType === 'block_time' 
 ? `حظر (${exStart} - ${exEnd})` 
 : `موعد استثنائي (${exStart} - ${exEnd})`;
 
 const labelEn = exType === 'close_day' 
 ? 'Full Day Closed' 
 : exType === 'block_time' 
 ? `Blocked (${exStart} - ${exEnd})` 
 : `Exceptional (${exStart} - ${exEnd})`;

 const item = {
 id: String(Date.now()),
 date: exDate,
 type: exType,
 labelAr,
 labelEn,
 start: exStart,
 end: exEnd
 };

 setExceptions(prev => [...prev, item]);
 setShowAddException(false);
 show(tr('تمت إضافة الاستثناء بنجاح', 'Exception added successfully'), 'success');
 };

 const handleDeleteException = (id: string) => {
 setExceptions(prev => prev.filter(x => x.id !== id));
 show(tr('تم حذف الاستثناء', 'Exception removed'), 'error');
 };

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NHeader title={tr(' جدول المواعيد والتوفر', ' Availability Settings')} onBack={onBack} />
 <ScrollView contentContainerStyle={{ padding: SP.xl, paddingBottom: 100 }}>
 
 {/* Vacation Mode */}
 <NCard style={{ marginBottom: SP.xl, backgroundColor: vacationMode ? `${theme.danger}15` : theme.surface }} accent={vacationMode ? theme.danger : undefined}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
 <View style={{ flex: 1 }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
 ️ {tr('إجازة مؤقتة (وضع عدم الاتصال)', 'Temporary Vacation (Offline)')}
 </Text>
 <Text style={{ fontSize: FS.xs, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginTop: SP.xs }}>
 {tr('تفعيل هذا الوضع يعطل حجز المواعيد الجديدة فوراً', 'Enabling this blocks new bookings immediately')}
 </Text>
 </View>
 <Switch value={vacationMode} onValueChange={(val) => { setVacationMode(val); show(val ? (tr('️ تم تفعيل وضع الإجازة', '️ Vacation enabled')) : (tr('🟢 تم إلغاء وضع الإجازة', '🟢 Vacation disabled')), val ? 'warning' : 'success'); }} trackColor={{ true: theme.danger }} />
 </View>
 </NCard>

 {/* Weekly Schedule */}
 <NSecHeader title={tr('الجدول الأسبوعي للعيادة والتوفر', 'Weekly Operations Calendar')} />
 {weeklySchedule.map(d => (
 <NCard key={d.day} style={{ marginBottom: SP.md, opacity: vacationMode ? 0.5 : 1 }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SP.md }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, alignItems: 'center' }}>
 <Switch value={d.active} disabled={vacationMode} onValueChange={() => toggleDay(d.day)} trackColor={{ true: theme.primary }} />
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: d.active ? theme.text : theme.textSub }}>
 {AR ? d.dayAr : d.day}
 </Text>
 </View>
 {d.active && (
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, alignItems: 'center' }}>
 <Text style={{ fontSize: FS.xs, color: theme.textSub }}>{tr('فترتين (منفصل)', 'Split Shift')}</Text>
 <Switch value={d.splitShift} disabled={vacationMode} onValueChange={() => toggleSplit(d.day)} />
 </View>
 )}
 </View>

 {d.active && (
 <View style={{ gap: SP.md }}>
 {/* Morning/Main Shift */}
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.sm }}>
 <Text style={{ fontSize: FS.sm, color: theme.text, width: 80, textAlign: AR ? 'right' : 'left' }}>
 {d.splitShift ? (tr(' صباحاً:', ' Morning:')) : (tr('⏰ العمل:', '⏰ Shift:'))}
 </Text>
 <TouchableOpacity disabled={vacationMode} onPress={() => openTimePicker(d.day, 'morningStart')} style={{ flex: 1, height: 40, backgroundColor: theme.surface2, borderRadius: R.sm, alignItems: 'center', justifyContent: 'center' }}>
   <Text style={{ color: theme.text, fontSize: FS.sm }}>{d.morningStart || '--:--'}</Text>
 </TouchableOpacity>
 <Text style={{ color: theme.textSub }}>{tr('إلى', 'to')}</Text>
 <TouchableOpacity disabled={vacationMode} onPress={() => openTimePicker(d.day, 'morningEnd')} style={{ flex: 1, height: 40, backgroundColor: theme.surface2, borderRadius: R.sm, alignItems: 'center', justifyContent: 'center' }}>
   <Text style={{ color: theme.text, fontSize: FS.sm }}>{d.morningEnd || '--:--'}</Text>
 </TouchableOpacity>
 </View>

 {/* Evening Shift */}
 {d.splitShift && (
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: SP.sm }}>
 <Text style={{ fontSize: FS.sm, color: theme.text, width: 80, textAlign: AR ? 'right' : 'left' }}>
 {tr(' مساءً:', ' Evening:')}
 </Text>
 <TouchableOpacity disabled={vacationMode} onPress={() => openTimePicker(d.day, 'eveningStart')} style={{ flex: 1, height: 40, backgroundColor: theme.surface2, borderRadius: R.sm, alignItems: 'center', justifyContent: 'center' }}>
   <Text style={{ color: theme.text, fontSize: FS.sm }}>{d.eveningStart || '--:--'}</Text>
 </TouchableOpacity>
 <Text style={{ color: theme.textSub }}>{tr('إلى', 'to')}</Text>
 <TouchableOpacity disabled={vacationMode} onPress={() => openTimePicker(d.day, 'eveningEnd')} style={{ flex: 1, height: 40, backgroundColor: theme.surface2, borderRadius: R.sm, alignItems: 'center', justifyContent: 'center' }}>
   <Text style={{ color: theme.text, fontSize: FS.sm }}>{d.eveningEnd || '--:--'}</Text>
 </TouchableOpacity>
 </View>
 )}
 </View>
 )}
 </NCard>
 ))}
  {showPicker && (
    Platform.OS === 'ios' ? (
      <Modal transparent visible={showPicker} animationType="slide">
        <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.4)' }}>
          <View style={{ backgroundColor: theme.surface, paddingBottom: 20 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', padding: SP.sm, borderBottomWidth: 1, borderColor: theme.border }}>
              <TouchableOpacity onPress={() => setShowPicker(false)}>
                <Text style={{ color: theme.primary, fontSize: FS.md, fontWeight: FW.bold }}>{tr('تم', 'Done')}</Text>
              </TouchableOpacity>
            </View>
            <DateTimePicker
              value={new Date()}
              mode="time"
              is24Hour={true}
              display="spinner"
              onChange={(e, d) => onTimeChange(e, d)}
            />
          </View>
        </View>
      </Modal>
    ) : (
      <DateTimePicker
        value={new Date()}
        mode="time"
        is24Hour={true}
        display="default"
        onChange={onTimeChange}
      />
    )
  )}

 <NBtn label={tr(' حفظ الجدول الأسبوعي', ' Save Weekly Calendar')} disabled={vacationMode} loading={saving} onPress={handleSaveSchedule} style={{ marginVertical: SP.lg }} />

 {/* Exceptional Settings */}
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: SP.xl, marginBottom: SP.lg }}>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text }}>
 {tr(' إغلاق وحظر استثنائي', ' Exceptional Blocks & Closures')}
 </Text>
 <TouchableOpacity onPress={() => setShowAddException(true)} style={{ backgroundColor: theme.surface2, paddingHorizontal: SP.md, paddingVertical: SP.xs, borderRadius: R.md }}>
 <Text style={{ color: theme.primary, fontSize: FS.sm, fontWeight: FW.bold }}> {tr('إضافة استثناء', 'Add Rule')}</Text>
 </TouchableOpacity>
 </View>

 {exceptions.map(x => (
 <NCard key={x.id} style={{ marginBottom: SP.sm, paddingVertical: SP.md }}>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
 <View>
 <Text style={{ fontSize: FS.md, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>
 {x.date}
 </Text>
 <Text style={{ fontSize: FS.sm, color: x.type === 'exceptional_open' ? theme.success : theme.danger, textAlign: AR ? 'right' : 'left', marginTop: 4 }}>
 {AR ? x.labelAr : x.labelEn}
 </Text>
 </View>
 <TouchableOpacity onPress={() => handleDeleteException(x.id)}>
 <Text style={{ fontSize: FS.xl, color: theme.danger }}>️</Text>
 </TouchableOpacity>
 </View>
 </NCard>
 ))}
 </ScrollView>

 {/* Exception Sheet */}
 <NSheet visible={showAddException} onClose={() => setShowAddException(false)} title={tr(' إضافة قاعدة استثنائية', ' Add Exceptional Rule')} height={500}>
 <View style={{ padding: SP.md }}>
 <NInput label={tr('التاريخ (YYYY-MM-DD)', 'Date (YYYY-MM-DD)')} value={exDate} onChange={setExDate} />
 
 <Text style={{ fontSize: FS.sm, color: theme.text, marginBottom: SP.xs, textAlign: AR ? 'right' : 'left' }}>
 {tr('نوع القاعدة الاستثنائية', 'Rule Type')}
 </Text>
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, marginBottom: SP.lg }}>
 {(['close_day', 'block_time', 'exceptional_open'] as const).map(type => (
 <TouchableOpacity key={type} onPress={() => setExType(type)} style={{
 flex: 1, padding: SP.md, borderRadius: R.md, borderWidth: 1.5,
 borderColor: exType === type ? theme.primary : theme.border,
 backgroundColor: exType === type ? theme.primaryLight : theme.surface
 }}>
 <Text style={{ fontSize: 11, fontWeight: FW.bold, color: exType === type ? theme.primary : theme.text, textAlign: 'center' }}>
 {type === 'close_day' ? (tr('إغلاق اليوم', 'Close Day')) : type === 'block_time' ? (tr('حظر وقت', 'Block Time')) : (tr('فتح استثنائي', 'Open Slot'))}
 </Text>
 </TouchableOpacity>
 ))}
 </View>

 {exType !== 'close_day' && (
 <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: SP.md, marginBottom: SP.md }}>
 <View style={{ flex: 1 }}>
 <NInput label={tr('من وقت', 'From Time')} value={exStart} onChange={setExStart} />
 </View>
 <View style={{ flex: 1 }}>
 <NInput label={tr('إلى وقت', 'To Time')} value={exEnd} onChange={setExEnd} />
 </View>
 </View>
 )}

 <NBtn label={tr(' تطبيق القاعدة', ' Apply Rule')} onPress={handleAddException} style={{ marginTop: SP.md }} />
 </View>
 </NSheet>
 </View>
 );
}

function DoctorProfileEditScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme();
 const { lang } = useLang();
 const { show } = useToast();
 const { user } = useAuth();
 const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

 const [loading, setLoading] = useState(false);
 const [profile, setProfile] = useState<any>(null);
 const [nameAr, setNameAr] = useState('');
 const [nameEn, setNameEn] = useState('');
 const [descAr, setDescAr] = useState('');
 const [descEn, setDescEn] = useState('');
 const [exp, setExp] = useState('');
 const [web, setWeb] = useState('');
 const [specialty, setSpecialty] = useState('');
 const [degree, setDegree] = useState('');
 const [avatarUrl, setAvatarUrl] = useState('');

 useEffect(() => {
 fetchProfile();
 }, []);

 const fetchProfile = async () => {
 setLoading(true);
 try {
 const res = await client.get('/provider/profile');
 setProfile(res.data);
 setNameAr(res.data.display_name_ar || '');
 setNameEn(res.data.display_name_en || '');
 setDescAr(res.data.description_ar || '');
 setDescEn(res.data.description_en || '');
 setExp(String(res.data.years_of_experience || ''));
 setWeb(res.data.website || '');
 setAvatarUrl(res.data.profile_image_id || '');
 } catch (err) {
 show(tr('فشل تحميل الملف الشخصي', 'Failed to load profile'), 'error');
 } finally {
 setLoading(false);
 }
 };

 const handleSave = async () => {
 setLoading(true);
 try {
 await client.patch('/provider/profile', {
 display_name_ar: nameAr,
 display_name_en: nameEn,
 description_ar: descAr,
 description_en: descEn,
 years_of_experience: parseInt(exp) || 0,
 website: web,
 specialty,
 degree,
 });
 show(tr('تم حفظ التعديلات بنجاح', 'Profile updated successfully'), 'success');
 onBack();
 } catch (err) {
 show(tr('فشل حفظ الملف الشخصي', 'Failed to save profile'), 'error');
 } finally {
 setLoading(false);
 }
 };

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NScroll>
 <NHeader title={tr('تعديل الملف الشخصي', 'Edit Profile')} onBack={onBack} />
 {loading && !profile ? (
 <ActivityIndicator color={theme.primary} style={{ marginTop: SP.xl }} />
 ) : (
 <View style={{ padding: SP.xl, gap: SP.lg }}>
 <NCard style={{ alignItems: 'center', paddingVertical: SP.xl }}>
 <NAvatar name={nameEn || user?.displayName} size={80} />
 
 <NProfileImageUploader 
 ownerType="doctor" 
 onProcessComplete={(urls) => {
 setAvatarUrl(urls.processed);
 show(tr('تم تحديث الصورة الشخصية', 'Profile picture updated'), 'success');
 }}
 />
 </NCard>

 <NInput label={tr('الاسم بالكامل (العربية)', 'Full Name (Arabic)')} value={nameAr} onChange={setNameAr} required />
 <NInput label={tr('الاسم بالكامل (الإنجليزية)', 'Full Name (English)')} value={nameEn} onChange={setNameEn} required />
 <NInput label={tr('النبذة التعريفية (العربية)', 'Bio (Arabic)')} value={descAr} onChange={setDescAr} multi lines={3} />
 <NInput label={tr('النبذة التعريفية (الإنجليزية)', 'Bio (English)')} value={descEn} onChange={setDescEn} multi lines={3} />
 <NInput label={tr('سنوات الخبرة', 'Years of Experience')} value={exp} onChange={setExp} kbType="numeric" />
 <NInput label={tr('الموقع الإلكتروني', 'Website')} value={web} onChange={setWeb} />
 <NInput label={tr('التخصص الطبي', 'Specialty')} value={specialty} onChange={setSpecialty} />
 <NInput label={tr('الدرجة العلمية', 'Degree / Title')} value={degree} onChange={setDegree} />

 <View style={{ marginTop: SP.md }}>
   <NSecHeader title={tr('صور العيادة', 'Clinic Images')} />
 </View>
 <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexDirection: AR ? 'row-reverse' : 'row' }}>
   <TouchableOpacity style={{ width: 100, height: 100, borderRadius: R.md, backgroundColor: theme.surface2, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border, borderStyle: 'dashed', marginRight: SP.md }}>
     <I name="plus" size={24} color={theme.primary} />
     <Text style={{ fontSize: FS.xs, color: theme.primary, marginTop: SP.xs }}>{tr('إضافة صورة', 'Add Image')}</Text>
   </TouchableOpacity>
   {[1, 2].map(i => (
     <View key={i} style={{ width: 100, height: 100, borderRadius: R.md, backgroundColor: theme.surface2, marginRight: SP.md, overflow: 'hidden' }}>
       <IBg name="image" size={32} color={theme.textSub} bg="transparent" />
     </View>
   ))}
 </ScrollView>

 <NBtn label={tr(' حفظ التعديلات', ' Save Changes')} onPress={handleSave} loading={loading} style={{ marginTop: SP.lg }} />
 </View>
 )}
 </NScroll>
 </View>
 );
}

 // ══════════════════════════════════════════════════════════════════════════════
// DOCTOR LOCATION & MAP SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function DoctorLocationScreen({ onBack }: { onBack: () => void }) {
  const { theme } = useTheme(); const { lang } = useLang(); const { show } = useToast(); const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
  const [radius, setRadius] = useState('10');
  const [transportFee, setTransportFee] = useState('50');

  const handleSave = () => {
    show(tr('تم حفظ الموقع ونطاق التغطية', 'Location & Coverage Saved'), 'success');
    onBack();
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <NHeader title={tr('الموقع ونطاق التغطية', 'Location & Coverage')} onBack={onBack} />
      <ScrollView contentContainerStyle={{ padding: SP.xl, gap: SP.md }}>
        <NSecHeader title={tr('موقع العيادة', 'Clinic Location')} />
        <View style={{ height: 200, backgroundColor: theme.surface2, borderRadius: R.xl, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border, overflow: 'hidden' }}>
          <IBg name="mapPin" size={32} color={theme.primary} bg={`${theme.primary}12`} />
          <Text style={{ marginTop: SP.sm, color: theme.textSub, fontSize: FS.sm }}>{tr('خريطة تفاعلية لاختيار الموقع', 'Interactive Map for Location')}</Text>
        </View>

        <View style={{ marginTop: SP.lg }}>
          <NSecHeader title={tr('الزيارات المنزلية', 'Home Visits')} />
        </View>
        <NCard>
          <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: SP.md }}>
            <Text style={{ fontSize: FS.sm, color: theme.text }}>{tr('نطاق التغطية (كم)', 'Coverage Radius (KM)')}</Text>
            <NInput label="" value={radius} onChange={setRadius} kbType="numeric" style={{ width: 100, marginVertical: 0 }} />
          </View>
          <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ fontSize: FS.sm, color: theme.text }}>{tr('رسوم الانتقال', 'Transport Fee')}</Text>
            <NInput label="" value={transportFee} onChange={setTransportFee} kbType="numeric" style={{ width: 100, marginVertical: 0 }} />
          </View>
        </NCard>

        <NBtn label={tr('حفظ', 'Save')} onPress={handleSave} style={{ marginTop: SP.lg }} />
      </ScrollView>
    </View>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// INSURANCE CONFIG SCREEN
// ══════════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════════
// CERTIFICATES CONFIG SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function CertificatesConfigScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme(); const { lang } = useLang(); const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NHeader title={tr('الشهادات والمؤهلات', 'Qualifications')} onBack={onBack} />
 <ScrollView contentContainerStyle={{ padding: SP.lg, gap: SP.md }}>
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginBottom: SP.sm }}>
 {tr('لا تُعرض المؤهلات إلا بعد ربط هذه الشاشة بعقد وثائق مهنية موثق.', 'Qualifications are shown only after this screen is connected to a verified professional-document contract.')}
 </Text>
 <NEmpty title={tr('المؤهلات غير متاحة حتى يتم توثيق عقد المستندات المهنية.', 'Qualifications are unavailable until the professional-document contract is verified.')} icon="document" />
 </ScrollView>
 </View>
 );
}

// ══════════════════════════════════════════════════════════════════════════════
// PHOTOS & MEDIA SCREEN
// ══════════════════════════════════════════════════════════════════════════════
export function MediaConfigScreen({ onBack }: { onBack: () => void }) {
 const { theme } = useTheme(); const { lang } = useLang(); const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

 return (
 <View style={{ flex: 1, backgroundColor: theme.bg }}>
 <NHeader title={tr('الصور والوسائط', 'Photos & Media')} onBack={onBack} />
 <ScrollView contentContainerStyle={{ padding: SP.lg, gap: SP.md }}>
 <Text style={{ fontSize: FS.sm, color: theme.textSub, textAlign: AR ? 'right' : 'left', marginBottom: SP.sm }}>
 {tr('لا تُعرض الوسائط أو تُغيّر حتى يتم ربط هذه الشاشة بعقد وسائط ورفع آمن موثق.', 'Media is not displayed or changed until this screen is connected to a verified media and secure-upload contract.')}
 </Text>
 <NEmpty title={tr('الوسائط غير متاحة حتى يتم توثيق عقد التخزين والرفع.', 'Media is unavailable until the storage and upload contract is verified.')} icon="camera" />
 </ScrollView>
 </View>
 );
}



// ══════════════════════════════════════════════════════════════════════════════
// VIRTUAL WAITING ROOM (PHASE 2)
// ══════════════════════════════════════════════════════════════════════════════
function VirtualWaitingRoomScreen({ onBack, onNavigate }: { onBack: () => void, onNavigate: (s: string, p?: any) => void }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const { show } = useToast();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);
  
  const [patients, setPatients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWaitingRoom();
  }, []);

  const fetchWaitingRoom = async () => {
    setLoading(true);
    try {
      const headers = await buildHeaders(false);
      const res = await fetch(`${API_BASE}/calls/provider/waiting-room`, { headers });
      if (res.ok) {
        const data = await res.json();
        setPatients(data);
      } else {
        throw new Error('Failed to fetch waiting room');
      }
    } catch (e) {
      show(tr('حدث خطأ في تحميل الغرفة', 'Error loading waiting room'), 'error');
    } finally {
      setLoading(false);
    }
  };

  const pingPatient = async (patientId: string) => {
    try {
      const headers = await buildHeaders(false);
      const response = await fetch(`${API_BASE}/calls/provider/ping-patient`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ patient_id: patientId })
      });
      if (!response.ok) throw new Error('ping rejected');
      show(tr('تم إرسال إشعار للمريض', 'Ping sent'), 'info');
    } catch (e) {
      show(tr('فشل التنبيه', 'Failed to ping'), 'error');
    }
  };

  const markNoShow = async (patient: any) => {
    try {
      const headers = await buildHeaders(false);
      const response = await fetch(`${API_BASE}/calls/provider/no-show`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ appointment_id: patient.id })
      });
      if (!response.ok) throw new Error('no-show rejected');
      show(tr('تم تسجيل الغياب', 'Marked as no-show'), 'success');
      fetchWaitingRoom();
    } catch (e) {
      show(tr('فشل تسجيل الغياب', 'Failed to mark no-show'), 'error');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <NHeader title={tr('غرفة الانتظار الافتراضية', 'Virtual Waiting Room')} onBack={onBack} />
      <ScrollView contentContainerStyle={{ padding: SP.lg }}>
        <Text style={{ fontSize: FS.md, color: theme.textSub, marginBottom: SP.lg }}>
          {tr('المرضى الذين أجروا تسجيل دخول (Checked-in) وينتظرون بدء المكالمة:', 'Patients who checked in and are waiting:')}
        </Text>
        {loading && <Text style={{ color: theme.text }}>{tr('جاري التحميل...', 'Loading...')}</Text>}
        {!loading && patients.map(p => (
          <NCard key={p.id} style={{ marginBottom: SP.sm, padding: SP.lg }}>
            <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View>
                <Text style={{ fontSize: FS.lg, fontWeight: FW.bold, color: theme.text, textAlign: AR ? 'right' : 'left' }}>{p.name}</Text>
                <Text style={{ color: p.checkedIn ? theme.success : theme.textSub, textAlign: AR ? 'right' : 'left' }}>
                  {p.checkedIn ? (trT("متواجد (انتظار: {0})", "Checked-in (Wait: {0})", [p.waitTime])) : (tr('لم يحضر بعد', 'Not arrived'))}
                </Text>
              </View>
              <View style={{ gap: SP.sm }}>
                {p.checkedIn && (
                  <>
                    <NBtn label={tr('تنبيه (Ping)', 'Ping')} variant="outline" onPress={() => pingPatient(p.id)} />
                    <NBtn label={tr('بدء المكالمة', 'Start Call')} onPress={() => onNavigate('consultation', p)} />
                  </>
                )}
                {!p.checkedIn && (
                  <NBtn label={tr('غياب (No-Show)', 'No-Show')} variant="outline" onPress={() => markNoShow(p)} />
                )}
              </View>
            </View>
          </NCard>
        ))}
      </ScrollView>
    </View>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// PRE-VISIT CHAT (PHASE 2)
// ══════════════════════════════════════════════════════════════════════════════
function PreVisitChatScreen({ onBack }: { apt: any, onBack: () => void, onNavigate: (s: string, p?: any) => void }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const AR = lang === 'ar';
  const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <NHeader title={tr('محادثة ما قبل الموعد', 'Pre-visit Chat')} onBack={onBack} />
      <View style={{ flex: 1, justifyContent: 'center', padding: SP.lg }}>
        <NEmpty
          title={tr('الدردشة غير متاحة', 'Chat unavailable')}
          sub={tr(
            'لن نعرض رسائل أو مرفقات محلية، ولن نرسل رسالة قبل ربط الموعد بعقد thread مشارك ومصرح به من الخادم.',
            'No local messages or attachments are shown, and no message is sent until the appointment is bound to a server-authorized participant thread contract.',
          )}
          icon="chat"
        />
      </View>
    </View>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// INBOUND MEDICAL REPORTS SCREEN (Radiology & Labs)
// ══════════════════════════════════════════════════════════════════════════════

function InboundMedicalReportsScreen({ onBack }: { onBack: () => void }) {
  const { theme } = useTheme();
  const { lang } = useLang();
  const { show } = useToast();
  const AR = lang === 'ar';
 const tr = (ar: string, en: string) => translateProviderPair(lang, ar, en);
 const trT = (ar: string, en: string, values: readonly unknown[]) => translateProviderTemplate(lang, ar, en, values);

  const [loading, setLoading] = useState(false);
  const [reports, setReports] = useState<any[]>([]);

  useEffect(() => {
    // A private report-list contract has not been approved for this surface.
    setLoading(false);
    setReports([]);
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <NHeader title={tr('التقارير الطبية الواردة', 'Inbound Medical Reports')} onBack={onBack} />
      {loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={theme.primary} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 24, gap: 16 }}>
          {reports.length === 0 ? (
            <NEmpty title={tr('لا توجد تقارير', 'No Reports')} sub={tr('لا توجد نتائج جاهزة حتى الآن', 'No results available yet.')} icon="folder" />
          ) : (
            reports.map(report => (
              <NCard key={report.id} style={{ marginBottom: 16 }}>
                <View style={{ flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <View style={{ flexDirection: AR ? 'row-reverse' : 'row', alignItems: 'center', gap: 8 }}>
                    <I name={report.type === 'RADIOLOGY' ? 'camera' : 'flask'} size={24} color={theme.primary} />
                    <View>
                      <Text style={{ fontSize: 16, fontWeight: 'bold', color: theme.text, textAlign: AR ? 'right' : 'left' }}>{report.testName}</Text>
                      <Text style={{ fontSize: 14, color: theme.textSub, textAlign: AR ? 'right' : 'left' }}>{report.patientName} • {report.date}</Text>
                    </View>
                  </View>
                  <NBadge label={report.status} variant="success" size="sm" />
                </View>
                <View style={{ flexDirection: AR ? 'row-reverse' : 'row', gap: 8, marginTop: 16 }}>
                  {report.dicomViewerUrl && (
                    <TouchableOpacity 
                      onPress={() => Linking.openURL(report.dicomViewerUrl).catch(() => show(tr('فشل فتح العارض', 'Failed to open viewer'), 'error'))}
                      style={{ flex: 1, backgroundColor: theme.info, padding: 8, borderRadius: 8, alignItems: 'center', flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'center', gap: 4 }}>
                      <I name="eye" size={16} color="#FFF" />
                      <Text style={{ color: '#FFF', fontWeight: 'bold', fontSize: 14 }}>{tr('عرض صور الأشعة', 'DICOM Viewer')}</Text>
                    </TouchableOpacity>
                  )}
                  {report.pdfUrl && (
                    <TouchableOpacity 
                      onPress={() => Linking.openURL(report.pdfUrl).catch(() => show(tr('فشل فتح التقرير', 'Failed to open report'), 'error'))}
                      style={{ flex: 1, backgroundColor: theme.primary, padding: 8, borderRadius: 8, alignItems: 'center', flexDirection: AR ? 'row-reverse' : 'row', justifyContent: 'center', gap: 4 }}>
                      <I name="fileText" size={16} color="#FFF" />
                      <Text style={{ color: '#FFF', fontWeight: 'bold', fontSize: 14 }}>{tr('تقرير PDF', 'PDF Report')}</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </NCard>
            ))
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, borderBottomWidth: 1 },
  iconBtn: { padding: 8, borderRadius: 8 },
  viewChip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 16, borderWidth: 1 },
  filterChip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 16, borderWidth: 1 },
  timeTag: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4 },
  freqChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, borderWidth: 1 },
  drugRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderRadius: 8 },
  dayChip2: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, borderWidth: 1 },
  specChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, borderWidth: 1 },
  insureCheck: { width: 24, height: 24, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  secTab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2 },
  insChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, borderWidth: 1 },
  rTypeRow: { padding: 16, borderRadius: 8, marginBottom: 8, borderWidth: 1 },
  filterChip2: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 16, borderWidth: 1 },
  notifRow: { flexDirection: 'row', padding: 16, borderBottomWidth: 1, gap: 12 },
  notifIcon: { width: 40, height: 40, borderRadius: 20 },
  calRow: { paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, alignItems: 'center', gap: 12 },
  calIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#E5E7EB', alignItems: 'center', justifyContent: 'center' },
});
