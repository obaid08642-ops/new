import mongoose from 'mongoose';

/**
 * Catalog-governance backfill. This script is intentionally fail-closed:
 * legacy entities without an explicit publication decision become hidden from
 * public discovery until an authorized reviewer approves them.
 *
 * Usage:
 *   MONGO_URL=... npx ts-node scripts/backfill-catalog-governance.ts
 *   MONGO_URL=... CATALOG_GOVERNANCE_MIGRATION_CONFIRM=apply npx ts-node scripts/backfill-catalog-governance.ts --apply
 *   MONGO_URL=... CATALOG_GOVERNANCE_MIGRATION_CONFIRM=rollback npx ts-node scripts/backfill-catalog-governance.ts --rollback
 */

const collections = [
  'medicines_master',
  'provider_profiles',
  'facilities',
  'labservices',
  'radiologyservices',
  'homecareservices',
] as const;

const requiredFields = [
  'public_eligibility',
  'indexing_eligibility',
  'medical_review_status',
  'last_reviewed',
  'provenance',
] as const;

async function missingCounts(collection: mongoose.mongo.Collection) {
  return Object.fromEntries(await Promise.all(requiredFields.map(async (field) => [
    field,
    await collection.countDocuments({ [field]: { $exists: false } }),
  ])));
}

async function applyBackfill(collection: mongoose.mongo.Collection) {
  const now = new Date();
  const updates = await Promise.all([
    collection.updateMany(
      { public_eligibility: { $exists: false } },
      { $set: { public_eligibility: false } },
    ),
    collection.updateMany(
      { indexing_eligibility: { $exists: false } },
      { $set: { indexing_eligibility: false } },
    ),
    collection.updateMany(
      { medical_review_status: { $exists: false } },
      { $set: { medical_review_status: 'pending' } },
    ),
    collection.updateMany(
      { last_reviewed: { $exists: false } },
      { $set: { last_reviewed: null } },
    ),
    collection.updateMany(
      { provenance: { $exists: false } },
      { $set: { provenance: 'legacy_backfill_pending_review', catalog_governance_backfilled_at: now } },
    ),
  ]);
  return updates.map((result) => ({ matched: result.matchedCount, modified: result.modifiedCount }));
}

async function rollbackBackfill(collection: mongoose.mongo.Collection) {
  // Only undo untouched legacy rows. A reviewer changing status/provenance later
  // makes the row ineligible for rollback, preventing accidental unpublication.
  const filter = {
    provenance: 'legacy_backfill_pending_review',
    public_eligibility: false,
    indexing_eligibility: false,
    medical_review_status: 'pending',
  };
  return collection.updateMany(filter, {
    $unset: {
      public_eligibility: '',
      indexing_eligibility: '',
      medical_review_status: '',
      last_reviewed: '',
      provenance: '',
      catalog_governance_backfilled_at: '',
    },
  });
}

async function main() {
  const mongoUrl = process.env.MONGO_URL;
  if (!mongoUrl) throw new Error('MONGO_URL is required');
  const rollback = process.argv.includes('--rollback');
  const apply = process.argv.includes('--apply');
  const requiredConfirmation = rollback ? 'rollback' : 'apply';

  if (apply && rollback) throw new Error('choose only one of --apply or --rollback');
  await mongoose.connect(mongoUrl);
  try {
    for (const name of collections) {
      const collection = mongoose.connection.collection(name);
      if (!apply && !rollback) {
        console.log(JSON.stringify({ mode: 'dry-run', collection: name, missing: await missingCounts(collection) }));
        continue;
      }
      if (process.env.CATALOG_GOVERNANCE_MIGRATION_CONFIRM !== requiredConfirmation) {
        throw new Error(`refusing ${rollback ? 'rollback' : 'apply'} without CATALOG_GOVERNANCE_MIGRATION_CONFIRM=${requiredConfirmation}`);
      }
      const result = rollback ? await rollbackBackfill(collection) : await applyBackfill(collection);
      console.log(JSON.stringify({ mode: rollback ? 'rollback' : 'apply', collection: name, result }));
    }
  } finally {
    await mongoose.disconnect();
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack : error);
  process.exitCode = 1;
});
