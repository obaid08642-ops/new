# Insurance Logo Release Candidates

This directory contains **official-source, unmodified brand assets** converted to small transparent lossless WebP files for the Nabdah insurance catalogue. Each asset is accompanied by its original official-company URL and SHA-256 in `manifest.json`.

## Release Safety

These files are **not deployed**, uploaded to object storage, or linked to a live database by this candidate. A reviewer/DevOps owner must first upload the selected WebP files to the approved public catalogue-media bucket, then apply the matching `logo_url`, `logo_source_url`, `logo_sha256`, and `logo_verified_at` fields through the admin-reviewed catalogue update path.

The catalogue policy is non-destructive. Historical, suspended, renamed, merged, or retired companies remain stored in `insurance_companies` and can be reactivated after review. They are not removed merely because they are unsuitable for the current public selection flow.

## Asset Contract

| Property | Requirement |
|---|---|
| Format | WebP, lossless, transparent when the official source supports alpha |
| Size | Maximum bounding-box edge of 256 pixels |
| Provenance | Official insurer website only; no generated marks or third-party logo directories |
| Integrity | SHA-256 in `manifest.json` must match the uploaded asset |
| Publication | `logo_url` is assigned only after approved storage upload and reviewer confirmation |

## Current Candidate Scope

The current manifest has verified assets only for companies whose official website source was accessible and could be independently checked. Other records remain `pending_official_brand_source`, including records requiring legal-name/rebrand review. This deliberate incompleteness is fail-closed and must not be replaced with generated or unofficial logos.

The files are release artifacts, not a database migration. Running any existing seed script must not overwrite `logo_url`, `is_active`, `catalog_status`, or historical/supersession metadata.
