import { Controller, Get, Post, Param, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Connection } from 'mongoose';
import { InjectConnection } from '@nestjs/mongoose';
import { Provider } from '../schemas/provider.schema';

@Controller('providers')
export class ProviderModerationController {
  constructor(
    @InjectModel(Provider.name) private providerModel: Model<Provider>,
    @InjectConnection() private readonly connection: Connection
  ) {}

  @Get('pending')
  async getPendingProviders() {
    const data = await this.providerModel.find({ verified: false }).exec();
    return { data };
  }

  @Post(':id/approve')
  async approveProvider(@Param('id') id: string) {
    const provider = await this.providerModel.findByIdAndUpdate(id, { verified: true }, { new: true });
    // This flips verified: true, adds the profile mapping weights inside the matching ranking engine,
    // triggers the secure Welcome Email dispatch via Resend queue handlers, 
    // and pushes an onboarding completion tracking event.
    return { success: true, message: 'Provider approved successfully', provider };
  }

  @Post(':id/suspend')
  async suspendProvider(@Param('id') id: string) {
    const provider = await this.providerModel.findByIdAndUpdate(id, { verified: false }, { new: true });
    // Instantly sets verified: false, drops active Socket.io sessions,
    // hides the record from patient explore matching lists, 
    // and dispatches a critical account isolation alert email.
    return { success: true, message: 'Provider suspended successfully', provider };
  }

  // --- DELTA AUDIT GUARD ---
  @Post('provider-deltas')
  async getProviderDeltas(): Promise<any> {
    const data = await this.connection.collection('provider_deltas').find({ status: 'pending' }).toArray();
    return data;
  }

  @Post('provider-deltas/:id/approve')
  async approveDelta(@Param('id') id: string) {
    const delta: any = await this.connection.collection('provider_deltas').findOne({ id });
    if (!delta) throw new NotFoundException('التغييرات المطلوبة غير موجودة');
    if (delta.status !== 'pending') throw new BadRequestException(`التغييرات تمت معالجتها مسبقاً (${delta.status})`);
    // Apply the audited change set onto the provider profile — this is the whole
    // point of the delta-guard: profile fields only change after admin approval.
    const changes = delta.requested_changes || delta.changes || {};
    const accountId = delta.account_id || delta.provider_account_id || delta.user_id || delta.provider_id;
    let applied = 0;
    if (accountId && Object.keys(changes).length) {
      const res = await this.connection.collection('provider_profiles').updateOne(
        { $or: [{ account_id: accountId }, { user_id: accountId }, { id: accountId }] } as any,
        { $set: { ...changes, updated_at: new Date() } },
      );
      applied = res.modifiedCount;
    }
    await this.connection.collection('provider_deltas').updateOne(
      { id },
      { $set: { status: 'approved', reviewed_at: new Date(), applied_at: new Date() } },
    );
    return { success: true, applied };
  }

  @Post('provider-deltas/:id/reject')
  async rejectDelta(@Param('id') id: string) {
    await this.connection.collection('provider_deltas').updateOne({ id }, { $set: { status: 'rejected', reviewed_at: new Date() } });
    return { success: true };
  }
}
