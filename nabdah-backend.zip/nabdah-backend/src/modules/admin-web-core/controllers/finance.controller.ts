import { Body, Controller, Get, NotFoundException, Param, Post } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CommissionLedger } from '../schemas/commission-ledger.schema';
import { WithdrawalRequest } from '../schemas/withdrawal-request.schema';

/**
 * M5 fix: provider withdrawals written by provider-ops (`ProviderWithdrawal`,
 * state PENDING_ADMIN_APPROVAL) were invisible to this controller which read
 * only the legacy `WithdrawalRequest` (status 'pending'). Both collections are
 * now merged in a normalized shape, and execute/reject handle either source.
 */
@Controller('admin/finance')
export class FinanceController {
  constructor(
    @InjectModel(CommissionLedger.name) private commissionModel: Model<CommissionLedger>,
    @InjectModel(WithdrawalRequest.name) private withdrawalModel: Model<WithdrawalRequest>,
    @InjectModel('ProviderWithdrawal') private providerWithdrawalModel: Model<any>,
  ) {}

  @Get('commissions')
  async getCommissions() {
    const data = await this.commissionModel.find().exec();
    return { data };
  }

  @Get('withdrawals/pending')
  async getPendingWithdrawals() {
    const [legacy, providerOps] = await Promise.all([
      this.withdrawalModel.find({ status: 'pending' }).lean().exec(),
      this.providerWithdrawalModel.find({ state: 'PENDING_ADMIN_APPROVAL' }, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).lean().exec(),
    ]);
    const normalized = [
      ...(legacy || []).map((w: any) => ({
        id: String(w._id),
        source: 'legacy',
        providerId: w.providerId || w.provider_id,
        providerName: w.providerName || w.provider_name,
        amount: w.amount,
        bankName: w.bankName,
        iban: w.iban,
        status: 'pending',
        createdAt: w.createdAt,
      })),
      ...(providerOps || []).map((w: any) => ({
        id: w.id,
        source: 'provider_ops',
        providerId: w.provider_id,
        providerName: w.provider_name,
        amount: w.amount,
        iban: w.iban,
        note: w.note,
        status: 'pending',
        createdAt: w.createdAt,
      })),
    ].sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    return { data: normalized };
  }

  @Post('withdrawals/:id/execute')
  async executePayout(@Param('id') id: string) {
    // Legacy collection first (Mongo _id), then provider-ops (uuid id).
    const legacy = await this.withdrawalModel.findByIdAndUpdate(id, { status: 'completed' }, { new: true }).catch(() => null);
    if (legacy) {
      return { success: true, message: 'Payout executed successfully', withdrawal: legacy, source: 'legacy' };
    }
    const doc = await this.providerWithdrawalModel.findOneAndUpdate(
      { id, state: 'PENDING_ADMIN_APPROVAL' },
      { $set: { state: 'PAID', decided_at: new Date() } },
      { new: true },
    );
    if (!doc) throw new NotFoundException('withdrawal not found or already decided');
    return { success: true, message: 'Payout executed successfully', withdrawal: doc, source: 'provider_ops' };
  }

  @Post('withdrawals/:id/reject')
  async rejectPayout(@Param('id') id: string, @Body() body: any) {
    const legacy = await this.withdrawalModel.findByIdAndUpdate(id, { status: 'rejected' }, { new: true }).catch(() => null);
    if (legacy) {
      return { success: true, withdrawal: legacy, source: 'legacy' };
    }
    const doc = await this.providerWithdrawalModel.findOneAndUpdate(
      { id, state: 'PENDING_ADMIN_APPROVAL' },
      { $set: { state: 'REJECTED', note: body?.reason || undefined, decided_at: new Date() } },
      { new: true },
    );
    if (!doc) throw new NotFoundException('withdrawal not found or already decided');
    return { success: true, withdrawal: doc, source: 'provider_ops' };
  }
}
