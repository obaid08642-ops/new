import { Injectable, NotFoundException, BadRequestException, Inject, forwardRef, Optional } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Connection, Model } from 'mongoose';
import { v4 as uuid } from 'uuid';
import { VitalReading, MedicationReminder, SleepReading } from '../../schemas/health.schema';
import { VitalReadingRepository } from "./repositories/vitalreading.repository";
import { MedicationReminderRepository } from "./repositories/medicationreminder.repository";
import { SleepReadingRepository } from "./repositories/sleepreading.repository";
import { OrdersService } from '../orders/orders.service';

const VALID_TYPES = ['bp', 'glucose', 'heart_rate', 'weight', 'temperature', 'spo2'];

@Injectable()
export class HealthService {
  constructor(
    @Inject('VitalReadingRepository') private readonly vitals: VitalReadingRepository,
    @Inject('MedicationReminderRepository') private readonly reminders: MedicationReminderRepository,
    @Inject('SleepReadingRepository') private readonly sleepModel: SleepReadingRepository,
    @Inject(forwardRef(() => OrdersService)) private readonly orders: OrdersService,
    @InjectConnection() private readonly conn: Connection,
    @Optional() private readonly events?: EventEmitter2,
  ) {}

  // VITALS
  async addVital(user: any, data: any) {
    if (!VALID_TYPES.includes(data.type)) throw new BadRequestException('invalid type');
    if (!data.value && data.value !== 0) throw new BadRequestException('value required');
    const reading = await this.vitals.create({
      patient_id: user.id,
      type: data.type,
      value: String(data.value),
      value_secondary: data.value_secondary,
      unit: data.unit || this.defaultUnit(data.type),
      measured_at: data.measured_at ? new Date(data.measured_at) : new Date(),
      context: data.context,
      notes: data.notes,
      source: data.source || 'manual',
    });
    // Engagement loop: loyalty listens for this to award vitals_logged points (capped 5/day)
    try { this.events?.emit('health.vitals_logged', { user_id: user.id }); } catch {}
    return reading.toObject();
  }

  defaultUnit(t: string): string {
    return ({ bp: 'mmHg', glucose: 'mg/dL', heart_rate: 'bpm', weight: 'kg', temperature: '°C', spo2: '%' } as any)[t] || '';
  }

  async listVitals(user: any, type?: string, limit = 100) {
    const q: any = { patient_id: user.id };
    if (type) q.type = type;
    return this.vitals.find(q, { _id: 0, __v: 0 }).sort({ measured_at: -1 }).limit(Math.min(limit, 500));
  }

  /** Chart series for one vital across fixed windows — real readings only, empty arrays when none. */
  async vitalsChart(user: any, type: string) {
    if (!type) throw new BadRequestException('vital query param required');
    const now = Date.now();
    const windows: Record<string, { spanMs: number; buckets: number }> = {
      day: { spanMs: 24 * 3600e3, buckets: 8 },
      week: { spanMs: 7 * 24 * 3600e3, buckets: 7 },
      month: { spanMs: 30 * 24 * 3600e3, buckets: 10 },
      year: { spanMs: 365 * 24 * 3600e3, buckets: 12 },
    };
    const readings = await this.vitals.find(
      { patient_id: user.id, type, measured_at: { $gte: new Date(now - windows.year.spanMs) } },
      { _id: 0, value: 1, measured_at: 1 },
    ).sort({ measured_at: 1 });
    const result: Record<string, number[]> = { day: [], week: [], month: [], year: [] };
    for (const [key, w] of Object.entries(windows)) {
      const start = now - w.spanMs;
      const inRange = readings.filter((r: any) => new Date(r.measured_at).getTime() >= start);
      // average per bucket, omit empty buckets (honest series — no fabricated zeros)
      const perBucket: number[] = [];
      for (let b = 0; b < w.buckets; b++) {
        const bStart = start + (b * w.spanMs) / w.buckets;
        const bEnd = start + ((b + 1) * w.spanMs) / w.buckets;
        const vals = inRange
          .filter((r: any) => { const t = new Date(r.measured_at).getTime(); return t >= bStart && t < bEnd; })
          .map((r: any) => parseFloat(r.value))
          .filter((v: number) => isFinite(v));
        if (vals.length) perBucket.push(Math.round((vals.reduce((a, c) => a + c, 0) / vals.length) * 10) / 10);
      }
      result[key] = perBucket;
    }
    return result;
  }

  /** Most recent readings of one vital type. */
  async vitalsRecent(user: any, type: string, limit = 20) {
    const q: any = { patient_id: user.id };
    if (type) q.type = type;
    return this.vitals.find(q, { _id: 0, __v: 0 }).sort({ measured_at: -1 }).limit(Math.min(limit, 100));
  }

  async latestVitals(user: any) {
    const out: any = {};
    for (const t of VALID_TYPES) {
      const r = await this.vitals.findOne({ patient_id: user.id, type: t }, { _id: 0, __v: 0 }).sort({ measured_at: -1 });
      if (r) out[t] = r;
    }
    return out;
  }

  async vitalsSummary(user: any) {
    const latest = await this.latestVitals(user);
    const summary = [];

    const heartRate = latest['heart_rate'];
    if (heartRate) {
      summary.push({ icon: 'ecg_heart', label: 'نبض القلب', value: String(heartRate.value), unit: heartRate.unit || 'bpm', status: 'طبيعي', color: '#EC4899' });
    } else {
      summary.push({ icon: 'ecg_heart', label: 'نبض القلب', value: '--', unit: 'bpm', status: 'لا توجد قراءة', color: '#EC4899' });
    }

    // latestVitals keys are the canonical types: bp | glucose | heart_rate | weight
    const bloodSugar = latest['glucose'];
    if (bloodSugar) {
      summary.push({ icon: 'water_drop', label: 'سكر الدم', value: String(bloodSugar.value), unit: bloodSugar.unit || 'mg/dl', status: 'طبيعي', color: '#F0A526' });
    } else {
      summary.push({ icon: 'water_drop', label: 'سكر الدم', value: '--', unit: 'mg/dl', status: 'لا توجد قراءة', color: '#F0A526' });
    }

    const bloodPressure = latest['bp'];
    if (bloodPressure) {
      summary.push({ icon: 'blood_pressure', label: 'ضغط الدم', value: String(bloodPressure.value), unit: bloodPressure.unit || 'mmHg', status: 'طبيعي', color: '#8B5CF6' });
    } else {
      summary.push({ icon: 'blood_pressure', label: 'ضغط الدم', value: '--', unit: 'mmHg', status: 'لا توجد قراءة', color: '#8B5CF6' });
    }

    const weight = latest['weight'];
    if (weight) {
      summary.push({ icon: 'monitor_weight', label: 'الوزن', value: String(weight.value), unit: 'kg', status: 'مثالي', color: '#10B981' });
    } else {
      summary.push({ icon: 'monitor_weight', label: 'الوزن', value: '--', unit: 'kg', status: 'لا توجد قراءة', color: '#10B981' });
    }

    return summary;
  }

  /**
   * GET /health/score — REAL computed health score (0-100).
   * Weighted average over the components that have actual data; a component
   * with no data is EXCLUDED (never guessed). If fewer than 2 components have
   * data the score is null with status insufficient_data — honest by design.
   */
  async healthScore(user: any) {
    const [latest, profile, sleep, weekCount] = await Promise.all([
      this.latestVitals(user),
      this.conn.model('MedicalProfile').findOne({ patient_id: user.id }).select('height_cm weight_kg -_id').lean().catch(() => null),
      this.sleepModel.findOne({ patient_id: user.id } as any, { _id: 0, __v: 0 } as any).sort({ measured_at: -1 }).catch(() => null),
      this.vitals.countDocuments({ patient_id: user.id, measured_at: { $gte: new Date(Date.now() - 7 * 24 * 3600 * 1000) } } as any).catch(() => 0),
    ]);

    const components: any[] = [];
    const recommendations: string[] = [];

    // 1) BMI from profile measurements (weight 20)
    const p: any = profile;
    if (p?.height_cm > 0 && p?.weight_kg > 0) {
      const bmi = p.weight_kg / Math.pow(p.height_cm / 100, 2);
      const score = bmi < 18.5 ? 55 : bmi < 25 ? 100 : bmi < 30 ? 70 : bmi < 35 ? 40 : 20;
      components.push({ key: 'bmi', label: 'مؤشر كتلة الجسم', weight: 20, score, detail: { bmi: +bmi.toFixed(1) } });
      if (bmi >= 25) recommendations.push('مؤشر كتلة الجسم أعلى من الطبيعي — نشاط بدني منتظم وتغذية متوازنة يساعدان على خفضه');
    } else {
      recommendations.push('أكمل طولك ووزنك في الملف الصحي لتحسب درجتك بدقة أعلى');
    }

    // 2) Blood pressure (weight 20)
    const bp = latest['bp'];
    if (bp) {
      const [sys, dia] = String(bp.value).split('/').map((x: string) => parseFloat(x));
      const s = isNaN(sys) ? null : (sys <= 120 && (dia || 80) <= 80) ? 100 : (sys <= 130 && (dia || 85) <= 85) ? 80 : sys <= 140 ? 60 : 30;
      if (s !== null) {
        components.push({ key: 'bp', label: 'ضغط الدم', weight: 20, score: s, detail: { value: bp.value, measured_at: bp.measured_at } });
        if (s < 80) recommendations.push('قراءة ضغط الدم الأخيرة مرتفعة — قلل الملح وراقب الضغط بانتظام واستشر طبيبك');
      }
    }

    // 3) Glucose (weight 15)
    const gl = latest['glucose'];
    if (gl) {
      const v = parseFloat(gl.value);
      if (!isNaN(v)) {
        const s = v >= 80 && v <= 140 ? 100 : v <= 180 ? 60 : 30;
        components.push({ key: 'glucose', label: 'سكر الدم', weight: 15, score: s, detail: { value: gl.value, measured_at: gl.measured_at } });
        if (s < 100) recommendations.push('قراءة السكر خارج النطاق الطبيعي — راجع خطة وجباتك وأدويتك مع طبيبك');
      }
    }

    // 4) Heart rate (weight 10)
    const hr = latest['heart_rate'];
    if (hr) {
      const v = parseFloat(hr.value);
      if (!isNaN(v)) {
        const s = v >= 60 && v <= 100 ? 100 : (v >= 50 && v <= 110) ? 60 : 30;
        components.push({ key: 'heart_rate', label: 'نبض القلب', weight: 10, score: s, detail: { value: hr.value, measured_at: hr.measured_at } });
      }
    }

    // 5) Sleep (weight 15) — latest device/manual sleep score
    const sl: any = sleep;
    if (sl?.sleep_score != null) {
      components.push({ key: 'sleep', label: 'جودة النوم', weight: 15, score: Math.max(0, Math.min(100, sl.sleep_score)), detail: { duration_hours: sl.duration_hours, measured_at: sl.measured_at } });
      if (sl.sleep_score < 60) recommendations.push('جودة نومك تحتاج تحسيناً — ثبّت موعد النوم وقلل الشاشات قبله');
    }

    // 6) Tracking consistency (weight 20) — readings logged in the last 7 days
    if ((weekCount as number) > 0) {
      const s = weekCount >= 5 ? 100 : weekCount >= 3 ? 70 : 40;
      components.push({ key: 'tracking', label: 'انتظام التسجيل', weight: 20, score: s, detail: { readings_last_7d: weekCount } });
      if (s < 100) recommendations.push('سجّل مؤشراتك الحيوية بانتظام (٥ قراءات أسبوعياً) لرفع دقة درجتك');
    } else {
      recommendations.push('ابدأ بتسجيل مؤشراتك الحيوية (ضغط، سكر، وزن) لتفعيل درجة الصحة');
    }

    if (components.length < 2) {
      return {
        score: null,
        status: 'insufficient_data',
        components,
        recommendations,
        message: 'لا توجد بيانات كافية لحساب درجة الصحة — أكمل ملفك وسجّل مؤشراتك',
      };
    }

    const totalWeight = components.reduce((s, c) => s + c.weight, 0);
    const weighted = components.reduce((s, c) => s + c.score * c.weight, 0);
    const score = Math.round(weighted / totalWeight);
    return {
      score,
      status: score >= 80 ? 'excellent' : score >= 60 ? 'good' : score >= 40 ? 'fair' : 'needs_attention',
      components,
      recommendations: recommendations.slice(0, 4),
    };
  }

  async deleteVital(user: any, id: string) {
    const r = await this.vitals.findOneAndDelete({ id, patient_id: user.id });
    if (!r) throw new NotFoundException();
    return { ok: true };
  }

  async updateVital(user: any, id: string, data: any) {
    const r = await this.vitals.findOneAndUpdate({ id, patient_id: user.id }, { $set: data }, { new: true });
    if (!r) throw new NotFoundException();
    return r.toObject();
  }

  // MEDICATION REMINDERS
  async createReminder(user: any, data: any) {
    if (!data.medicine_name_ar) throw new BadRequestException('medicine_name_ar required');
    if (!Array.isArray(data.times) || !data.times.length) throw new BadRequestException('times required');
    const duration_days = parseInt(data.duration_days, 10) || 0;
    const end_date = duration_days > 0 ? new Date(Date.now() + duration_days * 86400 * 1000) : (data.end_date ? new Date(data.end_date) : undefined);
    const r = await this.reminders.create({
      patient_id: user.id,
      medicine_name_ar: data.medicine_name_ar,
      medicine_name_en: data.medicine_name_en,
      medicine_id: data.medicine_id,
      order_id: data.order_id,
      prescription_id: data.prescription_id,
      dose: data.dose || '1',
      dosage_count: parseInt(data.dosage_count, 10) || 1,
      dosage_form: data.dosage_form || 'tablet',
      times: data.times,
      frequency: data.frequency || 'daily',
      start_date: data.start_date ? new Date(data.start_date) : new Date(),
      end_date,
      duration_days,
      instructions_ar: data.instructions_ar,
      source: data.source || 'manual',
      active: true,
      chronic: !!data.chronic,
      pills_remaining: parseInt(data.pills_remaining, 10) || 0,
      refill_date: data.refill_date ? new Date(data.refill_date) : undefined,
    });
    return r.toObject();
  }

  /** Auto-create reminders from a dispensed order (called when order moves to DISPENSED/DELIVERED) */
  async fromOrder(user: any, orderItems: any[], orderId: string) {
    const out: any[] = [];
    for (const it of (orderItems || [])) {
      if (!it.name_ar) continue;
      const existing = await this.reminders.findOne({ patient_id: user.id, medicine_name_ar: it.name_ar, active: true });
      if (existing) continue;
      const r = await this.reminders.create({
        patient_id: user.id,
        medicine_name_ar: it.name_ar,
        medicine_name_en: it.name_en,
        medicine_id: it.medicine_id,
        order_id: orderId,
        dose: '1',
        dosage_count: 1,
        dosage_form: 'tablet',
        times: ['08:00', '20:00'],
        frequency: 'daily',
        duration_days: 7,
        end_date: new Date(Date.now() + 7 * 86400 * 1000),
        source: 'dispense',
        active: true,
      });
      out.push(r.toObject());
    }
    return out;
  }

  async listReminders(user: any, active = true) {
    const q: any = { patient_id: user.id };
    if (active) q.active = true;
    const rows = await this.reminders.find(q, { _id: 0, __v: 0 }).sort({ createdAt: -1 });
    // Annotate each reminder with TODAY's taken state derived from its log —
    // the app's toggle reads `taken` and must not reset on every reload.
    const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
    return rows.map((r: any) => {
      const obj = r.toObject ? r.toObject() : r;
      const takenToday = (obj.log || []).some(
        (e: any) => e?.status === 'taken' && e?.at && new Date(e.at) >= dayStart,
      );
      return { ...obj, taken: takenToday };
    });
  }

  async logReminder(user: any, id: string, status: 'taken' | 'skipped' | 'missed', time_key: string) {
    const r = await this.reminders.findOne({ id, patient_id: user.id });
    if (!r) throw new NotFoundException();
    r.log = [...(r.log || []), { at: new Date(), status, time_key }];
    await r.save();
    return r.toObject();
  }

  async toggleReminder(user: any, id: string, active: boolean) {
    const r = await this.reminders.findOneAndUpdate({ id, patient_id: user.id }, { $set: { active } }, { new: true });
    if (!r) throw new NotFoundException();
    return r.toObject();
  }

  /** Full reminder update — accepts any subset of editable fields. */
  async updateReminder(user: any, id: string, patch: any) {
    const allowed = ['medicine_name_ar', 'medicine_name_en', 'dose', 'dosage_count', 'dosage_form', 'times', 'frequency', 'start_date', 'end_date', 'duration_days', 'instructions_ar', 'active', 'chronic', 'pills_remaining', 'refill_date'];
    const $set: any = {};
    for (const k of allowed) if (patch[k] !== undefined) $set[k] = patch[k];
    if (Object.keys($set).length === 0) return { ok: false };
    const r = await this.reminders.findOneAndUpdate({ id, patient_id: user.id }, { $set }, { new: true });
    if (!r) throw new NotFoundException();
    return r.toObject();
  }

  async deleteReminder(user: any, id: string) {
    const r = await this.reminders.findOneAndDelete({ id, patient_id: user.id });
    if (!r) throw new NotFoundException();
    return { ok: true };
  }

  /**
   * Mark a "chronic" reminder for immediate refill broadcast.
   * Returns the items payload caller can pass to OrdersService.create() to
   * dispatch a real pharmacy order. We do not couple ordering here to keep
   * health module pure — the controller orchestrates with OrdersService.
   */
  async prepareRefill(user: any, id: string) {
    const r = await this.reminders.findOne({ id, patient_id: user.id });
    if (!r) throw new NotFoundException();
    return {
      reminder: r.toObject(),
      items: [
        {
          medicine_id: r.medicine_id,
          name_ar: r.medicine_name_ar,
          name_en: r.medicine_name_en,
          qty: 1,
        },
      ],
    };
  }

  /**
   * Complete refill flow: validate ownership → resolve default address →
   * create a REAL pharmacy order (source='refill') → advance the reminder's
   * next refill date. Replaces the previous UI-only simulation.
   */
  async refillNow(user: any, id: string) {
    const prep = await this.prepareRefill(user, id);
    // Resolve the patient's default delivery address from their profile
    const u: any = await (this.reminders as any).db.model('User').findOne({ id: user.id }).lean();
    const addrs: any[] = u?.addresses || [];
    const addr = addrs.find((a: any) => a.is_default) || addrs[0];
    if (!addr?.lat || !addr?.lng) {
      throw new BadRequestException('no_default_address: add a delivery address before reordering');
    }
    const order = await this.orders.create(user, {
      items: prep.items,
      delivery_address: { lat: addr.lat, lng: addr.lng, label: addr.label || addr.address || '', details: addr.details || '' },
      notes: `refill:${id}`,
    });
    // Tag the order as a refill so pharmacies see it in their refill inbox
    if (order?.id) {
      await (this.reminders as any).db.collection('orders').updateOne(
        { id: order.id },
        { $set: { source: 'refill', refill_reminder_id: id } },
      );
    }
    // Advance the reminder: pills restocked → next refill in ~30 days
    await this.reminders.findOneAndUpdate(
      { id, patient_id: user.id },
      { $set: { pills_remaining: 30, refill_date: new Date(Date.now() + 30 * 86400 * 1000) } },
    );
    return { ok: true, order_id: order?.id, state: order?.state };
  }

  /** Snooze refill date for a chronic reminder by N days (default 3) */
  async snoozeRefill(user: any, id: string, days = 3) {
    const r = await this.reminders.findOne({ id, patient_id: user.id });
    if (!r) throw new NotFoundException();
    const base = r.refill_date ? new Date(r.refill_date) : new Date();
    r.refill_date = new Date(base.getTime() + Math.max(1, days) * 86400 * 1000);
    await r.save();
    return r.toObject();
  }

  /** Cancel chronic refill auto-broadcast (turn off chronic flag) */
  async cancelChronic(user: any, id: string) {
    const r = await this.reminders.findOneAndUpdate(
      { id, patient_id: user.id },
      { $set: { chronic: false } },
      { new: true },
    );
    if (!r) throw new NotFoundException();
    return r.toObject();
  }

  /** Enrich list of reminders with refill insights (days_until_refill, needs_refill_soon) */
  async listRemindersEnriched(user: any, active = true) {
    const list: any[] = await this.listReminders(user, active);
    const now = Date.now();
    return list.map((r: any) => {
      const obj = r.toObject ? r.toObject() : r;
      let days_until_refill: number | null = null;
      if (obj.refill_date) {
        days_until_refill = Math.ceil((new Date(obj.refill_date).getTime() - now) / 86400000);
      }
      const needs_refill_soon = obj.chronic && days_until_refill !== null && days_until_refill <= 3;
      return { ...obj, days_until_refill, needs_refill_soon };
    });
  }

  // SLEEP METRICS
  async addSleep(user: any, data: any) {
    if (data.sleep_score === undefined || data.duration_hours === undefined) {
      throw new BadRequestException('sleep_score and duration_hours are required');
    }
    const reading = await this.sleepModel.create({
      patient_id: user.id,
      sleep_score: data.sleep_score,
      duration_hours: data.duration_hours,
      measured_at: data.measured_at ? new Date(data.measured_at) : new Date(),
      source: data.source || 'device',
    });
    return reading.toObject();
  }

  async listSleep(user: any, limit = 100) {
    return this.sleepModel.find({ patient_id: user.id }, { _id: 0, __v: 0 })
      .sort({ measured_at: -1 })
      .limit(Math.min(limit, 500));
  }

  // --- WP 1.5 Additional Health/Medical Profile Service Methods ---
  // All methods below read exclusively from real persisted data.

  /** Medical reports issued by doctors/facilities for this patient. */
  async listReports(user: any) {
    const rows = await this.conn.db.collection('medicalreports')
      .find({ patient_id: user.id }, { projection: { body: 0, 'attachments.base64': 0 } })
      .sort({ createdAt: -1 }).limit(50).toArray();
    return rows.map((r: any) => ({
      id: r.id,
      date: (r.issued_at || r.createdAt) ? new Date(r.issued_at || r.createdAt).toISOString().slice(0, 10) : null,
      title: r.title_ar || r.title_en || null,
      doctor: r.doctor_name || null,
      facility: r.facility_name || null,
      type: r.report_type || null,
      critical: !!r.critical,
      has_attachments: Array.isArray(r.attachments) && r.attachments.length > 0,
    }));
  }

  /** Active medication reminders — today adherence derived from the reminder log. */
  async listMedicationReminders(user: any) {
    const rows: any[] = await this.reminders.find({ patient_id: user.id, active: true }, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).limit(100);
    const today = new Date().toDateString();
    return rows.map((r: any) => {
      const o = typeof r.toObject === 'function' ? r.toObject() : r;
      const taken = Array.isArray(o.log) && o.log.some((l: any) => l.status === 'taken' && l.at && new Date(l.at).toDateString() === today);
      return {
        id: o.id,
        name: o.medicine_name_ar || o.medicine_name_en,
        dose: o.dose,
        time: Array.isArray(o.times) && o.times.length ? o.times[0] : null,
        times: o.times || [],
        frequency: o.frequency,
        chronic: !!o.chronic,
        instructions: o.instructions_ar || null,
        status: taken ? 'completed' : 'pending',
        taken,
      };
    });
  }

  /** Prescriptions from the prescriptions collection, doctor name resolved from users. */
  async listPrescriptions(user: any) {
    const rows = await this.conn.db.collection('prescriptions')
      .find({ patient_id: user.id }, { projection: { upload_image: 0 } })
      .sort({ createdAt: -1 }).limit(50).toArray();
    const doctorIds = [...new Set(rows.map((r: any) => r.doctor_id).filter(Boolean))];
    const doctors = doctorIds.length
      ? await this.conn.db.collection('users').find({ id: { $in: doctorIds } }, { projection: { id: 1, full_name: 1, name: 1 } }).toArray()
      : [];
    const nameOf = (id: string) => {
      const d: any = doctors.find((x: any) => x.id === id);
      return d ? (d.full_name || d.name || null) : null;
    };
    return rows.map((r: any) => ({
      id: r.id,
      date: r.createdAt ? new Date(r.createdAt).toISOString().slice(0, 10) : null,
      doctorName: r.doctor_id ? nameOf(r.doctor_id) : null,
      status: r.state || null,
      medications: (r.items || []).map((i: any) => i.medicine_name_ar || i.medicine_name_en).filter(Boolean),
      items: (r.items || []).map((i: any) => ({
        name: i.medicine_name_ar || i.medicine_name_en || null,
        dose: i.dose || null,
        frequency_hours: i.frequency_hours ?? null,
        duration_days: i.duration_days ?? null,
        instructions: i.instructions || null,
      })),
      isPurchased: !!r.order_id,
      isOcr: !!r.upload_image,
      diagnosis: r.diagnosis || null,
    }));
  }

  /** Patient-managed emergency contacts — embedded in the patient profile, empty when none added. */
  async listEmergencyContacts(user: any) {
    const p: any = await this.conn.db.collection('patient_profiles')
      .findOne({ user_id: user.id }, { projection: { emergency_contacts: 1 } });
    const list: any[] = Array.isArray(p?.emergency_contacts) ? p.emergency_contacts : [];
    return list.map((c: any, i: number) => ({
      id: c.id || `ec-${i}`,
      name: c.name,
      relation: c.relation || null,
      phone: c.phone,
      isPrimary: !!c.isPrimary,
    }));
  }

  async addEmergencyContact(user: any, data: any) {
    const name = String(data?.name || '').trim();
    const phone = String(data?.phone || '').trim();
    if (!name || name.length > 120) throw new BadRequestException('name required');
    if (!/^\+?[0-9\s-]{6,20}$/.test(phone)) throw new BadRequestException('valid phone required');
    const doc: any = {
      id: uuid(),
      name,
      relation: String(data?.relation || '').slice(0, 60) || null,
      phone,
      isPrimary: !!data?.isPrimary,
    };
    if (doc.isPrimary) {
      await this.conn.db.collection('patient_profiles').updateOne(
        { user_id: user.id }, { $set: { 'emergency_contacts.$[].isPrimary': false } });
    }
    await this.conn.db.collection('patient_profiles').updateOne(
      { user_id: user.id }, { $push: { emergency_contacts: doc } } as any, { upsert: true });
    return doc;
  }

  async removeEmergencyContact(user: any, id: string) {
    const col = this.conn.db.collection('patient_profiles');
    const p: any = await col.findOne({ user_id: user.id }, { projection: { emergency_contacts: 1 } });
    const list: any[] = Array.isArray(p?.emergency_contacts) ? p.emergency_contacts : [];
    const filtered = list.filter((c: any, i: number) => (c.id || `ec-${i}`) !== id);
    if (filtered.length === list.length) throw new NotFoundException('contact not found');
    await col.updateOne({ user_id: user.id }, { $set: { emergency_contacts: filtered } });
    return { ok: true };
  }

  /** Chronic conditions as recorded in the patient's own profile (self-declared). */
  async listChronicDiseases(user: any) {
    const p: any = await this.conn.db.collection('patient_profiles').findOne({ user_id: user.id }, { projection: { chronic_diseases: 1 } });
    const list: string[] = Array.isArray(p?.chronic_diseases) ? p.chronic_diseases : [];
    return list.map((name, i) => ({
      id: `cc-${i}`,
      name,
      controlled: null, // no clinical assessment data — the app renders this neutrally
      source: 'patient_profile',
    }));
  }

  /** Medications flagged chronic in the patient's reminders. */
  async listChronicMeds(user: any) {
    const rows: any[] = await this.reminders.find({ patient_id: user.id, chronic: true, active: true }, { _id: 0, __v: 0 }).limit(50);
    return rows.map((r: any) => {
      const o = typeof r.toObject === 'function' ? r.toObject() : r;
      return { id: o.id, name: o.medicine_name_ar || o.medicine_name_en, dose: o.dose, frequency: o.frequency };
    });
  }

  /** Vital trends computed from the patient's real readings only. */
  async listTrends(user: any) {
    const defs: any[] = [
      { id: 'glucose', name: 'سكر الدم', unit: 'mg/dL', normal: [70, 140] },
      { id: 'heart_rate', name: 'نبض القلب', unit: 'bpm', normal: [60, 100] },
      { id: 'bp', name: 'ضغط الدم الانقباضي', unit: 'mmHg', normal: [90, 120] },
      { id: 'spo2', name: 'أكسجين الدم', unit: '%', normal: [95, 100] },
      { id: 'temperature', name: 'درجة الحرارة', unit: '°C', normal: [36.1, 37.2] },
      { id: 'weight', name: 'الوزن', unit: 'kg', normal: null },
    ];
    const out: any[] = [];
    for (const d of defs) {
      const rows: any[] = await this.vitals.find({ patient_id: user.id, type: d.id }, { _id: 0, value: 1, measured_at: 1 }).sort({ measured_at: 1 }).limit(30);
      const data = rows
        .map((r: any) => {
          const o = typeof r.toObject === 'function' ? r.toObject() : r;
          return { value: Number(String(o.value).split('/')[0]), at: o.measured_at };
        })
        .filter((x: any) => !isNaN(x.value));
      if (!data.length) continue;
      const current = data[data.length - 1].value;
      const first = data[0].value;
      const trendDir = data.length < 2 || current === first ? 'flat' : current > first ? 'up' : 'down';
      out.push({
        id: d.id,
        name: d.name,
        unit: d.unit,
        normal: d.normal,
        current,
        trendDir,
        labels: data.map((x: any) => new Date(x.at).toISOString().slice(5, 10)),
        data,
      });
    }
    return out;
  }
}
