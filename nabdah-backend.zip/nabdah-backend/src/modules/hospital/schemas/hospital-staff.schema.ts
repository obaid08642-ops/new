import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type HospitalStaffDocument = HospitalStaff & Document;

@Schema({ timestamps: true })
export class HospitalStaff {
  @Prop({ type: String, ref: 'User', required: true, index: true })
  user_id: string;

  @Prop({ type: String, ref: 'User', required: true, index: true })
  hospital_id: string;

  @Prop({ type: String, ref: 'HospitalBranch', index: true })
  branch_id: string;

  @Prop({ type: String, ref: 'HospitalDepartment', index: true })
  department_id: string;

  @Prop({ required: true, enum: ['receptionist', 'branch_admin', 'finance', 'doctor', 'lab_tech'] })
  role: string;

  @Prop({ default: true })
  is_active: boolean;
}

export const HospitalStaffSchema = SchemaFactory.createForClass(HospitalStaff);
