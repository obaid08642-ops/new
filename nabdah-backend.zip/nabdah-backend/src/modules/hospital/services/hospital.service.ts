import { Injectable, BadRequestException, UnauthorizedException, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { HospitalBranch } from '../schemas/hospital-branch.schema';
import { HospitalDepartment } from '../schemas/hospital-department.schema';
import { HospitalStaff } from '../schemas/hospital-staff.schema';
import { HospitalInvitation } from '../schemas/hospital-invitation.schema';
import { DoctorProfileExtended } from '../../care/schemas/doctor-profile-extended.schema';
import { User } from '../../../schemas/user.schema';
import { Appointment } from '../../../schemas/appointment.schema';

// Whitelist of permission keys a facility may grant through an invitation —
// anything else in the payload is silently dropped (mass-assignment guard).
const INVITATION_PERMISSION_KEYS = [
  'pricing', 'schedule', 'insurance', 'vacation', 'availability',
  'online_consultation', 'home_visit', 'catalog', 'read_stats', 'manage_wallet',
];

@Injectable()
export class HospitalService {
  constructor(
    @InjectModel(HospitalBranch.name) private branchModel: Model<HospitalBranch>,
    @InjectModel(HospitalDepartment.name) private departmentModel: Model<HospitalDepartment>,
    @InjectModel(HospitalStaff.name) private staffModel: Model<HospitalStaff>,
    @InjectModel(HospitalInvitation.name) private invitationModel: Model<HospitalInvitation>,
    @InjectModel(DoctorProfileExtended.name) private doctorModel: Model<DoctorProfileExtended>,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Appointment.name) private appointmentModel: Model<Appointment>,
  ) {}

  // ── Facility → provider invitations (additive) ────────────────────────────

  async createInvitation(facilityId: string, body: { identifier?: string; role?: string; permissions?: Record<string, boolean> }) {
    const identifier = (body?.identifier || '').trim();
    if (!identifier) throw new BadRequestException('identifier_required');
    const invitee: any = await this.userModel.findOne({
      $or: [{ phone: identifier }, { email: identifier.toLowerCase() }, { id: identifier }],
    }).lean();
    if (!invitee) throw new NotFoundException('provider_not_found');
    if (invitee.id === facilityId) throw new BadRequestException('cannot_invite_self');
    const permissions = Object.fromEntries(
      Object.entries(body?.permissions || {})
        .filter(([k]) => INVITATION_PERMISSION_KEYS.includes(k))
        .map(([k, v]) => [k, !!v]),
    );
    // One pending invitation per facility+invitee — re-sending returns it.
    const existing = await this.invitationModel.findOne({ facility_id: facilityId, invitee_id: invitee.id, status: 'pending' });
    if (existing) return existing;
    return this.invitationModel.create({
      facility_id: facilityId,
      invitee_id: invitee.id,
      invitee_identifier: identifier,
      role: body?.role || 'doctor',
      permissions,
    });
  }

  async listFacilityInvitations(facilityId: string) {
    const inv = await this.invitationModel.find({ facility_id: facilityId }).sort({ createdAt: -1 }).lean();
    const users: any[] = await this.userModel.find({ id: { $in: inv.map(i => i.invitee_id) } }).lean();
    const byId = new Map(users.map(u => [u.id, u]));
    return inv.map(i => ({ ...i, invitee_name: byId.get(i.invitee_id)?.full_name || null }));
  }

  async listMyInvitations(userId: string) {
    const inv = await this.invitationModel.find({ invitee_id: userId }).sort({ createdAt: -1 }).lean();
    const facilities: any[] = await this.userModel.find({ id: { $in: inv.map(i => i.facility_id) } }).lean();
    const byId = new Map(facilities.map(u => [u.id, u]));
    return inv.map(i => ({ ...i, facility_name: byId.get(i.facility_id)?.full_name || null }));
  }

  async respondInvitation(userId: string, invitationId: string, accept: boolean) {
    const inv = await this.invitationModel.findOne({ id: invitationId });
    // Ownership check: only the invitee may respond (no IDOR).
    if (!inv || inv.invitee_id !== userId) throw new NotFoundException('invitation_not_found');
    if (inv.status !== 'pending') throw new BadRequestException('invitation_already_responded');
    inv.status = accept ? 'accepted' : 'rejected';
    inv.responded_at = new Date();
    await inv.save();
    if (accept) {
      // Link the provider under the facility with the granted permissions.
      await this.userModel.updateOne(
        { id: userId },
        { $set: { parent_provider_account_id: inv.facility_id, permissions: Object.keys(inv.permissions || {}).filter(k => inv.permissions[k]) } },
      );
    }
    return inv;
  }

  async createBranch(hospitalId: string, data: Partial<HospitalBranch>) {
    return this.branchModel.create({ ...data, hospital_id: hospitalId });
  }

  async getBranches(hospitalId: string) {
    return this.branchModel.find({ hospital_id: hospitalId });
  }

  async createDepartment(hospitalId: string, data: Partial<HospitalDepartment>) {
    return this.departmentModel.create({ ...data, hospital_id: hospitalId });
  }

  async getDepartments(hospitalId: string) {
    return this.departmentModel.find({ hospital_id: hospitalId });
  }

  async addStaff(hospitalId: string, data: Partial<HospitalStaff>) {
    return this.staffModel.create({ ...data, hospital_id: hospitalId });
  }

  async getStaff(hospitalId: string) {
    return this.staffModel.find({ hospital_id: hospitalId });
  }

  async onboardDoctor(hospitalId: string, doctorId: string) {
    const doctorProfile = await this.doctorModel.findOneAndUpdate(
      { doctor_id: doctorId },
      { $set: { affiliated_hospital_id: hospitalId } },
      { new: true, upsert: true }
    );

    // User accounts use the business UUID in `id`; `_id` is Mongo's internal key.
    // Auto-approve the doctor at the system level because hospital takes legal responsibility.
    await this.userModel.updateOne(
      { id: doctorId },
      { $set: { verified: true, active: true } },
    );
    
    return doctorProfile;
  }

  async getUnifiedAppointments(hospitalId: string, branchId?: string) {
    // 1. Find all doctors affiliated with this hospital
    const doctors = await this.doctorModel.find({ affiliated_hospital_id: hospitalId });
    const doctorIds = doctors.map(d => String(d.doctor_id));

    const query: any = { doctor_id: { $in: doctorIds } };
    // Receptionists can see this
    return this.appointmentModel.find(query).sort({ slot_start: 1 }).limit(100);
  }

  async updateAppointmentStatus(hospitalId: string, appointmentId: string, status: string) {
    // Note: status must be one of APPT_STATES
    const appointment = await this.appointmentModel.findOneAndUpdate(
      { _id: new Types.ObjectId(appointmentId) },
      { $set: { status } },
      { new: true }
    );
    if (!appointment) throw new BadRequestException('Appointment not found');
    return appointment;
  }

  async getAggregatedWallet(hospitalId: string, userRole: string) {
    // Only Finance or Admin can see wallet. Receptionist is blocked.
    if (userRole === 'receptionist') {
      throw new UnauthorizedException('Access Denied: Financial data restricted.');
    }
    
    // 1. Find all doctors affiliated with this hospital
    const doctors = await this.doctorModel.find({ affiliated_hospital_id: hospitalId });
    const doctorIds = doctors.map(d => String(d.doctor_id));

    // 2. Aggregate all completed appointments for these doctors
    const completed = await this.appointmentModel.find({
      doctor_id: { $in: doctorIds },
      status: 'COMPLETED'
    });
    
    let totalRevenue = 0;
    completed.forEach(app => {
      totalRevenue += (app.total_price || 0);
    });
    
    return {
      success: true,
      total_revenue: totalRevenue,
      transactions_count: completed.length
    };
  }
}

