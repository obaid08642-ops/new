/**
 * M2 — Provider Ops Completion Module.
 *
 * Implements the genuinely-missing API surface that the Provider/Patient apps
 * already call (audit 2.3): reviews, provider wallet views, today-stats,
 * working-hours/schedule settings, consultation end, home-care compatibility
 * paths, nursing ops reference data, and chat aliases.
 *
 * Everything persists to real Mongo collections — no stubs, no console-log fakery.
 */
import { Module, Controller, Injectable, Get, Post, Put, Body, Param, Query, UseGuards, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectModel, MongooseModule } from '@nestjs/mongoose';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { v4 as uuid } from 'uuid';
import { JwtAuthGuard, CurrentUser } from '../../common/auth.guard';
import { WalletModule } from '../wallet/wallet.module';
import { WalletService } from '../wallet/wallet.service';
import { ChatModule } from '../chat/chat.module';
import { ChatService } from '../chat/chat.module';
import { OrderSchema, OrderDocument } from '../../schemas/order.schema';
import { LabBookingSchema } from '../../schemas/lab.schema';
import { RadiologyBookingSchema } from '../../schemas/radiology.schema';
import { HomeCareBookingSchema, HomeCareServiceSchema } from '../../schemas/home-care.schema';
import { AppointmentSchema } from '../../schemas/appointment.schema';
import { ProviderProfileSchema } from '../../schemas/provider-profile.schema';

// ============================================================================
// Schemas (new, real persistence)
// ============================================================================

@Schema({ timestamps: true })
export class ProviderReview {
  @Prop({ required: true, unique: true, default: () => uuid() }) id: string;
  @Prop({ required: true, index: true }) target_id: string;       // provider profile/user id
  @Prop({ default: 'provider', index: true }) target_type: string; // provider | pharmacy | lab | radiology | nursing
  @Prop({ required: true, index: true }) author_id: string;
  @Prop({ default: 'patient' }) author_role: string;
  @Prop() author_name?: string;
  @Prop({ required: true, min: 1, max: 5 }) rating: number;
  @Prop() comment?: string;
  @Prop() booking_id?: string;
  @Prop({ type: Object }) reply?: { text: string; at: Date };
}
export const ProviderReviewSchema = SchemaFactory.createForClass(ProviderReview);
ProviderReviewSchema.index({ target_id: 1, createdAt: -1 });

@Schema({ timestamps: true })
export class ProviderWithdrawal {
  @Prop({ required: true, unique: true, default: () => uuid() }) id: string;
  @Prop({ required: true, index: true }) provider_id: string;
  @Prop({ required: true }) amount: number;
  @Prop({ default: 'PENDING_ADMIN_APPROVAL', index: true }) state: string; // PENDING_ADMIN_APPROVAL | APPROVED | PAID | REJECTED
  @Prop() iban?: string;
  @Prop() note?: string;
  @Prop() decided_by?: string;
  @Prop() decided_at?: Date;
}
export const ProviderWithdrawalSchema = SchemaFactory.createForClass(ProviderWithdrawal);

// ============================================================================
// Reviews — system was completely absent from the backend (audit C9)
// ============================================================================

@Injectable()
export class ReviewsService {
  constructor(
    @InjectModel('ProviderReview') private reviews: Model<any>,
    @InjectModel('ProviderProfile') private profiles: Model<any>,
  ) {}

  async create(author: any, body: any) {
    const rating = Number(body?.rating);
    if (!rating || rating < 1 || rating > 5) throw new BadRequestException('rating must be 1..5');
    if (!body?.target_id) throw new BadRequestException('target_id is required');
    const doc = await this.reviews.create({
      target_id: body.target_id,
      target_type: body.target_type || 'provider',
      author_id: author.id,
      author_role: author.role || 'patient',
      author_name: author.full_name,
      rating,
      comment: body.comment,
      booking_id: body.booking_id,
    });
    // keep running aggregate on the provider profile (fields tolerated by schema)
    const agg = await this.reviews.aggregate([
      { $match: { target_id: body.target_id } },
      { $group: { _id: null, avg: { $avg: '$rating' }, count: { $sum: 1 } } },
    ]);
    if (agg[0]) {
      await this.profiles.updateOne(
        { id: body.target_id },
        { $set: { rating_avg: Math.round(agg[0].avg * 10) / 10, rating_count: agg[0].count } },
      );
    }
    return doc.toObject();
  }

  async listForProvider(user: any, q: any) {
    const page = Math.max(1, parseInt(q?.page || '1', 10) || 1);
    const limit = Math.min(50, parseInt(q?.limit || '20', 10) || 20);
    const filter = { target_id: user.id };
    const [items, total, agg] = await Promise.all([
      this.reviews.find(filter, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
      this.reviews.countDocuments(filter),
      this.reviews.aggregate([{ $match: filter }, { $group: { _id: null, avg: { $avg: '$rating' }, count: { $sum: 1 } } }]),
    ]);
    return {
      items,
      total,
      page,
      average: agg[0] ? Math.round(agg[0].avg * 10) / 10 : null,
      count: agg[0]?.count || 0,
    };
  }

  async listPublic(targetId: string, q: any) {
    const limit = Math.min(50, parseInt(q?.limit || '20', 10) || 20);
    return this.reviews
      .find({ target_id: targetId }, { _id: 0, __v: 0, author_id: 0 })
      .sort({ createdAt: -1 }).limit(limit).lean();
  }

  async reply(user: any, reviewId: string, text: string) {
    const review = await this.reviews.findOne({ id: reviewId });
    if (!review) throw new NotFoundException('review not found');
    if (review.target_id !== user.id && user.role !== 'admin') {
      throw new ForbiddenException('only the reviewed provider can reply');
    }
    if (!text?.trim()) throw new BadRequestException('reply text is required');
    review.reply = { text: text.trim(), at: new Date() };
    await review.save();
    return review.toObject();
  }
}

@Controller()
@UseGuards(JwtAuthGuard)
export class ReviewsController {
  constructor(private readonly svc: ReviewsService) {}

  // Provider app: GET /provider/reviews
  @Get('provider/reviews') myReviews(@CurrentUser() u: any, @Query() q: any) { return this.svc.listForProvider(u, q); }
  // Provider app: POST /provider/reviews/:id/reply
  @Post('provider/reviews/:id/reply') reply(@CurrentUser() u: any, @Param('id') id: string, @Body() b: any) {
    return this.svc.reply(u, id, b?.text || b?.reply || '');
  }
  // Patient app: POST /reviews (post-consultation rating)
  @Post('reviews') create(@CurrentUser() u: any, @Body() b: any) { return this.svc.create(u, b); }
  // Public listing for provider profile screens
  @Get('reviews') listPublic(@Query('target_id') targetId: string, @Query() q: any) {
    if (!targetId) throw new BadRequestException('target_id is required');
    return this.svc.listPublic(targetId, q);
  }
}

// ============================================================================
// Provider wallet views + real withdrawal (was a console.log stub)
// ============================================================================

@Controller('provider/wallet')
@UseGuards(JwtAuthGuard)
export class ProviderWalletViewController {
  constructor(
    private readonly wallet: WalletService,
    @InjectModel('ProviderWithdrawal') private withdrawals: Model<any>,
  ) {}

  @Get() async summary(@CurrentUser() u: any) {
    const [balance, tx] = await Promise.all([
      this.wallet.getBalance(u.id, 'provider'),
      this.wallet.getTransactions(u.id, 'provider', 1, 5),
    ]);
    const pending = await this.withdrawals.countDocuments({ provider_id: u.id, state: 'PENDING_ADMIN_APPROVAL' });
    return { balance, currency: 'SAR', recent_transactions: (tx as any)?.transactions || [], pending_withdrawals: pending };
  }

  @Get('transactions') transactions(@CurrentUser() u: any, @Query() q: any) {
    return this.wallet.getTransactions(u.id, 'provider', parseInt(q?.page || '1', 10) || 1, parseInt(q?.limit || '20', 10) || 20);
  }

  @Post('withdraw') async withdraw(@CurrentUser() u: any, @Body() body: any) {
    const amount = Number(body?.amount);
    if (!amount || amount <= 0) throw new BadRequestException('amount must be positive');
    const balance = await this.wallet.getBalance(u.id, 'provider');
    if (amount > balance) throw new BadRequestException('المبلغ يتجاوز الرصيد المتاح');
    const doc = await this.withdrawals.create({ provider_id: u.id, amount, iban: body?.iban, note: body?.note });
    return { ok: true, id: doc.id, state: doc.state, amount };
  }

  @Get('withdrawals') myWithdrawals(@CurrentUser() u: any) {
    return this.withdrawals.find({ provider_id: u.id }, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).limit(50).lean();
  }
}

// ============================================================================
// Today stats + provider ops (working hours, schedule settings, consultation end)
// ============================================================================

@Controller('provider')
@UseGuards(JwtAuthGuard)
export class ProviderOpsController {
  constructor(
    @InjectModel('Order') private orders: Model<OrderDocument>,
    @InjectModel('HomeCareBooking') private hcBookings: Model<any>,
    @InjectModel('LabBooking') private labBookings: Model<any>,
    @InjectModel('RadiologyBooking') private radBookings: Model<any>,
    @InjectModel('Appointment') private appointments: Model<any>,
    @InjectModel('ProviderProfile') private profiles: Model<any>,
  ) {}

  /** GET /provider/stats/today — live counts for the dashboard header. */
  @Get('stats/today') async today(@CurrentUser() u: any) {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const pid = u.id;
    const day = { $gte: start };
    const [consultations, homeCare, lab, radiology, revenueAgg] = await Promise.all([
      this.appointments.countDocuments({ doctor_id: pid, createdAt: day }),
      this.hcBookings.countDocuments({ provider_id: pid, createdAt: day }),
      this.labBookings.countDocuments({ provider_id: pid, createdAt: day }),
      this.radBookings.countDocuments({ provider_id: pid, createdAt: day }),
      this.orders.aggregate([
        { $match: { pharmacy_id: pid, createdAt: day, payment_status: 'paid' } },
        { $group: { _id: null, total: { $sum: '$total' } } },
      ]),
    ]);
    return {
      date: start.toISOString().slice(0, 10),
      consultations, home_care: homeCare, lab, radiology,
      total_jobs: consultations + homeCare + lab + radiology,
      revenue_today: revenueAgg[0]?.total || 0,
      currency: 'SAR',
    };
  }

  /** PUT /provider/working-hours — persist weekly schedule on the profile. */
  @Put('working-hours') async setWorkingHours(@CurrentUser() u: any, @Body() body: any) {
    const hours = body?.working_hours || body?.hours || body;
    if (!Array.isArray(hours)) throw new BadRequestException('working_hours must be an array');
    await this.profiles.updateOne({ id: u.id }, { $set: { working_hours: hours } });
    return { ok: true, working_hours: hours };
  }

  /** POST /provider/schedule/settings — booking preferences (slot length, buffers...). */
  @Post('schedule/settings') async scheduleSettings(@CurrentUser() u: any, @Body() body: any) {
    await this.profiles.updateOne({ id: u.id }, { $set: { schedule_settings: body } }, { upsert: false });
    return { ok: true, settings: body };
  }

  /** POST /provider/consultation/end — close a consultation appointment. */
  @Post('consultation/end') async endConsultation(@CurrentUser() u: any, @Body() body: any) {
    const id = body?.appointment_id || body?.id;
    if (!id) throw new BadRequestException('appointment_id is required');
    const appt = await this.appointments.findOne({ id });
    if (!appt) throw new NotFoundException('appointment not found');
    if ((appt as any).doctor_id !== u.id && u.role !== 'admin') throw new ForbiddenException();
    (appt as any).status = 'COMPLETED';
    (appt as any).completed_at = new Date();
    await appt.save();
    return { ok: true, id, status: 'COMPLETED' };
  }
}

// ============================================================================
// Module
// ============================================================================

@Module({
  imports: [
    WalletModule,
    ChatModule,
    MongooseModule.forFeature([
      { name: 'ProviderReview', schema: ProviderReviewSchema },
      { name: 'ProviderWithdrawal', schema: ProviderWithdrawalSchema },
      { name: 'Order', schema: OrderSchema },
      { name: 'HomeCareBooking', schema: HomeCareBookingSchema },
      { name: 'HomeCareService', schema: HomeCareServiceSchema },
      { name: 'LabBooking', schema: LabBookingSchema },
      { name: 'RadiologyBooking', schema: RadiologyBookingSchema },
      { name: 'Appointment', schema: AppointmentSchema },
      { name: 'ProviderProfile', schema: ProviderProfileSchema },
    ]),
  ],
  controllers: [ReviewsController, ProviderWalletViewController, ProviderOpsController],
  providers: [ReviewsService],
  exports: [ReviewsService],
})
export class ProviderOpsModule {}
