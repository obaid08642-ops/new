import { BadRequestException, NotFoundException } from '@nestjs/common';
import { SimulatedFeaturesController } from './simulated-features.controller';

describe('SimulatedFeaturesController security contracts', () => {
  const model = (overrides: any = {}) => ({ findOne: jest.fn(), find: jest.fn(), create: jest.fn(), findOneAndUpdate: jest.fn(), ...overrides });
  const makeController = (overrides: any = {}) => new SimulatedFeaturesController(
    model(), model(), model(), model(overrides.userModel), model(overrides.homeCare), model(overrides.reports), model(overrides.radiology),
  );

  it('rejects a nurse attempting to check in another provider\'s booking', async () => {
    const booking = { id: 'booking-1', provider_id: 'provider-owner', save: jest.fn() };
    const homeCare = model({ findOne: jest.fn().mockResolvedValue(booking) });
    const controller = new SimulatedFeaturesController(model(), model(), model(), model(), homeCare, model(), model());

    await expect(controller.homeCareCheckin('booking-1', { lat: 24, lng: 46 } as any, { id: 'provider-other', role: 'provider', provider_type: 'home_care' }))
      .rejects.toBeInstanceOf(NotFoundException);
    expect(booking.save).not.toHaveBeenCalled();
  });

  it('requires a real file reference before accepting a radiology report', async () => {
    const booking = { id: 'rad-1', radiology_center_id: 'center-1', reports: [], save: jest.fn() };
    const radiology = model({ findOne: jest.fn().mockResolvedValue(booking) });
    const userModel = model({ findOne: jest.fn().mockReturnValue({ lean: jest.fn().mockResolvedValue({ _id: 'center-1' }) }) });
    const controller = new SimulatedFeaturesController(model(), model(), model(), userModel, model(), model(), radiology);

    await expect(controller.uploadRadiologyReport('rad-1', { report_text: 'result' } as any, { id: 'rad-provider', role: 'provider', provider_type: 'radiology' }))
      .rejects.toBeInstanceOf(BadRequestException);
    expect(booking.save).not.toHaveBeenCalled();
  });

  it('does not publish an empty radiology report', async () => {
    const booking = { id: 'rad-1', radiology_center_id: 'center-1', reports: [], save: jest.fn() };
    const radiology = model({ findOne: jest.fn().mockResolvedValue(booking) });
    const userModel = model({ findOne: jest.fn().mockReturnValue({ lean: jest.fn().mockResolvedValue({ _id: 'center-1' }) }) });
    const controller = new SimulatedFeaturesController(model(), model(), model(), userModel, model(), model(), radiology);

    await expect(controller.publishRadiologyReport('rad-1', { id: 'rad-provider', role: 'provider', provider_type: 'radiology' }))
      .rejects.toBeInstanceOf(BadRequestException);
    expect(booking.save).not.toHaveBeenCalled();
  });
});
