import { Module } from '@nestjs/common';
import { AiService } from './ai.service';
import { AiController } from './ai.controller';
import { AiProviderService } from './ai-provider.service';
@Module({
  controllers: [AiController],
  providers: [AiService, AiProviderService],
  exports: [AiService, AiProviderService],
})
export class AiModule {}
