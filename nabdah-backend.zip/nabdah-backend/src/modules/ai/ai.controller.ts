import { Body, Controller, Post, Get, Param, Query, Req, UseGuards, UseInterceptors, UploadedFile } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { AiService } from './ai.service';
import { AiGatewayService } from './ai-gateway.service';
import { JwtAuthGuard, Public, Roles } from '../../common/auth.guard';
import { UserRole } from '../../common/enums';

@Controller('ai')
@UseGuards(JwtAuthGuard)
export class AiController {
  constructor(private svc: AiService, private gateway: AiGatewayService) {}

  @Get('config')
  @Roles(UserRole.ADMIN)
  getConfig() {
    return this.svc.getAiConfig();
  }

  @Post('config')
  @Roles(UserRole.ADMIN)
  updateConfig(@Body() body: any) {
    return this.svc.updateAiConfig(body);
  }

  /** AI Gateway admin: full provider registry + mode. */
  @Get('admin/gateway')
  @Roles(UserRole.ADMIN)
  gatewayStatus() {
    return this.gateway.listProviders();
  }

  /** Admin: enable/disable/rekey/re-model/re-priority a provider. */
  @Post('admin/gateway/provider/:key')
  @Roles(UserRole.ADMIN)
  updateProvider(@Param('key') key: any, @Body() body: any) {
    return this.gateway.updateProvider(key, body);
  }

  /** Admin: auto fallback & round-robin OR manual pinned provider. */
  @Post('admin/gateway/mode')
  @Roles(UserRole.ADMIN)
  setMode(@Body() body: { mode: 'auto' | 'manual'; pinned?: any }) {
    return this.gateway.setMode(body?.mode || 'auto', body?.pinned);
  }

  /** Admin: usage/token report per provider+model+feature (with fallback counts). */
  @Get('admin/usage')
  @Roles(UserRole.ADMIN)
  usage(@Query('days') days?: string) {
    return this.gateway.usageReport(parseInt(days || '7'));
  }

  @Public()
  @Post('triage')
  triage(@Req() req: any, @Body() body: any) {
    return this.svc.triage(body, req.user?.id);
  }

  @Post('voice-to-order')
  @UseInterceptors(FileInterceptor('audio'))
  voice(@UploadedFile() file: any, @Body() body: { transcript?: string }) {
    if (file) {
      return this.svc.voiceToOrderFile(file.buffer);
    }
    return this.svc.voiceToOrder(body.transcript || '');
  }

  @Post('prescription-ocr')
  ocr(@Body() body: { image_base64?: string; imageBase64?: string }) {
    const base64 = body.image_base64 || body.imageBase64 || '';
    return this.svc.prescriptionOcr(base64);
  }

  @Post('parse-excel')
  @UseInterceptors(FileInterceptor('document'))
  parseExcel(@UploadedFile() file: any) {
    if (!file) throw new Error('No file uploaded');
    return this.svc.parseExcel(file.buffer);
  }

  @Post('copilot/suggest')
  copilotSuggest(@Body() body: { notes: string }) {
    return this.svc.copilotSuggest(body.notes || '');
  }

  @Post('triage/chat')
  triageChat(@Body() body: { messages: { role: 'user' | 'assistant' | 'system'; content: string }[] }) {
    return this.svc.triageChat(body.messages || []);
  }

  /** OCR + bilingual translation of a prescription image — uses GEMINI_KEY_OCR */
  @Post('ocr-translate')
  ocrTranslate(@Body() body: { image_base64: string; target_lang?: string }) {
    return this.svc.ocrTranslate(body.image_base64 || '', body.target_lang || 'ar');
  }

  @Post('skin-analysis')
  skinAnalysis(@Body() body: { image_base64: string; area?: string }) {
    return this.svc.skinAnalysis(body.image_base64, body.area);
  }

  @Post('medicine-image-search')
  medicineImageSearch(@Body() body: { image_base64: string }) {
    return this.svc.medicineImageSearch(body.image_base64);
  }

  @Post('barcode-lookup')
  barcodeLookup(@Body() body: { code: string }) {
    return this.svc.barcodeLookup(body.code);
  }

  @Post('analyze-meal')
  analyzeMeal(@Body() body: { query: string; image_base64?: string }) {
    return this.svc.analyzeMeal(body.query || '', body.image_base64);
  }

  @Post('generate-diet-plan')
  generateDietPlan(@Body() body: {
    goal: string;
    gender: string;
    weight: number;
    height: number;
    age: number;
    targetWeight: number;
    activity: string;
    diet: string;
    allergies: string;
  }) {
    return this.svc.generateDietPlan(body);
  }
}

