// @ts-nocheck
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { MongoRepository } from '../../../common/database/mongo.repository';
// Ensure correct import
import {  MedicationReminder, any  } from '../../../schemas/health.schema';

@Injectable()
export class MedicationReminderRepository extends MongoRepository<any> {
  constructor(@InjectModel(MedicationReminder.name) model: Model<any>) {
    super(model);
  }
}
