import { ForbiddenException } from '@nestjs/common';
import { LiveKitService } from './livekit.service';

describe('LiveKitService session authorization', () => {
  const session = {
    id: 'session-1',
    room_name: 'room-1',
    patient_id: 'patient-1',
    provider_id: 'provider-1',
    status: 'INITIATED',
    _id: 'mongo-id',
  };

  const makeService = () => {
    const collection = {
      findOne: jest.fn().mockResolvedValue(session),
      updateOne: jest.fn().mockResolvedValue({ acknowledged: true }),
    };
    const conn = { collection: jest.fn().mockReturnValue(collection) } as any;
    const appointments = { find: jest.fn() } as any;
    const events = { emit: jest.fn() } as any;
    return { service: new LiveKitService(appointments, conn, events), collection };
  };

  it('rejects a non-participant from reading a session', async () => {
    const { service } = makeService();
    await expect(service.getSessionById('session-1', 'other-user', 'patient'))
      .rejects.toBeInstanceOf(ForbiddenException);
  });

  it('rejects a non-participant from joining a session', async () => {
    const { service } = makeService();
    await expect(service.joinCall('session-1', 'other-user', 'Other'))
      .rejects.toBeInstanceOf(ForbiddenException);
  });

  it('allows a participant and returns room contract without Mongo internals', async () => {
    const { service } = makeService();
    const result = await service.getSessionById('session-1', 'patient-1', 'patient');
    expect(result).toEqual(expect.objectContaining({ id: 'session-1', room_name: 'room-1' }));
    expect(result).not.toHaveProperty('_id');
  });
});
