import { AccessToken } from 'livekit-server-sdk';
import { InjectModel, InjectConnection } from '@nestjs/mongoose';
import { Model, Connection } from 'mongoose';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { UserRole } from '../../common/enums';

@Injectable()
export class LiveKitService {
  private readonly logger = new Logger(LiveKitService.name);

  constructor(
    @InjectModel('Appointment') private readonly appointments: Model<any>,
    @InjectConnection() private readonly conn: Connection,
    private readonly events: EventEmitter2,
  ) {}

  private get callSessions() { return this.conn.collection('callsessions'); }

  private async sessionForActor(sessionId: string, userId: string, role?: string) {
    const session: any = await this.callSessions.findOne({ $or: [{ id: sessionId }, { room_name: sessionId }] } as any);
    if (!session) throw new NotFoundException('Call session not found');
    const isAdmin = role === UserRole.ADMIN || role === UserRole.SUPER_ADMIN;
    if (!isAdmin && session.patient_id !== userId && session.provider_id !== userId) {
      throw new ForbiddenException('You are not a participant in this call');
    }
    return session;
  }

  async createToken(roomName: string, participantName: string): Promise<string> {
    this.logger.log(`Creating LiveKit token for ${participantName} in ${roomName}`);
    if (!process.env.LIVEKIT_API_KEY || !process.env.LIVEKIT_API_SECRET) {
      throw new Error('LIVEKIT_NOT_CONFIGURED');
    }
    const at = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, {
      identity: participantName,
      ttl: '2h', // short-lived per production hardening policy
    });
    at.addGrant({ roomJoin: true, room: roomName });
    return at.toJwt();
  }

  async getProviderWaitingRoom(providerId: string) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const appointments = await this.appointments.find({
      provider_id: providerId,
      status: { $in: ['SCHEDULED', 'IN_PROGRESS', 'CHECKED_IN'] },
      scheduled_time: { $gte: today, $lt: tomorrow }
    }).lean();

    return appointments.map((a: any) => ({
      id: a.id || a._id?.toString(),
      name: a.patient_name || 'مريض',
      time: a.scheduled_time,
      checkedIn: a.status === 'CHECKED_IN',
      waitTime: a.status === 'CHECKED_IN' ? 'جاهز' : 'ينتظر'
    }));
  }

  async pingPatient(providerId: string, patientId: string) {
    this.logger.log(`Provider ${providerId} is pinging patient ${patientId}`);
    // Real delivery — the push module's @OnEvent('call.incoming') listener
    // fans this out to every registered device of the patient.
    this.events.emit('call.incoming', {
      patientId,
      callerName: 'طبيبك',
      callType: 'video',
      sessionId: providerId,
    });
    return { success: true, delivered_via: 'push:call.incoming' };
  }

  async markNoShow(providerId: string, appointmentId: string) {
    const appt = await this.appointments.findOne({ _id: appointmentId, provider_id: providerId });
    if (!appt) throw new NotFoundException('Appointment not found');

    appt.status = 'NO_SHOW';
    await appt.save();
    return { success: true, message: 'Marked as no-show' };
  }

  async initiateCall(providerId: string, providerName: string, calleeId: string, callType: string, bookingId?: string) {
    const roomName = `room-${bookingId || Math.random().toString(36).substring(7)}`;
    const token = await this.createToken(roomName, providerName);

    // Persist the session so history/analytics/admin views are REAL
    const sessionId = `call_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await this.callSessions.insertOne({
      id: sessionId,
      appointment_id: bookingId || 'direct',
      patient_id: calleeId,
      provider_id: providerId,
      room_name: roomName,
      call_type: callType || 'video',
      status: 'INITIATED',
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    // Ring the callee on all their devices (push listener: call.incoming)
    this.events.emit('call.incoming', {
      patientId: calleeId,
      callerName: providerName,
      callType: callType || 'video',
      sessionId: roomName,
    });

    return { room_name: roomName, token, call_type: callType, session_id: sessionId };
  }

  async joinCall(sessionId: string, userId: string, userName: string) {
    const session: any = await this.sessionForActor(sessionId, userId);
    const roomName = session.room_name;
    const token = await this.createToken(roomName, userName);
    await this.callSessions.updateOne(
      { id: session.id, status: 'INITIATED' },
      { $set: { status: 'ACTIVE', started_at: new Date(), updatedAt: new Date() } },
    );
    return { room_name: roomName, token, session_id: session.id };
  }

  async endCall(sessionId: string, userId: string) {
    const session: any = await this.sessionForActor(sessionId, userId);
    this.logger.log(`User ${userId} ended call ${session.id}`);
    const started = session.started_at ? new Date(session.started_at).getTime() : null;
    const duration = started ? Math.max(0, Math.round((Date.now() - started) / 1000)) : 0;
    await this.callSessions.updateOne(
      { id: session.id },
      { $set: { status: 'ENDED', ended_at: new Date(), duration_seconds: duration, updatedAt: new Date() } },
    );
    return { success: true };
  }

  async rejectCall(sessionId: string, userId: string) {
    const session: any = await this.sessionForActor(sessionId, userId);
    await this.callSessions.updateOne(
      { id: session.id },
      { $set: { status: 'FAILED', end_reason: 'rejected', ended_at: new Date(), updatedAt: new Date() } },
    );
    return { success: true };
  }

  async saveMetrics(sessionId: string, userId: string, metrics: any) {
    const session: any = await this.sessionForActor(sessionId, userId);
    this.logger.log(`Saving metrics for ${session.id}`);
    await this.callSessions.updateOne(
      { id: session.id },
      { $set: { metrics, metrics_saved_at: new Date(), updatedAt: new Date() } },
    );
    return { success: true };
  }

  async getCallHistory(userId: string, page = 1, limit = 20) {
    const safeLimit = Math.min(Math.max(limit || 20, 1), 100);
    const safePage = Math.max(page || 1, 1);
    const filter = { $or: [{ patient_id: userId }, { provider_id: userId }] };
    const [rows, total] = await Promise.all([
      this.callSessions.find(filter as any, { projection: { _id: 0 } })
        .sort({ createdAt: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit).toArray(),
      this.callSessions.countDocuments(filter as any),
    ]);
    return {
      data: rows.map((s: any) => ({
        id: s.id,
        appointment_id: s.appointment_id,
        room_name: s.room_name,
        call_type: s.call_type,
        status: s.status,
        started_at: s.started_at || null,
        ended_at: s.ended_at || null,
        duration_seconds: s.duration_seconds || 0,
        end_reason: s.end_reason || null,
      })),
      total,
      page: safePage,
      total_pages: Math.ceil(total / safeLimit),
    };
  }

  async getSessionById(sessionId: string, userId: string, role?: string) {
    const s: any = await this.sessionForActor(sessionId, userId, role);
    const { _id, ...safe } = s;
    return safe;
  }

  async getActiveRooms() {
    const rows = await this.callSessions
      .find({ status: { $in: ['INITIATED', 'ACTIVE'] } }, { projection: { _id: 0 } })
      .sort({ createdAt: -1 }).limit(100).toArray();
    return rows.map((s: any) => ({
      room_name: s.room_name,
      appointment_id: s.appointment_id,
      patient_id: s.patient_id,
      provider_id: s.provider_id,
      call_type: s.call_type,
      status: s.status,
      started_at: s.started_at || null,
    }));
  }

  async getCallAnalytics() {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const [agg] = await this.callSessions.aggregate([
      {
        $group: {
          _id: null,
          total_calls: { $sum: 1 },
          completed: { $sum: { $cond: [{ $eq: ['$status', 'ENDED'] }, 1, 0] } },
          failed: { $sum: { $cond: [{ $eq: ['$status', 'FAILED'] }, 1, 0] } },
          total_minutes: { $sum: { $round: [{ $divide: [{ $ifNull: ['$duration_seconds', 0] }, 60] }, 1] } },
          avg_duration_seconds: { $avg: { $ifNull: ['$duration_seconds', 0] } },
        },
      },
    ]).toArray();
    const calls_today = await this.callSessions.countDocuments({ createdAt: { $gte: todayStart } });
    return {
      total_calls: agg?.total_calls || 0,
      completed: agg?.completed || 0,
      failed: agg?.failed || 0,
      total_minutes: agg?.total_minutes || 0,
      avg_duration_seconds: Math.round(agg?.avg_duration_seconds || 0),
      calls_today,
    };
  }

  /** LiveKit server RoomService — available when LIVEKIT_URL is configured. */
  private roomService(): any | null {
    if (!process.env.LIVEKIT_URL || !process.env.LIVEKIT_API_KEY || !process.env.LIVEKIT_API_SECRET) return null;
    try {
      const { RoomServiceClient } = require('livekit-server-sdk');
      return new RoomServiceClient(process.env.LIVEKIT_URL, process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET);
    } catch {
      return null;
    }
  }

  async getRoomParticipants(roomName: string) {
    const svc = this.roomService();
    if (!svc) return [];
    const list = await svc.listParticipants(roomName).catch(() => []);
    return (list || []).map((p: any) => ({
      identity: p.identity,
      name: p.name,
      state: p.state,
      is_publisher: p.isPublisher,
      tracks: (p.tracks || []).map((t: any) => ({ type: t.type, source: t.source, muted: t.muted })),
    }));
  }

  async muteParticipant(roomName: string, participantId: string, muted: boolean) {
    const svc = this.roomService();
    if (!svc) return { success: false, reason: 'livekit_not_configured' };
    const p = await svc.getParticipant(roomName, participantId).catch(() => null);
    if (!p) return { success: false, reason: 'participant_not_found' };
    for (const track of p.tracks || []) {
      await svc.mutePublishedTrack(roomName, participantId, track.sid, muted).catch(() => null);
    }
    return { success: true };
  }

  async removeParticipant(roomName: string, participantId: string) {
    const svc = this.roomService();
    if (!svc) return { success: false, reason: 'livekit_not_configured' };
    await svc.removeParticipant(roomName, participantId).catch(() => null);
    return { success: true };
  }
}
