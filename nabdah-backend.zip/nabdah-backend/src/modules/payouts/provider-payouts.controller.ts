/**
 * Provider-initiated withdrawal requests — providers request payouts;
 * admin executes/rejects (existing finance.controller flow).
 */
import { Controller, Post, Get, Body, UseGuards, BadRequestException } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { Connection } from 'mongoose';
import { JwtAuthGuard, CurrentUser } from '../../common/auth.guard';

@Controller('provider/payouts')
@UseGuards(JwtAuthGuard)
export class ProviderPayoutsController {
  constructor(@InjectConnection() private readonly conn: Connection) {}

  private get withdrawals() { return this.conn.collection('withdrawals'); }

  @Post('request')
  async request(@CurrentUser() user: any, @Body() body: { amount?: number; iban?: string }) {
    const w = await this.conn.collection('platformledgerentries').aggregate([
      { $match: { provider_account_id: user.id } },
      { $group: { _id: null, earned: { $sum: { $cond: [{ $eq: ['$type', 'provider_earning'] }, '$amount', 0] } }, paid: { $sum: { $cond: [{ $eq: ['$type', 'payout'] }, '$amount', 0] } } } },
    ]).toArray().catch(() => []);
    const balance = w[0] ? Math.max(0, (w[0].earned || 0) - (w[0].paid || 0)) : 0;

    const minimum = (await this.conn.collection('finance_config').findOne({ key: 'commissions' }))?.payout_schedule?.minimum_payout_sar ?? 100;
    const amount = body?.amount ?? balance;

    if (amount < minimum) {
      throw new BadRequestException(`minimum withdrawal is ${minimum} SAR (your balance: ${balance})`);
    }
    if (amount > balance && balance < minimum) {
      throw new BadRequestException(`insufficient balance (${balance} SAR) for minimum withdrawal ${minimum} SAR`);
    }

    const pending = await this.withdrawals.findOne({ provider_id: user.id, status: 'pending' });
    if (pending) throw new BadRequestException('you already have a pending withdrawal request');

    const profile: any = await this.conn.collection('provider_profiles').findOne(
      { $or: [{ user_id: user.id }, { account_id: user.id }] } as any,
    );

    const doc = {
      id: `wd_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      provider_id: user.id,
      provider_type: user.role,
      amount,
      iban: body?.iban || profile?.iban || null,
      bank_account_name: profile?.bank_account_name || null,
      status: 'pending',
      balance_at_request: balance,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    await this.withdrawals.insertOne(doc);
    return { ok: true, request: doc, available_balance: balance, minimum };
  }

  @Get('mine')
  mine(@CurrentUser() user: any): Promise<any[]> {
    return this.withdrawals.find({ provider_id: user.id }, { projection: { _id: 0 } }).sort({ createdAt: -1 }).limit(50).toArray();
  }
}
