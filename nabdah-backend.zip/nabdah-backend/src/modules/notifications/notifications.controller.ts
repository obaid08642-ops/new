import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { CurrentUser, JwtAuthGuard, Roles } from '../../common/auth.guard';
import { UserRole } from '../../common/enums';

@Controller('notifications')
@UseGuards(JwtAuthGuard)
export class NotificationsController {
  constructor(private svc: NotificationsService) {}

  @Get()
  list(@CurrentUser() user: any) {
    return this.svc.listForUser(user);
  }

  @Post(':id/read')
  read(@Param('id') id: string, @CurrentUser() user: any) {
    return this.svc.markRead(id, user);
  }

  @Post('read-all')
  readAll(@CurrentUser() user: any) {
    return this.svc.markAllRead(user);
  }

  @Post('admin/send')
  @Roles(UserRole.ADMIN)
  send(@Body() body: any) {
    return this.svc.create(body);
  }

  // M6/ER-8: admin — schedule a notification for future delivery
  @Post('admin/schedule')
  @Roles(UserRole.ADMIN)
  schedule(@Body() body: any) {
    if (!body?.scheduled_at) throw new Error('scheduled_at is required');
    return this.svc.create(body);
  }

  // M6/ER-8: admin — delivery status analytics
  @Get('admin/delivery-stats')
  @Roles(UserRole.ADMIN)
  deliveryStats() {
    return this.svc.deliveryStats();
  }
}
