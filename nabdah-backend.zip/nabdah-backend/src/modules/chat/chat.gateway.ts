import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  ConnectedSocket,
  MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ForbiddenException, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { getWebSocketCorsOptions } from '../../config/websocket-cors';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const jwt = require('jsonwebtoken');

@WebSocketGateway({
  cors: getWebSocketCorsOptions(),
})
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger(ChatGateway.name);

  // In a real app, use Redis adapter for multi-instance deployments
  private activeUsers = new Map<string, string>(); // socketId -> userId

  constructor(@InjectModel('ChatThread') private readonly threads: Model<any>) {}

  private async assertThreadMember(socket: Socket, threadId: string): Promise<string> {
    const userId = this.activeUsers.get(socket.id);
    if (!userId) throw new ForbiddenException('socket_not_authenticated');
    const thread: any = await this.threads.findOne({ id: threadId }, { participant_ids: 1 }).lean();
    if (!thread || !thread.participant_ids?.includes(userId)) {
      throw new ForbiddenException('not_thread_participant');
    }
    return userId;
  }

  async handleConnection(socket: Socket) {
    // M6/ER-11: identity must come from a verified JWT — previously any client
    // could claim any userId via handshake auth (spoofing hole).
    let userId: string | null = null;
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.replace(/^Bearer\s+/i, '');
    if (token) {
      try {
        const secret = process.env.JWT_SECRET;
        if (!secret) { this.logger.error('Socket rejected: JWT_SECRET not configured'); socket.disconnect(); return; }
        const payload: any = jwt.verify(token, secret);
        userId = payload?.sub || payload?.id || payload?.user_id || null;
      } catch {
        this.logger.warn('Socket rejected: invalid JWT');
      }
    }
    if (userId) {
      this.activeUsers.set(socket.id, userId);
      socket.join(userId);
      this.logger.log(`User ${userId} connected (Socket: ${socket.id})`);
    } else {
      socket.disconnect();
    }
  }

  handleDisconnect(socket: Socket) {
    const userId = this.activeUsers.get(socket.id);
    if (userId) {
      this.activeUsers.delete(socket.id);
      this.logger.log(`User ${userId} disconnected`);
    }
  }

  @SubscribeMessage('join_thread')
  @SubscribeMessage('chat:join')
  async handleJoinThread(
    @ConnectedSocket() socket: Socket,
    @MessageBody() data: { threadId?: string; thread_id?: string },
  ) {
    const threadId = data.threadId || data.thread_id;
    if (!threadId) return { error: 'thread_id_required' };
    await this.assertThreadMember(socket, threadId);
    socket.join(`thread_${threadId}`);
    return { status: 'joined', thread_id: threadId };
  }

  @SubscribeMessage('typing')
  async handleTyping(
    @ConnectedSocket() socket: Socket,
    @MessageBody() data: { threadId: string; isTyping: boolean },
  ) {
    const userId = await this.assertThreadMember(socket, data.threadId);
    socket.to(`thread_${data.threadId}`).emit('typing', {
      threadId: data.threadId,
      userId,
      isTyping: data.isTyping,
    });
  }

  @SubscribeMessage('chat:typing:start')
  async handleTypingStart(@ConnectedSocket() socket: Socket, @MessageBody() data: { thread_id?: string; threadId?: string }) {
    const threadId = data.thread_id || data.threadId;
    if (!threadId) return { error: 'thread_id_required' };
    const userId = await this.assertThreadMember(socket, threadId);
    socket.to(`thread_${threadId}`).emit('chat:typing:start', { thread_id: threadId, user_id: userId });
    return { status: 'typing' };
  }

  @SubscribeMessage('chat:typing:stop')
  async handleTypingStop(@ConnectedSocket() socket: Socket, @MessageBody() data: { thread_id?: string; threadId?: string }) {
    const threadId = data.thread_id || data.threadId;
    if (!threadId) return { error: 'thread_id_required' };
    const userId = await this.assertThreadMember(socket, threadId);
    socket.to(`thread_${threadId}`).emit('chat:typing:stop', { thread_id: threadId, user_id: userId });
    return { status: 'stopped' };
  }

  // --- V3.0 DOCTOR PLATFORM ENFORCEMENT ---

  @SubscribeMessage('send_message')
  async handleSendMessage(@ConnectedSocket() socket: Socket, @MessageBody() data: { threadId: string }) {
    await this.assertThreadMember(socket, data.threadId);
    // Message creation is intentionally REST-only so every message is persisted,
    // deduplicated, permission-checked, and pushed through ChatService.
    return { error: 'use_rest_message_contract' };
  }

  @SubscribeMessage('initiate_call')
  async handleInitiateCall(
    @ConnectedSocket() socket: Socket,
    @MessageBody() data: { threadId: string; state: string },
  ) {
    // Enforce PRE_CONSULTATION state
    if (data.state === 'FOLLOW_UP' || data.state === 'CLOSED') {
      return { error: 'calls_disabled_in_this_state' };
    }
    
    socket.to(`thread_${data.threadId}`).emit('incoming_call', {
      threadId: data.threadId,
      callerId: this.activeUsers.get(socket.id)
    });
    return { status: 'calling' };
  }

  @SubscribeMessage('mark_seen')
  async handleMarkSeen(
    @ConnectedSocket() socket: Socket,
    @MessageBody() data: { threadId: string; messageIds?: string[] },
  ) {
    const userId = await this.assertThreadMember(socket, data.threadId);
    socket.to(`thread_${data.threadId}`).emit('message_seen', {
      threadId: data.threadId,
      seenBy: userId,
      messageIds: data.messageIds || [],
      at: new Date(),
    });
    return { status: 'seen' };
  }

  @OnEvent('chat.message_sent')
  handlePersistedMessage(payload: { thread_id: string; msg_id: string; body: string; type: string; sender_id: string; created_at: Date }) {
    this.server.to(`thread_${payload.thread_id}`).emit('chat:message', payload);
    this.server.to(`thread_${payload.thread_id}`).emit('new_message', payload);
  }

  @OnEvent('medical_orders.emitted')
  handleMedicalOrders(payload: { threadId: string, prescriptions: any[], labs: any[] }) {
    this.logger.log(`Emitting medical_orders_received to thread_${payload.threadId}`);
    this.server.to(`thread_${payload.threadId}`).emit('medical_orders_received', {
      prescriptions: payload.prescriptions,
      labs: payload.labs
    });
  }
}
