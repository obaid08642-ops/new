import { Controller, Get, UseGuards, Req } from '@nestjs/common';
import { JwtAuthGuard, NoGuestsGuard } from '../../common/auth.guard';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

@UseGuards(JwtAuthGuard, NoGuestsGuard)
@Controller('insurance')
export class InsuranceController {
  constructor(@InjectModel('PatientProfile') private profileModel: Model<any>) {}

  @Get('active')
  async getActivePolicies(@Req() req) {
    const profile = await this.profileModel.findOne({ user_id: req.user.id });
    return { policies: profile?.insurance_details ? [profile.insurance_details] : [] };
  }

  /** EPIC4/S21: active insurance companies catalog (replaces a hardcoded
   * constant list in the patient app's insurance-upload flow). */
  @Get('companies')
  async listCompanies(): Promise<any[]> {
    return this.profileModel.db
      .collection('insurance_companies')
      .find({ is_active: true }, { projection: { _id: 0 } })
      .toArray();
  }
}
