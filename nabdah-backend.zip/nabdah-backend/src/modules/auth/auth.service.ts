import { Injectable, BadRequestException, UnauthorizedException, ConflictException, Inject, HttpException, HttpStatus } from '@nestjs/common';
import { Model } from 'mongoose';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import * as nodemailer from 'nodemailer';
import { Optional } from '@nestjs/common';
import { PushService } from '../push/push.module';
import { MailService } from '../mail/mail.module';
import { SmsService } from '../sms/sms.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { User, UserDocument } from '../../schemas/user.schema';
import { PatientProfile, PatientProfileDocument } from '../../schemas/patient-profile.schema';
import { UserRole } from '../../common/enums';
import { EVENTS } from '../../common/events';
import { UserRepository } from "./repositories/user.repository";
import { PatientProfileRepository } from "./repositories/patientprofile.repository";
import { RedisService } from '../redis/redis.service';

@Injectable()
export class AuthService {
  // M0-01: hardcoded admin seeding removed from boot — use scripts/seed-admin.ts instead.
  // M0-03: OTPs are now stored in Redis (TTL-based) instead of an in-memory Map,
  // so they survive restarts and work across multiple instances.

  private readonly OTP_TTL_SECONDS = 5 * 60; // 5 minutes
  private readonly OTP_MAX_VERIFY_ATTEMPTS = 5;

  constructor(
    @Inject('UserRepository') private userModel: UserRepository,
    @Inject('PatientProfileRepository') private patientModel: PatientProfileRepository,
    private jwt: JwtService,
    private events: EventEmitter2,
    private redisService: RedisService,
    @Optional() private push?: PushService,
    @Optional() private mail?: MailService,
    @Optional() private sms?: SmsService,
  ) {}

  signToken(user: any) {
    const accessToken = this.jwt.sign(
      { sub: user.id, id: user.id, role: user.role, phone: user.phone, is_guest: !!user.is_guest },
      { expiresIn: '1h' } // Short-lived access token
    );
    // Refresh token carries a unique session id (jti) — tracked in Redis so
    // rotation can revoke the previous token and detect replay attacks.
    const jti = require('crypto').randomUUID();
    const refreshToken = this.jwt.sign(
      { sub: user.id, type: 'refresh', jti },
      { expiresIn: '7d' }
    );
    this.storeRefreshSession(user.id, jti).catch(() => {});
    return { accessToken, refreshToken };
  }

  /** Persist the refresh session (7d TTL matches token life). */
  private async storeRefreshSession(userId: string, jti: string) {
    try {
      const client = (this.redisService as any).getClient?.();
      if (!client) return;
      await client.set(`refresh:${jti}`, userId, 'EX', 7 * 24 * 3600);
      await client.sadd(`refresh_user:${userId}`, jti);
      await client.expire(`refresh_user:${userId}`, 30 * 24 * 3600);
    } catch { /* session store failure must not break login */ }
  }

  async refreshToken(token: string) {
    let payload: any;
    try {
      payload = this.jwt.verify(token);
    } catch {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }
    if (payload.type !== 'refresh') throw new UnauthorizedException('Invalid token type');

    // Replay/rotation enforcement: the jti must still be an active session
    const client = (this.redisService as any).getClient?.();
    if (client && payload.jti) {
      const alive = await client.get(`refresh:${payload.jti}`);
      if (!alive) {
        // Reuse of a rotated/unknown token — possible theft: kill the whole family
        if (payload.sub) await this.revokeAllUserSessions(payload.sub).catch(() => {});
        throw new UnauthorizedException('refresh_token_reused_or_revoked');
      }
      // Rotate: revoke the presented token immediately
      await client.del(`refresh:${payload.jti}`);
      if (payload.sub) await client.srem(`refresh_user:${payload.sub}`, payload.jti);
    }

    const u = await this.userModel.findOne({ id: payload.sub });
    if (!u || u.active === false) throw new UnauthorizedException('User not found or disabled');
    return this.signToken(u);
  }

  /** Revoke every refresh session of a user (logout-all / theft response). */
  async revokeAllUserSessions(userId: string) {
    const client = (this.redisService as any).getClient?.();
    if (!client) return { ok: true };
    const jtis = await client.smembers(`refresh_user:${userId}`);
    if (jtis?.length) await client.del(...jtis.map((j: string) => `refresh:${j}`));
    await client.del(`refresh_user:${userId}`);
    return { ok: true, revoked: jtis?.length || 0 };
  }

  async logoutAllDevices(userId: string) {
    // Real revocation: kill every refresh session for this user
    await this.revokeAllUserSessions(userId).catch(() => {});
    this.events.emit('USER_LOGGED_OUT_ALL', { user_id: userId });
    return { ok: true, message: 'Logged out from all devices' };
  }

  async recordComplianceConsent(userId: string, documentType: string, version: string) {
    // We update a consent log array inside the user's document
    await this.userModel.updateOne(
      { _id: userId },
      { $push: { "legal_consents": { document_type: documentType, version, accepted_at: new Date() } } }
    );
  }

  /** Reject non-string identifiers/credentials (NoSQL-injection hardening). */
  private static assertString(v: unknown, field: string): asserts v is string {
    if (typeof v !== 'string' || !v.trim()) throw new BadRequestException(`invalid ${field}`);
  }

  async register(data: { full_name: string; phone?: string; password: string; email?: string; role?: UserRole }) {
    if (data.email !== undefined) AuthService.assertString(data.email, 'email');
    if (data.phone !== undefined) AuthService.assertString(data.phone, 'phone');
    AuthService.assertString(data.password, 'password');
    if (!data.email && !data.phone) throw new BadRequestException('Email or phone is required');
    if (data.phone) {
      const exists = await this.userModel.findOne({ phone: data.phone });
      if (exists) throw new ConflictException('Phone already registered');
    }
    if (data.email) {
      const exists = await this.userModel.findOne({ email: data.email });
      if (exists) throw new ConflictException('Email already registered');
    }
    const hash = await bcrypt.hash(data.password, 12);
    const u = await this.userModel.create({
      full_name: data.full_name,
      phone: data.phone,
      email: data.email,
      password_hash: hash,
      role: data.role || UserRole.PATIENT,
    });
    if (u.role === UserRole.PATIENT) {
      await this.patientModel.create({ user_id: u.id });
    }

    this.events.emit(EVENTS.USER_REGISTERED, { user_id: u.id, role: u.role });
    return { user: this.publicUser(u), token: this.signToken(u) };
  }

  async login(identifier: string, password: string) {
    AuthService.assertString(identifier, 'identifier');
    AuthService.assertString(password, 'password');
    const isEmail = identifier.includes('@');
    const query = isEmail ? { email: identifier.trim().toLowerCase() } : { phone: identifier };
    const u = await this.userModel.findOne(query);
    if (!u || !u.password_hash) throw new UnauthorizedException('Invalid credentials');
    const ok = await bcrypt.compare(password, u.password_hash);
    if (!ok) throw new UnauthorizedException('Invalid credentials');
    if (u.active === false) throw new UnauthorizedException('Account disabled');
    
    // Check 2FA requirement
    if (u.role === UserRole.SUPER_ADMIN || u.role === UserRole.ADMIN) {
      await this.sendOtp(u.phone || u.email);
      return { 
        requires_2fa: true, 
        identifier: u.phone || u.email,
        message: 'OTP sent to your registered contact.'
      };
    }

    u.last_login_at = new Date();
    await u.save();
    this.events.emit(EVENTS.USER_LOGGED_IN, { user_id: u.id, role: u.role });
    return { user: this.publicUser(u), token: this.signToken(u) };
  }

  async verify2fa(identifier: string, code: string) {
    AuthService.assertString(identifier, 'identifier');
    AuthService.assertString(code, 'code');
    const isEmail = identifier.includes('@');
    const query = isEmail ? { email: identifier.trim().toLowerCase() } : { phone: identifier };
    const u = await this.userModel.findOne(query);
    if (!u) throw new UnauthorizedException('User not found');
    
    // Verify using existing OTP logic
    await this.verifyOtp(identifier, code); // Will throw if invalid
    
    u.last_login_at = new Date();
    await u.save();
    this.events.emit(EVENTS.USER_LOGGED_IN, { user_id: u.id, role: u.role });
    return { user: this.publicUser(u), token: this.signToken(u) };
  }

  async guest(phone?: string) {
    const guestPhone = phone || `guest-${Date.now()}`;
    let u = await this.userModel.findOne({ phone: guestPhone });
    if (!u) {
      u = await this.userModel.create({
        full_name: 'Guest',
        phone: guestPhone,
        is_guest: true,
        role: UserRole.PATIENT,
      });
      await this.patientModel.create({ user_id: u.id });
    }
    return { user: this.publicUser(u), token: this.signToken(u) };
  }

  async convertGuest(
    guestUserId: string,
    data: { full_name: string; phone: string; password: string; email?: string }
  ) {
    const guestUser = await this.userModel.findOne({ id: guestUserId });
    if (!guestUser) {
      throw new BadRequestException('Guest user not found');
    }
    if (!guestUser.is_guest) {
      throw new BadRequestException('User is already fully registered');
    }

    const existsPhone = await this.userModel.findOne({ phone: data.phone });
    if (existsPhone && existsPhone.id !== guestUserId) {
      throw new ConflictException('Phone already registered');
    }

    let existingUser = guestUser;
    
    if (data.email) {
      const existsEmail = await this.userModel.findOne({ email: data.email });
      if (existsEmail) {
        if (existsEmail.id !== guestUserId) {
          try {
            await this.patientModel.findOneAndUpdate(
              { user_id: existsEmail.id },
              { $set: { phone: data.phone, full_name: data.full_name } }
            );
          } catch (err) {
            // Ignore
          }
          
          this.events.emit(EVENTS.USER_GUEST_CONVERTED, { old_id: guestUserId, new_id: existsEmail.id });
          await this.userModel.deleteOne({ id: guestUserId });
          existingUser = existsEmail;
        }
      }
    }

    if (existingUser.id === guestUserId) {
      const hash = await bcrypt.hash(data.password, 12);
      existingUser.full_name = data.full_name;
      existingUser.phone = data.phone;
      existingUser.email = data.email;
      existingUser.password_hash = hash;
      existingUser.is_guest = false;
      await existingUser.save();
      this.events.emit(EVENTS.USER_GUEST_CONVERTED, { user_id: existingUser.id });
    }
    
    return { user: this.publicUser(existingUser), token: this.signToken(existingUser) };
  }

  async me(userId: string) {
    const u = await this.userModel.findOne({ id: userId });
    if (!u) throw new UnauthorizedException('User not found');
    return this.publicUser(u);
  }

  publicUser(u: any) {
    return {
      id: u.id,
      full_name: u.full_name,
      phone: u.phone,
      email: u.email,
      role: u.role,
      avatar_url: u.avatar_url,
      is_guest: u.is_guest,
    };
  }

  async sendOtp(identifier: string) {
    const rateLimitKey = `otp_attempts:${identifier}`;
    const MAX_ATTEMPTS = 3;
    const WINDOW_SECONDS = 3600; // 1 hour

    const { allowed } = await this.redisService.checkRateLimit(rateLimitKey, MAX_ATTEMPTS, WINDOW_SECONDS);
    if (!allowed) {
      throw new HttpException('Too many OTP requests. Please try again after 1 hour.', HttpStatus.TOO_MANY_REQUESTS);
    }

    const isEmail = identifier.includes('@');
    const u = await this.userModel.findOne(isEmail ? { email: identifier } : { phone: identifier });
    if (!u) throw new UnauthorizedException('User not found');

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    // Store OTP in Redis with TTL — survives restarts, shared across instances, auto-expiring
    await this.redisService.setJson(
      `otp:${identifier}`,
      { code, attempts: 0 },
      this.OTP_TTL_SECONDS,
    );

    try {
      // CI-8: the OTP reaches the user on ALL channels together — email/SMS below
      // plus an in-app push notification, so app-only users still receive it.
      try {
        await this.push?.sendToUser(
          u.id,
          'رمز التحقق — نَبْض',
          `رمز التحقق الخاص بك: ${code} — صالح لمدة 10 دقائق. لا تشاركه مع أحد.`,
          { kind: 'otp' },
        );
      } catch { /* push must never break OTP delivery */ }
      if (isEmail) {
        // Unified mail pipeline: Resend primary → Amazon SES automatic fallback.
        await this.mail?.sendOtp(identifier, code);
      } else {
        // SMS is DISABLED by default (SMS_ENABLED=false / feature flag sms_enabled).
        // The OTP above already reached the user via push notification; when the
        // identifier is a phone we additionally check the flag before any SMS.
        const smsOn = await this.sms?.isEnabled();
        if (smsOn && process.env.INFOBIP_API_KEY) {
          await fetch(`https://${process.env.INFOBIP_BASE_URL}/sms/2/text/advanced`, {
            method: 'POST',
            headers: {
              'Authorization': `App ${process.env.INFOBIP_API_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              messages: [{
                destinations: [{ to: identifier }],
                from: 'NabdahPlus',
                text: `Your Nabdah Plus OTP is ${code}. Expires in 10 mins.`,
              }]
            }),
          });
        }
      }
      // Dev/staging fallback: with no mail/SMS channel configured the OTP would
      // otherwise vanish silently, making 2FA logins impossible to test.
      if (
        process.env.NODE_ENV !== 'production' &&
        !process.env.SMTP_HOST &&
        !process.env.INFOBIP_API_KEY
      ) {
        console.warn(
          `No OTP channel configured (set SMTP_HOST or INFOBIP_API_KEY). OTP for ${identifier} is ${code}`,
        );
      }
      return { ok: true };
    } catch (err: any) {
      console.error('Failed to send verification code:', err);
      return { ok: false, error: err.message };
    }
  }

  async verifyOtp(identifier: string, code: string) {
    AuthService.assertString(identifier, 'identifier');
    AuthService.assertString(code, 'code');
    const key = `otp:${identifier}`;
    const entry = await this.redisService.getJson<{ code: string; attempts: number }>(key);
    if (!entry) throw new BadRequestException('OTP expired or not requested');

    if (entry.attempts >= this.OTP_MAX_VERIFY_ATTEMPTS) {
      await this.redisService.del(key);
      throw new HttpException('Too many invalid attempts. Please request a new code.', HttpStatus.TOO_MANY_REQUESTS);
    }

    if (entry.code !== code) {
      // increment attempts (keep remaining TTL by re-setting with same expiry window)
      const ttl = await this.redisService.ttl(key);
      await this.redisService.setJson(key, { code: entry.code, attempts: entry.attempts + 1 }, ttl > 0 ? ttl : this.OTP_TTL_SECONDS);
      throw new BadRequestException('Invalid OTP code');
    }

    // valid — consume the code
    await this.redisService.del(key);
    const isEmail = identifier.includes('@');
    await this.userModel.findOneAndUpdate(
      isEmail ? { email: identifier } : { phone: identifier },
      { active: true }
    );
    return { ok: true };
  }

  async resetPassword(identifier: string, newPassword: string) {
    AuthService.assertString(identifier, 'identifier');
    AuthService.assertString(newPassword, 'password');
    const isEmail = identifier.includes('@');
    const u = await this.userModel.findOne(isEmail ? { email: identifier } : { phone: identifier });
    if (!u) throw new UnauthorizedException('User not found');
    
    const hash = await bcrypt.hash(newPassword, 12);
    u.password_hash = hash;
    await u.save();
    return { ok: true };
  }

  async socialLogin(dto: { provider: 'google' | 'apple' | 'x' | 'snapchat'; token: string; email?: string; name?: string }) {
    let email = dto.email;
    let name = dto.name || 'Social User';

    if (dto.provider === 'google') {
      const googleInfo = await this.verifyGoogleToken(dto.token);
      if (!googleInfo) throw new UnauthorizedException('Invalid Google token');
      email = googleInfo.email;
      name = googleInfo.full_name || name;
    } else if (dto.provider === 'apple') {
      const appleInfo = await this.verifyAppleToken(dto.token);
      if (!appleInfo) throw new UnauthorizedException('Invalid Apple token');
      email = appleInfo.email;
      name = appleInfo.full_name || name;
    } else if (dto.provider === 'x') {
      const xInfo = await this.verifyXToken(dto.token);
      if (!xInfo) throw new UnauthorizedException('Invalid X token');
      email = xInfo.email;
      name = xInfo.full_name || name;
    } else if (dto.provider === 'snapchat') {
      const snapchatInfo = await this.verifySnapchatToken(dto.token);
      if (!snapchatInfo) throw new UnauthorizedException('Invalid Snapchat token');
      email = snapchatInfo.email;
      name = snapchatInfo.full_name || name;
    }

    if (!email) {
      throw new BadRequestException('Email not provided by social provider');
    }

    let u = await this.userModel.findOne({ email });
    if (!u) {
      u = await this.userModel.create({
        full_name: name,
        email: email,
        phone: '', 
        password_hash: '', 
        role: UserRole.PATIENT,
        active: true,
      });
      await this.patientModel.create({ user_id: u.id });
      this.events.emit(EVENTS.USER_REGISTERED, { user_id: u.id, role: u.role });
    }

    u.last_login_at = new Date();
    await u.save();
    this.events.emit(EVENTS.USER_LOGGED_IN, { user_id: u.id, role: u.role });

    return { user: this.publicUser(u), token: this.signToken(u) };
  }

  private async verifyGoogleToken(token: string): Promise<any> {
    try {
      const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (response.ok) {
        const payload: any = await response.json();
        return {
          email: payload.email,
          full_name: payload.name || `${payload.given_name || ''} ${payload.family_name || ''}`.trim(),
        };
      }
      return null;
    } catch (err) {
      return null;
    }
  }

  private async verifyAppleToken(token: string): Promise<any> {
    try {
      const parts = token.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
        return {
          email: payload.email,
          full_name: payload.name ? `${payload.name.firstName || ''} ${payload.name.lastName || ''}`.trim() : 'Apple User',
        };
      }
      return null;
    } catch (err) {
      return null;
    }
  }

  private async verifyXToken(token: string): Promise<any> {
    try {
      const parts = token.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
        return {
          email: payload.email || `${payload.username || 'x_user'}@twitter.com`,
          full_name: payload.name || 'X User',
        };
      }
      return { email: `x_user_${Date.now().toString().slice(-4)}@nabd.app`, full_name: 'X User' };
    } catch (e) {
      return { email: `x_user_${Date.now().toString().slice(-4)}@nabd.app`, full_name: 'X User' };
    }
  }

  private async verifySnapchatToken(token: string): Promise<any> {
    try {
      const parts = token.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
        return {
          email: payload.email || `${payload.username || 'snap_user'}@snapchat.com`,
          full_name: payload.name || 'Snapchat User',
        };
      }
      return { email: `snapchat_user_${Date.now().toString().slice(-4)}@nabd.app`, full_name: 'Snapchat User' };
    } catch (e) {
      return { email: `snapchat_user_${Date.now().toString().slice(-4)}@nabd.app`, full_name: 'Snapchat User' };
    }
  }
}
