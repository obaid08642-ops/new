import { Injectable, Inject, ExecutionContext } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PromotionCampaign, PromotionCampaignDocument } from '../../schemas/promotion-campaign.schema';
import { Appointment, AppointmentDocument } from '../../schemas/appointment.schema';
import { REQUEST } from '@nestjs/core';

@Injectable()
export class HomeService {
  constructor(
    @InjectModel(PromotionCampaign.name) private promoModel: Model<PromotionCampaignDocument>,
    @InjectModel(Appointment.name) private apptModel: Model<AppointmentDocument>,
    @Inject(REQUEST) private request: any,
  ) {}

  async getOffers() {
    const campaigns = await this.promoModel.find({ status: 'active' }).limit(10).exec();

    // Resolve real provider names/ratings — never expose raw ids or fake ratings
    const providerIds = [...new Set(campaigns.map((c: any) => c.provider_id).filter(Boolean).map(String))];
    const providers: any[] = providerIds.length
      ? await this.promoModel.db.collection('provider_profiles')
          .find({ $or: [{ id: { $in: providerIds } }, { user_id: { $in: providerIds } }, { account_id: { $in: providerIds } }] } as any)
          .toArray()
      : [];
    const provMap = new Map<string, any>();
    for (const p of providers) {
      for (const key of [p.id, p.user_id, p.account_id].filter(Boolean)) provMap.set(String(key), p);
    }

    return campaigns.map(c => {
      const prov = c.provider_id ? provMap.get(String(c.provider_id)) : null;
      return {
        id: (c as any).id || String((c as any)._id),
        t: c.title_ar,
        price: c.discounted_price,
        old: c.original_price,
        disc: Math.round(((c.original_price - c.discounted_price) / c.original_price) * 100) + '%',
        rating: prov?.rating_avg ?? null,
        prov: prov?.name || prov?.facility_name || 'شريك نبض',
        c: '#FF4B55',
        ic: 'local_offer',
        sponsored: c.target_parameters?.sponsored || false,
      };
    });
  }

  async getUpcomingAppointment() {
    const userId = this.request.user?.id;
    if (!userId) return null;

    const upcoming = await this.apptModel.findOne({
      patient_id: userId,
      status: { $in: ['PENDING', 'CONFIRMED'] },
      slot_start: { $gte: new Date() }
    }).sort({ slot_start: 1 }).exec();

    if (!upcoming) return null;

    const dateStr = upcoming.slot_start.toISOString().split('T')[0];
    const timeStr = upcoming.slot_start.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', hour12: true });
    
    let typeAr = 'استشارة في العيادة';
    if (upcoming.service_type === 'video') typeAr = 'استشارة فيديو';
    else if (upcoming.service_type === 'home') typeAr = 'زيارة منزلية';

    // Resolve the real doctor name from the provider profile (doctor_id = provider_profile.id)
    let doctorName = '';
    if (upcoming.doctor_id) {
      const prov: any = await this.apptModel.db.collection('provider_profiles').findOne({
        $or: [{ id: upcoming.doctor_id }, { user_id: upcoming.doctor_user_id }, { account_id: upcoming.doctor_id }],
      } as any);
      doctorName = prov?.name || '';
    }

    return {
      id: (upcoming as any).id || String((upcoming as any)._id),
      date: dateStr,
      doctorName: doctorName || null,
      type: typeAr,
      time: timeStr
    };
  }

  async globalSearch(query: string) {
    if (!query || query.trim().length === 0) return [];
    
    const regex = new RegExp(query, 'i');
    const campaigns = await this.promoModel.find({
      $or: [{ title_ar: regex }, { title_en: regex }]
    }).limit(10).lean();

    // Resolve provider names so we never show raw ids as the subtitle
    const providerIds = [...new Set(campaigns.map((c: any) => c.provider_id).filter(Boolean).map(String))];
    const providers: any[] = providerIds.length
      ? await this.promoModel.db.collection('provider_profiles')
          .find({ $or: [{ id: { $in: providerIds } }, { user_id: { $in: providerIds } }, { account_id: { $in: providerIds } }] } as any)
          .toArray()
      : [];
    const provMap = new Map<string, any>();
    for (const p of providers) {
      for (const key of [p.id, p.user_id, p.account_id].filter(Boolean)) provMap.set(String(key), p);
    }

    return campaigns.map(c => ({
      id: c._id?.toString() || c.id,
      type: 'باقة',
      typeEn: 'Package',
      name: c.title_ar,
      nameEn: c.title_en || c.title_ar,
      sub: (c.provider_id && (provMap.get(String(c.provider_id))?.name || provMap.get(String(c.provider_id))?.facility_name)) || 'عرض نبض',
      subEn: (c.provider_id && (provMap.get(String(c.provider_id))?.name || provMap.get(String(c.provider_id))?.facility_name)) || 'Nabd Offer',
      ic: 'science',
      c: '#7A6BEA',
      cs: '#F2F0FD',
      price: String(c.discounted_price || c.original_price || 0),
      priceEn: String(c.discounted_price || c.original_price || 0),
      sponsored: c.target_parameters?.sponsored || false,
    }));
  }
}
