import { Controller, Get, Post, Param, Query, UseGuards, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { JwtAuthGuard, Roles } from '../../common/auth.guard';
import { UserRole } from '../../common/enums';
import { User, UserDocument } from '../../schemas/user.schema';
import { ProviderDelta } from '../providers/schemas/provider-delta.schema';

@Controller('admin')
@UseGuards(JwtAuthGuard)
@Roles(UserRole.ADMIN) // Globally secures this controller to ADMIN only
export class AdminController {
  constructor(
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
    @InjectModel(ProviderDelta.name) private readonly deltaModel: Model<any>
  ) {}

  /**
   * User directory for the admin dashboard (users-management page):
   * paginated, filterable by role and free-text search (name/phone/email).
   */
  @Get('users')
  async listUsers(
    @Query('page') page = '1',
    @Query('limit') limit = '50',
    @Query('role') role?: string,
    @Query('q') q?: string,
  ) {
    const p = Math.max(1, parseInt(page, 10) || 1);
    const l = Math.min(200, Math.max(1, parseInt(limit, 10) || 50));
    const filter: any = {};
    if (role) filter.role = role;
    if (q?.trim()) {
      const rx = new RegExp(q.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      filter.$or = [{ full_name: rx }, { phone: rx }, { email: rx }];
    }
    const [items, total] = await Promise.all([
      this.userModel
        .find(filter, { password_hash: 0, otp_codes: 0 })
        .sort({ createdAt: -1 })
        .skip((p - 1) * l)
        .limit(l)
        .lean(),
      this.userModel.countDocuments(filter),
    ]);
    return { data: items, total, page: p, pages: Math.ceil(total / l) };
  }

  /** Ban/deactivate a user account (blocks login via active=false). */
  @Post('users/:userId/ban')
  async banUser(@Param('userId') userId: string) {
    const user = await this.userModel.findOne({ id: userId }).exec()
      || await this.userModel.findById(userId).catch(() => null);
    if (!user) throw new BadRequestException('user_not_found');
    if (user.role === UserRole.ADMIN || user.role === UserRole.SUPER_ADMIN) {
      throw new BadRequestException('cannot_ban_admin');
    }
    (user as any).active = false;
    (user as any).suspended = true;
    await user.save();
    return { ok: true, message: 'user_banned' };
  }

  /** Lift a ban / reactivate an account. */
  @Post('users/:userId/unban')
  async unbanUser(@Param('userId') userId: string) {
    const user = await this.userModel.findOne({ id: userId }).exec()
      || await this.userModel.findById(userId).catch(() => null);
    if (!user) throw new BadRequestException('user_not_found');
    (user as any).active = true;
    (user as any).suspended = false;
    await user.save();
    return { ok: true, message: 'user_unbanned' };
  }

  /**
   * Manually approve a Doctor or Pharmacy (ensures 'verified: boolean' blocks booking until Admin approves).
   */
  @Post('approve/:userId')
  async approveProvider(@Param('userId') userId: string) {
    const user = await this.userModel.findById(userId);
    if (!user) throw new BadRequestException('user_not_found');
    if (![UserRole.DOCTOR, UserRole.PHARMACY].includes(user.role)) {
      throw new BadRequestException('user_not_a_provider');
    }
    
    user.verified = true;
    await user.save();
    return { ok: true, message: 'provider_verified' };
  }

  @Post('suspend/:userId')
  async suspendProvider(@Param('userId') userId: string) {
    const user = await this.userModel.findById(userId);
    if (!user) throw new BadRequestException('user_not_found');
    
    user.suspended = true;
    user.verified = false;
    await user.save();
    return { ok: true, message: 'provider_suspended' };
  }

  // --- DELTA AUDIT GUARD ENDPOINTS ---

  @Post('provider-deltas')
  async getPendingDeltas() {
    const deltas = await this.deltaModel.find({ status: 'pending' }).exec();
    return deltas;
  }

  @Post('provider-deltas/:deltaId/approve')
  async approveDelta(@Param('deltaId') deltaId: string) {
    const delta = await this.deltaModel.findById(deltaId);
    if (!delta) throw new BadRequestException('delta_not_found');

    delta.status = 'approved';
    await delta.save();

    // Here we would apply the requested_changes to the actual ProviderProfile
    // e.g., await this.profileModel.updateOne({ account_id: delta.provider_id }, { $set: delta.requested_changes })
    
    return { ok: true, message: 'delta_approved' };
  }

  @Post('provider-deltas/:deltaId/reject')
  async rejectDelta(@Param('deltaId') deltaId: string) {
    const delta = await this.deltaModel.findById(deltaId);
    if (!delta) throw new BadRequestException('delta_not_found');

    delta.status = 'rejected';
    await delta.save();
    
    return { ok: true, message: 'delta_rejected' };
  }
}
