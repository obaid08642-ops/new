import { Injectable, NotFoundException, BadRequestException, Inject } from '@nestjs/common';
import { Model } from 'mongoose';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EmergencyRequest, EmergencyRequestDocument } from '../../schemas/emergency.schema';
import { EmergencyState, EMERGENCY_TRANSITIONS, UserRole } from '../../common/enums';
import { EVENTS } from '../../common/events';
import { EmergencyRequestRepository } from "./repositories/emergencyrequest.repository";

@Injectable()
export class EmergencyService {
  constructor(
    @Inject('EmergencyRequestRepository') private model: EmergencyRequestRepository,
    private events: EventEmitter2,
  ) {}

  async trigger(patient: any, data: { location?: any; symptoms?: string; severity?: string }) {
    const e = await this.model.create({
      patient_id: patient.id,
      patient_name: patient.full_name,
      patient_phone: patient.phone,
      location: data.location,
      symptoms: data.symptoms,
      severity: data.severity || 'critical',
      state: EmergencyState.TRIGGERED,
      state_history: [{ from: '', to: EmergencyState.TRIGGERED, by: patient.id, at: new Date() }],
    });
    this.events.emit(EVENTS.EMERGENCY_TRIGGERED, { emergency_id: e.id, patient_id: patient.id });
    // Auto-progress: capture location -> notify admin
    if (data.location) await this.transition(e.id, EmergencyState.LOCATION_CAPTURED, { id: 'system', role: 'system' });
    await this.transition(e.id, EmergencyState.ADMIN_NOTIFIED, { id: 'system', role: 'system' });
    return this.model.findOne({ id: e.id }, { _id: 0, __v: 0 });
  }

  async transition(id: string, to: EmergencyState, by: any) {
    const e = await this.model.findOne({ id });
    if (!e) throw new NotFoundException();
    const allowed = EMERGENCY_TRANSITIONS[e.state] || [];
    if (by.role !== UserRole.ADMIN && by.role !== 'system' && !allowed.includes(to)) {
      throw new BadRequestException(`Invalid emergency transition ${e.state} → ${to}`);
    }
    e.state_history.push({ from: e.state, to, by: by.id, at: new Date() } as any);
    e.state = to;
    await e.save();
    return e.toObject();
  }

  async assign(id: string, hospital_id: string, by: any) {
    const e = await this.model.findOneAndUpdate(
      { id },
      { $set: { assigned_hospital_id: hospital_id, state: EmergencyState.DISPATCH_INITIATED } },
      { new: true },
    );
    if (!e) throw new NotFoundException();
    this.events.emit(EVENTS.EMERGENCY_ASSIGNED, { emergency_id: id, hospital_id });
    return e.toObject();
  }

  async resolve(id: string, by: any, notes?: string) {
    const e = await this.model.findOneAndUpdate(
      { id },
      { $set: { state: EmergencyState.RESOLVED, resolved_at: new Date(), resolved_by: by.id, admin_notes: notes } },
      { new: true },
    );
    if (!e) throw new NotFoundException();
    this.events.emit(EVENTS.EMERGENCY_RESOLVED, { emergency_id: id });
    return e.toObject();
  }

  async active() {
    return this.model.find(
      { state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] } },
      { _id: 0, __v: 0 },
    ).sort({ createdAt: -1 });
  }

  /** M1-31: patient-scoped view — the caller's own active SOS request (was admin-only before). */
  /** Patient cancels their own active SOS — ownership enforced, dispatched units notified */
  async cancelOwn(id: string, patientId: string) {
    const e = await this.model.findOneAndUpdate(
      {
        id,
        patient_id: patientId,
        state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] },
      },
      {
        $set: { state: EmergencyState.CANCELLED, cancelled_at: new Date(), updatedAt: new Date() },
        $push: { state_history: { from: '', to: EmergencyState.CANCELLED, by: patientId, at: new Date(), note: 'patient_cancelled' } },
      },
      { new: true },
    );
    if (!e) throw new NotFoundException('no_active_sos_for_patient');
    this.events.emit(EVENTS.EMERGENCY_RESOLVED, { emergency_id: id, cancelled_by_patient: true });
    return e.toObject();
  }

  async myActive(patientId: string) {
    const e = await this.model.findOne(
      { patient_id: patientId, state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] } },
      { _id: 0, __v: 0 },
    );
    return e || null;
  }

  /** Driver: unassigned SOS pool + my assigned missions */
  async driverMissions(driverId: string): Promise<any> {
    const [pool, mine] = await Promise.all([
      this.model.find(
        { assigned_ambulance_id: { $in: [null, undefined] }, state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] } },
        { _id: 0, __v: 0 },
      ).sort({ createdAt: -1 }).limit(20),
      this.model.find(
        { assigned_ambulance_id: driverId, state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] } },
        { _id: 0, __v: 0 },
      ).sort({ createdAt: -1 }).limit(20),
    ]);
    return { pool, mine };
  }

  /** Driver claims an open SOS — atomic first-come-first-served.
   *  Repo updateOne == findOneAndUpdate → returns the doc or null. */
  async claim(id: string, driverId: string) {
    const doc = await this.model.updateOne(
      { id, assigned_ambulance_id: { $in: [null, undefined] }, state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] } },
      { $set: { assigned_ambulance_id: driverId, claimed_at: new Date(), state: EmergencyState.DISPATCH_INITIATED, updatedAt: new Date() } },
    );
    if (!doc) throw new BadRequestException('already_claimed_or_closed');
    return { ok: true, id, driver_id: driverId, state: EmergencyState.DISPATCH_INITIATED };
  }

  async getById(id: string) {
    const e = await this.model.findOne({ id }, { _id: 0, __v: 0 });
    if (!e) throw new NotFoundException();
    return e;
  }

  private haversineKm(lat1: number, lng1: number, lat2: number, lng2: number) {
    const R = 6371, dLat = (lat2 - lat1) * Math.PI / 180, dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(a));
  }

  /** Patient: live tracking of their own active SOS — real fields only, no fabricated ETA. */
  async tracking(patientId: string) {
    const e = await this.model.findOne(
      { patient_id: patientId, state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] } },
      { _id: 0, __v: 0 },
    );
    if (!e) return { active: false };
    const o: any = e.toObject ? e.toObject() : e;
    let eta_minutes: number | null = null;
    let distance_km: number | null = null;
    const u = o.unit_location, p = o.location;
    if (u?.lat && u?.lng && p?.lat && p?.lng) {
      distance_km = Math.round(this.haversineKm(u.lat, u.lng, p.lat, p.lng) * 10) / 10;
      eta_minutes = Math.max(1, Math.round((distance_km / 40) * 60)); // urban avg 40km/h
    }
    const claimed = !!o.assigned_ambulance_id;
    const steps = [
      { key: 'received', title_ar: 'تم استلام النداء', done: true },
      { key: 'assigned', title_ar: 'تم تخصيص سيارة إسعاف', done: claimed, current: claimed && !u?.lat },
      { key: 'en_route', title_ar: 'سيارة الإسعاف في الطريق', done: !!u?.lat, current: claimed && !!u?.lat },
      { key: 'arrived', title_ar: 'الوصول إلى موقعك', done: false },
    ];
    return {
      active: true,
      id: o.id,
      state: o.state,
      vehicle_id: o.assigned_ambulance_id || null,
      claimed_at: o.claimed_at || null,
      unit_location: u?.lat ? { lat: u.lat, lng: u.lng, updated_at: u.updated_at } : null,
      eta_minutes,
      distance_km,
      steps,
    };
  }

  /** Driver who claimed the SOS: push the ambulance unit's live GPS position. */
  async updateUnitLocation(id: string, driverId: string, body: { lat?: number; lng?: number }) {
    const lat = Number(body?.lat), lng = Number(body?.lng);
    if (!isFinite(lat) || !isFinite(lng)) throw new BadRequestException('lat_lng_required');
    const res = await this.model.updateOne(
      { id, assigned_ambulance_id: driverId, state: { $nin: [EmergencyState.RESOLVED, EmergencyState.CLOSED, EmergencyState.CANCELLED] } },
      { $set: { unit_location: { lat, lng, updated_at: new Date() }, updatedAt: new Date() } },
    );
    if (!res) throw new NotFoundException('mission_not_found_or_not_yours');
    return { ok: true };
  }
}
