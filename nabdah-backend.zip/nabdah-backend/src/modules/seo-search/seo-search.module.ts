/**
 * SEO + Global Search + Recommendations module.
 * Auto metadata per entity (slug/canonical/OG/Twitter/JSON-LD/breadcrumbs),
 * sitemap.xml + robots.txt, universal home search, recommendation engine.
 */
import { Module, Injectable, Controller, Get, Param, Query, Res } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { Connection } from 'mongoose';
import { Response } from 'express';
import { Public } from '../../common/auth.guard';

const SITE = process.env.API_PUBLIC_URL?.replace('/api/v1', '') || 'https://api.nabd.plus';
const SITE_NAME = 'نبض';

function slugify(s: string): string {
  return (s || '').trim().replace(/[\s_]+/g, '-').replace(/[^\p{L}\p{N}-]/gu, '').replace(/-+/g, '-').replace(/^-|-$/g, '').toLowerCase().slice(0, 80);
}

@Injectable()
export class SeoSearchService {
  constructor(@InjectConnection() private readonly conn: Connection) {}

  async metadata(type: string, id: string): Promise<any> {
    const entity = await this.loadEntity(type, id);
    if (!entity) return null;
    const base = this.baseFields(type, entity);
    const slug = entity.slug || slugify(`${base.title}-${String(entity.id || id).slice(0, 6)}`);
    const canonical = `${SITE}/s/${type}/${slug}`;
    const description = base.description.slice(0, 155);
    const image = base.image || `${SITE}/og-default.png`;
    return {
      type, id: entity.id, slug, canonical_url: canonical,
      page_title: `${base.title} | ${SITE_NAME}`,
      meta_description: description,
      og: {
        'og:title': base.title, 'og:description': description, 'og:url': canonical,
        'og:image': image, 'og:type': base.ogType, 'og:site_name': SITE_NAME, 'og:locale': 'ar_SA',
      },
      twitter_card: { card: 'summary_large_image', title: base.title, description, image },
      json_ld: base.jsonLd(canonical, image),
      breadcrumbs: base.breadcrumbs(canonical),
      robots: 'index,follow',
      sitemap_entry: { loc: canonical, changefreq: base.changefreq, priority: base.priority },
    };
  }

  private async loadEntity(type: string, id: string): Promise<any> {
    if (type === 'category') return { id, is_category: true };
    const col = type === 'medicine' ? 'medicines_master' : type === 'article' ? 'articles' : 'provider_profiles';
    return this.conn.collection(col).findOne({ id }, { projection: { _id: 0 } });
  }

  private cdn(u?: string) {
    if (!u) return u;
    if (u.startsWith('http')) return u;
    return `${process.env.S3_PUBLIC_BASE_URL || 'https://cdn.nabd.plus'}/${u.replace(/^\//, '')}`;
  }

  private crumbs(url: string, items: Array<[string, string | null]>) {
    return {
      '@context': 'https://schema.org', '@type': 'BreadcrumbList',
      itemListElement: items.map(([name, link], i) => ({ '@type': 'ListItem', position: i + 1, name, ...(link ? { item: link } : {}) })),
    };
  }

  private baseFields(type: string, e: any): any {
    switch (type) {
      case 'medicine': {
        const title = e.name_ar || e.name_en || 'منتج';
        const desc = [e.description_ar, e.active_ingredient ? `المادة الفعالة: ${e.active_ingredient}` : null, e.manufacturer ? `من ${e.manufacturer}` : null].filter(Boolean).join(' — ') || `${title} — متوفر في صيدلية ${SITE_NAME}`;
        return {
          title, description: desc, image: e.image ? this.cdn(e.image) : null, ogType: 'product', changefreq: 'weekly', priority: 0.8,
          jsonLd: (url: string, img: string) => ({
            '@context': 'https://schema.org', '@type': 'Product', name: title, description: desc, image: img, url,
            brand: e.manufacturer ? { '@type': 'Brand', name: e.manufacturer } : undefined,
            offers: e.price ? { '@type': 'Offer', price: e.price, priceCurrency: 'SAR', availability: e.availability_status === 'none' || !e.availability_status ? 'https://schema.org/InStock' : 'https://schema.org/LimitedAvailability' } : undefined,
          }),
          breadcrumbs: (url: string) => this.crumbs(url, [['الرئيسية', SITE], ['الصيدلية', `${SITE}/pharmacy`], [e.category || 'منتجات', null], [title, url]]),
        };
      }
      case 'article':
        return {
          title: e.title_ar || e.title || 'مقال',
          description: (e.excerpt_ar || e.content_ar || '').slice(0, 155) || `مقال طبي من ${SITE_NAME}`,
          image: e.image ? this.cdn(e.image) : null, ogType: 'article', changefreq: 'monthly', priority: 0.6,
          jsonLd: (url: string, img: string) => ({ '@context': 'https://schema.org', '@type': 'Article', headline: e.title_ar || e.title, image: img, url, author: { '@type': 'Organization', name: SITE_NAME } }),
          breadcrumbs: (url: string) => this.crumbs(url, [['الرئيسية', SITE], ['المقالات', `${SITE}/articles`], [e.title_ar || 'مقال', url]]),
        };
      case 'category':
        return {
          title: e.id, description: `تصفح منتجات ${e.id} في صيدلية ${SITE_NAME}`,
          image: null, ogType: 'website', changefreq: 'weekly', priority: 0.7,
          jsonLd: (url: string) => ({ '@context': 'https://schema.org', '@type': 'CollectionPage', name: e.id, url }),
          breadcrumbs: (url: string) => this.crumbs(url, [['الرئيسية', SITE], ['الصيدلية', `${SITE}/pharmacy`], [e.id, url]]),
        };
      default: {
        const title = e.name || e.facility_name || e.full_name || 'مزود';
        const desc = [e.specialty, e.city, (e.bio || '').slice(0, 100)].filter(Boolean).join(' — ') || `${title} — مزود رعاية صحية في ${SITE_NAME}`;
        return {
          title, description: desc, image: e.photo_url || e.logo_url ? this.cdn(e.photo_url || e.logo_url) : null,
          ogType: 'profile', changefreq: 'weekly', priority: 0.7,
          jsonLd: (url: string, img: string) => ({ '@context': 'https://schema.org', '@type': type === 'doctor' ? 'Physician' : 'MedicalBusiness', name: title, description: desc, image: img, url, ...(e.specialty ? { medicalSpecialty: e.specialty } : {}) }),
          breadcrumbs: (url: string) => this.crumbs(url, [['الرئيسية', SITE], ['المزودون', `${SITE}/providers`], [title, url]]),
        };
      }
    }
  }

  async sitemapXml(): Promise<string> {
    const meds = await this.conn.collection('medicines_master')
      .find({ is_deleted: { $ne: true } }, { projection: { _id: 0, id: 1, slug: 1, name_ar: 1, updatedAt: 1 } })
      .sort({ usage_count: -1 }).limit(2000).toArray();
    const urls = meds.map((m: any) => {
      const slug = m.slug || slugify(`${m.name_ar || ''}-${String(m.id).slice(0, 6)}`);
      const lastmod = m.updatedAt ? new Date(m.updatedAt).toISOString().slice(0, 10) : '2026-07-01';
      return `  <url><loc>${SITE}/s/medicine/${slug}</loc><lastmod>${lastmod}</lastmod><changefreq>weekly</changefreq><priority>0.8</priority></url>`;
    });
    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join('\n')}\n</urlset>`;
  }

  async globalSearch(q: string, limit = 5): Promise<any> {
    const term = (q || '').trim();
    if (term.length < 2) return { query: q, results: {}, total: 0 };
    const rx = { $regex: term, $options: 'i' };
    const medProj = { _id: 0, id: 1, name_ar: 1, name_en: 1, price: 1, image: 1, category: 1, manufacturer: 1 };
    const docProj = { _id: 0, id: 1, name: 1, full_name: 1, specialty: 1, photo_url: 1, rating: 1, city: 1 };
    const [medicines, doctors, pharmacies, hospitals, labs, services] = await Promise.all([
      this.conn.collection('medicines_master').find({ is_deleted: { $ne: true }, $or: [{ name_ar: rx }, { name_en: rx }, { active_ingredient: rx }, { search_text: rx }] } as any, { projection: medProj } as any).limit(limit).toArray(),
      this.conn.collection('provider_profiles').find({ provider_type: 'doctor', $or: [{ name: rx }, { full_name: rx }, { specialty: rx }] } as any, { projection: docProj } as any).limit(limit).toArray(),
      this.conn.collection('provider_profiles').find({ provider_type: 'pharmacy', $or: [{ name: rx }, { facility_name: rx }] } as any, { projection: { _id: 0, id: 1, name: 1, facility_name: 1, city: 1, logo_url: 1 } } as any).limit(limit).toArray(),
      this.conn.collection('provider_profiles').find({ provider_type: { $in: ['hospital', 'clinic', 'medical_center'] }, $or: [{ name: rx }, { facility_name: rx }] } as any, { projection: { _id: 0, id: 1, name: 1, facility_name: 1, city: 1 } } as any).limit(limit).toArray(),
      this.conn.collection('provider_profiles').find({ provider_type: { $in: ['lab', 'laboratory'] }, $or: [{ name: rx }, { facility_name: rx }] } as any, { projection: { _id: 0, id: 1, name: 1, facility_name: 1, city: 1 } } as any).limit(limit).toArray(),
      this.conn.collection('homecareservices').find({ $or: [{ name_ar: rx }, { name_en: rx }] } as any, { projection: { _id: 0, id: 1, name_ar: 1, name_en: 1, price: 1 } } as any).limit(limit).toArray().catch(() => []),
    ]);
    const total = medicines.length + doctors.length + pharmacies.length + hospitals.length + labs.length + (services || []).length;
    return {
      query: term, total,
      results: {
        medicines: medicines.map((m: any) => ({ ...m, _type: 'medicine' })),
        doctors: doctors.map((d: any) => ({ ...d, _type: 'doctor' })),
        pharmacies: pharmacies.map((p: any) => ({ ...p, _type: 'pharmacy' })),
        hospitals: hospitals.map((h: any) => ({ ...h, _type: 'hospital' })),
        labs: labs.map((l: any) => ({ ...l, _type: 'laboratory' })),
        services: (services || []).map((s: any) => ({ ...s, _type: 'service' })),
      },
    };
  }

  async medicineRecommendations(id: string, limit = 12): Promise<any> {
    const med: any = await this.conn.collection('medicines_master').findOne({ id, is_deleted: { $ne: true } }, { projection: { _id: 0 } });
    if (!med) return { alternatives: [], same_manufacturer: [], same_category: [] };
    const card = { _id: 0, id: 1, name_ar: 1, name_en: 1, price: 1, old_price: 1, image: 1, manufacturer: 1, requires_prescription: 1, form: 1, strength: 1 };
    const [alternatives, sameManufacturer, sameCategory] = await Promise.all([
      med.active_ingredient
        ? this.conn.collection('medicines_master').find({ active_ingredient: med.active_ingredient, id: { $ne: id }, is_deleted: { $ne: true } } as any, { projection: card } as any).limit(limit).toArray()
        : Promise.resolve([]),
      med.manufacturer
        ? this.conn.collection('medicines_master').find({ manufacturer: med.manufacturer, id: { $ne: id }, is_deleted: { $ne: true } } as any, { projection: card } as any).limit(limit).toArray()
        : Promise.resolve([]),
      this.conn.collection('medicines_master').find({ category: med.category, id: { $ne: id }, is_deleted: { $ne: true } } as any, { projection: card } as any).sort({ usage_count: -1 }).limit(limit).toArray(),
    ]);
    return { alternatives, same_manufacturer: sameManufacturer, same_category: sameCategory, ranking: 'ingredient>manufacturer>category (AI-rank ready)' };
  }

  async doctorRecommendations(id: string, limit = 10): Promise<any> {
    const doc: any = await this.conn.collection('provider_profiles').findOne({ id, provider_type: 'doctor' } as any, { projection: { _id: 0 } });
    if (!doc) return { same_specialty: [], nearby: [] };
    const card = { _id: 0, id: 1, name: 1, full_name: 1, specialty: 1, photo_url: 1, rating: 1, city: 1, consultation_price: 1 };
    const [sameSpecialty, nearby] = await Promise.all([
      doc.specialty
        ? this.conn.collection('provider_profiles').find({ provider_type: 'doctor', specialty: doc.specialty, id: { $ne: id } } as any, { projection: card } as any).sort({ rating: -1 }).limit(limit).toArray()
        : Promise.resolve([]),
      doc.city
        ? this.conn.collection('provider_profiles').find({ provider_type: 'doctor', city: doc.city, id: { $ne: id } } as any, { projection: card } as any).sort({ rating: -1 }).limit(limit).toArray()
        : Promise.resolve([]),
    ]);
    return { same_specialty: sameSpecialty, nearby, ranking: 'specialty>nearby>rating (AI-rank ready)' };
  }
}

@Controller()
export class SeoSearchController {
  constructor(private readonly svc: SeoSearchService) {}

  @Public()
  @Get('seo/:type/:id')
  seo(@Param('type') type: string, @Param('id') id: string) {
    return this.svc.metadata(type, id);
  }

  @Public()
  @Get('sitemap.xml')
  async sitemap(@Res() res: Response) {
    res.setHeader('Content-Type', 'application/xml');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.send(await this.svc.sitemapXml());
  }

  @Public()
  @Get('robots.txt')
  robots(@Res() res: Response) {
    res.setHeader('Content-Type', 'text/plain');
    res.send(`User-agent: *\nAllow: /s/\nAllow: /sitemap.xml\nDisallow: /api/\nSitemap: ${SITE}/sitemap.xml\n`);
  }

  @Public()
  @Get('search/global')
  globalSearch(@Query('q') q: string, @Query('limit') limit?: string) {
    return this.svc.globalSearch(q || '', parseInt(limit || '5'));
  }

  @Public()
  @Get('medicines/:id/recommendations')
  medicineRecommendations(@Param('id') id: string, @Query('limit') limit?: string) {
    return this.svc.medicineRecommendations(id, parseInt(limit || '12'));
  }

  @Public()
  @Get('doctors/:id/recommendations')
  doctorRecommendations(@Param('id') id: string, @Query('limit') limit?: string) {
    return this.svc.doctorRecommendations(id, parseInt(limit || '10'));
  }
}

@Module({
  controllers: [SeoSearchController],
  providers: [SeoSearchService],
})
export class SeoSearchModule {}
