import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { LabResultsService } from './lab-results.service';
import { LabBookingState } from '../../schemas/lab.schema';

describe('LabResultsService workflow integrity', () => {
  const results: any = { create: jest.fn() };
  const bookings: any = { findOne: jest.fn() };
  const events: any = { emit: jest.fn() };
  const engine: any = { apply: jest.fn(async (opts: any) => opts.mutate()) };
  const service = new LabResultsService(results, {} as any, bookings, events, engine);

  beforeEach(() => jest.clearAllMocks());

  it('rejects a foreign provider before creating a result', async () => {
    bookings.findOne.mockResolvedValue({ id: 'b1', provider_account_id: 'lab-a', state: LabBookingState.RESULT_UPLOADED });
    await expect(service.create({ id: 'lab-b', role: 'provider', provider_type: 'lab' }, { booking_id: 'b1', type: 'blood' })).rejects.toThrow(ForbiddenException);
    expect(results.create).not.toHaveBeenCalled();
  });

  it('rejects result creation until the sample has reached result upload', async () => {
    bookings.findOne.mockResolvedValue({ id: 'b1', provider_account_id: 'lab-a', state: LabBookingState.PROCESSING });
    await expect(service.create({ id: 'lab-a', role: 'provider', provider_type: 'lab' }, { booking_id: 'b1', type: 'blood' })).rejects.toThrow(BadRequestException);
    expect(results.create).not.toHaveBeenCalled();
  });

  it('creates and releases a result through the workflow engine only', async () => {
    const booking: any = { id: 'b1', patient_id: 'p1', provider_account_id: 'lab-a', state: LabBookingState.RESULT_UPLOADED, state_history: [], reports: [], items: [], save: jest.fn() };
    bookings.findOne.mockResolvedValue(booking);
    results.create.mockResolvedValue({ id: 'r1', tracking_id: 'RES-1', toObject: () => ({ id: 'r1' }) });
    await expect(service.create({ id: 'lab-a', role: 'provider', provider_type: 'lab' }, { booking_id: 'b1', type: 'blood', entries: [] })).resolves.toEqual({ id: 'r1' });
    expect(engine.apply).toHaveBeenCalledWith(expect.objectContaining({ from_domain: LabBookingState.RESULT_UPLOADED, to_domain: LabBookingState.REPORTED }));
    expect(booking.save).toHaveBeenCalled();
  });
});
