// @ts-nocheck
/**
 * M6 / ZATCA (Phase 1 — فوترة إلكترونية مبسطة):
 * Every paid booking gets an e-invoice with a ZATCA-compliant QR code
 * (TLV tags 1–5, base64) as mandated since 04/12/2021.
 * Phase 2 (Fatoora clearance / UBL XML / cryptographic signing) requires a
 * certified integration — tracked in PROJECT_CONTEXT debts.
 *
 * NOTE: booking models are fetched from the shared mongoose connection
 * (already registered by their owning modules) — no re-registration here.
 */
import {
  BadRequestException, Controller, Get, Module, Param, Query,
  NotFoundException, Injectable, UseGuards,
} from '@nestjs/common';
import { InjectConnection, MongooseModule } from '@nestjs/mongoose';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Connection } from 'mongoose';
import { randomUUID } from 'crypto';
import { JwtAuthGuard, Roles } from '../../common/auth.guard';
import { UserRole } from '../../common/enums';
import { CurrentUser } from '../../common/auth.guard';

const VAT_RATE = 0.15;

// ── Schema ─────────────────────────────────────────────────────────────────
@Schema({ timestamps: true })
export class EInvoice {
  @Prop({ default: () => randomUUID() }) id: string;
  @Prop({ unique: true, index: true }) invoice_no: string; // INV-2026-000001
  @Prop({ index: true }) booking_kind: string;
  @Prop({ index: true }) booking_id: string;
  @Prop({ index: true }) patient_id: string;
  @Prop({ default: 0 }) subtotal: number;
  @Prop({ default: VAT_RATE }) vat_rate: number;
  @Prop({ default: 0 }) vat_amount: number;
  @Prop({ default: 0 }) total: number;
  @Prop({ default: 'SAR' }) currency: string;
  @Prop() qr_base64: string; // ZATCA TLV QR payload
  @Prop({ default: 'ISSUED', index: true }) status: string; // ISSUED|CANCELLED
}
export const EInvoiceSchema = SchemaFactory.createForClass(EInvoice);

// ── ZATCA TLV QR (Phase 1: tags 1–5) ───────────────────────────────────────
function tlvQr(sellerName: string, vatNumber: string, isoDate: string, total: number, vat: number): string {
  const tlv = (tag: number, value: string) => {
    const buf = Buffer.from(value, 'utf8');
    return Buffer.concat([Buffer.from([tag, buf.length]), buf]);
  };
  const payload = Buffer.concat([
    tlv(1, sellerName),
    tlv(2, vatNumber),
    tlv(3, isoDate),
    tlv(4, total.toFixed(2)),
    tlv(5, vat.toFixed(2)),
  ]);
  return payload.toString('base64');
}

// ── Service ────────────────────────────────────────────────────────────────
@Injectable()
export class BillingService {
  constructor(@InjectConnection() private conn: Connection) {}

  private get invoices() { return this.conn.model('EInvoice'); }

  private async nextInvoiceNo(): Promise<string> {
    const year = new Date().getFullYear();
    const counter = await this.conn.collection('counters').findOneAndUpdate(
      { _id: `invoice-${year}` } as any,
      { $inc: { seq: 1 } },
      { upsert: true, returnDocument: 'after' },
    );
    const seq = (counter as any)?.seq ?? (counter as any)?.value?.seq ?? 1;
    return `INV-${year}-${String(seq).padStart(6, '0')}`;
  }

  private bookingModelName(kind: string): string {
    switch (kind) {
      case 'pharmacy': case 'order': return 'Order';
      case 'appointment': case 'consultation': return 'Appointment';
      case 'lab': return 'LabBooking';
      case 'radiology': return 'RadiologyBooking';
      case 'home_care': case 'nursing': return 'HomeCareBooking';
      default: throw new BadRequestException('unsupported booking_kind');
    }
  }

  /** Issue (or return existing) e-invoice for a paid booking. */
  async issue(user: any, kind: string, bookingId: string) {
    const existing = await this.invoices.findOne({ booking_kind: kind, booking_id: bookingId, status: 'ISSUED' }, { _id: 0, __v: 0 }).lean();
    if (existing) return existing;

    const booking: any = await this.conn.model(this.bookingModelName(kind)).findOne({ id: bookingId }).lean();
    if (!booking) throw new NotFoundException('booking not found');
    const isOwner = booking.patient_id === user.id || booking.user_id === user.id;
    if (!isOwner && user.role !== 'admin') throw new BadRequestException('not your booking');

    const total = Number(booking.total ?? booking.total_price ?? booking.price ?? 0);
    if (!(total > 0)) throw new BadRequestException('booking has no payable amount');
    const vat = Math.round((total - total / (1 + VAT_RATE)) * 100) / 100; // VAT-inclusive extraction
    const subtotal = Math.round((total - vat) * 100) / 100;

    const sellerName = process.env.ZATCA_SELLER_NAME || 'منصة نبضة بلس للرعاية الصحية';
    const vatNumber = process.env.ZATCA_VAT_NUMBER || '300000000000003';
    const issuedAt = new Date();
    const qr = tlvQr(sellerName, vatNumber, issuedAt.toISOString(), total, vat);

    const doc = await this.invoices.create({
      invoice_no: await this.nextInvoiceNo(),
      booking_kind: kind,
      booking_id: bookingId,
      patient_id: booking.patient_id || booking.user_id,
      subtotal, vat_rate: VAT_RATE, vat_amount: vat, total,
      qr_base64: qr,
    });
    return this.invoices.findOne({ id: doc.id }, { _id: 0, __v: 0 }).lean();
  }

  myInvoices(user: any) {
    return this.invoices.find({ patient_id: user.id }, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).limit(100).lean();
  }

  adminList(limit = 100) {
    return this.invoices.find({}, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).limit(Math.min(limit, 500)).lean();
  }
}

// ── Controller ─────────────────────────────────────────────────────────────
@Controller('billing')
@UseGuards(JwtAuthGuard)
export class BillingController {
  constructor(private svc: BillingService) {}

  /** Issue/retrieve the e-invoice for a paid booking (patient or admin). */
  @Get('invoice/:kind/:bookingId')
  invoice(@CurrentUser() user: any, @Param('kind') kind: string, @Param('bookingId') bookingId: string) {
    return this.svc.issue(user, kind, bookingId);
  }

  @Get('my')
  my(@CurrentUser() user: any) {
    return this.svc.myInvoices(user);
  }

  /** Admin: list recent invoices. */
  @Get('admin/list')
  @Roles(UserRole.ADMIN)
  adminInvoices(@Query('limit') limit?: string) {
    return this.svc.adminList(Number(limit) || 100);
  }
}

@Module({
  imports: [MongooseModule.forFeature([{ name: 'EInvoice', schema: EInvoiceSchema }])],
  controllers: [BillingController],
  providers: [BillingService],
})
export class BillingModule {}
