import { Controller, Get, UseGuards, Req } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { JwtAuthGuard, NoGuestsGuard } from '../../common/auth.guard';
import { NABDAH_ACCESS_TOKEN_SECURITY_SCHEME } from '../../config/openapi.config';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

@ApiTags('Insurance')
@UseGuards(JwtAuthGuard, NoGuestsGuard)
@Controller('insurance')
export class InsuranceController {
  constructor(@InjectModel('PatientProfile') private profileModel: Model<any>) {}

  @Get('active')
  @ApiBearerAuth(NABDAH_ACCESS_TOKEN_SECURITY_SCHEME)
  @ApiOperation({
    summary: 'Get the authenticated patient’s active insurance projection',
    description: 'Returns `insurance_details` as a zero-or-one `policies` collection for active-policy consumers. It is not interchangeable with the editable `insurance` object from `GET /users/me/insurance` or the deprecated legacy `insurance_policies` collection.',
  })
  @ApiOkResponse({
    description: 'Zero or one active `insurance_details` record for the authenticated patient.',
    schema: {
      type: 'object',
      required: ['policies'],
      properties: {
        policies: {
          type: 'array',
          maxItems: 1,
          description: 'Active-policy projection populated from `insurance_details` when present.',
          items: { type: 'object', additionalProperties: true },
        },
      },
    },
  })
  @ApiUnauthorizedResponse({ description: 'Missing, malformed, or expired bearer token.' })
  @ApiForbiddenResponse({ description: 'Guest accounts cannot access insurance operations.' })
  async getActivePolicies(@Req() req) {
    const profile = await this.profileModel.findOne({ user_id: req.user.id });
    return { policies: profile?.insurance_details ? [profile.insurance_details] : [] };
  }

  /** EPIC4/S21: active insurance companies catalog (replaces a hardcoded
   * constant list in the patient app's insurance-upload flow).
   * SINGLE SOURCE OF TRUTH — every app (patient, provider onboarding, provider
   * dashboard, admin) reads companies + their plan tiers from here. Plans are
   * embedded from insurance_networks so clients never hardcode a second list. */
  @Get('companies')
  @ApiBearerAuth(NABDAH_ACCESS_TOKEN_SECURITY_SCHEME)
  @ApiOperation({
    summary: 'List active insurance companies and their plan tiers',
    description: 'Single source of truth for active company catalog entries and embedded plan tiers. The response filters companies by `is_active: true`; clients must not replace it with a hard-coded provider list.',
  })
  @ApiOkResponse({
    description: 'Active insurance companies with sorted plan tiers.',
    schema: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          name_ar: { type: 'string' },
          name_en: { type: 'string' },
          plans: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id: { type: 'string' },
                code: { type: 'string' },
                name_ar: { type: 'string' },
                name_en: { type: 'string' },
                tier_level: { type: 'number' },
              },
              additionalProperties: true,
            },
          },
        },
        additionalProperties: true,
      },
    },
  })
  @ApiUnauthorizedResponse({ description: 'Missing, malformed, or expired bearer token.' })
  @ApiForbiddenResponse({ description: 'Guest accounts cannot access insurance operations.' })
  async listCompanies(): Promise<any[]> {
    const db = this.profileModel.db;
    const [companies, networks] = await Promise.all([
      db.collection('insurance_companies').find({ is_active: true }, { projection: { _id: 0 } }).toArray(),
      db.collection('insurance_networks').find({}, { projection: { _id: 0, company_id: 1, id: 1, name_ar: 1, name_en: 1, tier_level: 1, code: 1 } }).toArray(),
    ]);
    const byCompany = new Map<string, any[]>();
    for (const n of networks as any[]) {
      const arr = byCompany.get(n.company_id) || [];
      arr.push({ id: n.id, code: n.code, name_ar: n.name_ar, name_en: n.name_en, tier_level: n.tier_level });
      byCompany.set(n.company_id, arr);
    }
    return (companies as any[]).map((c) => ({
      ...c,
      plans: (byCompany.get(c.id) || []).sort((a, b) => (a.tier_level || 0) - (b.tier_level || 0)),
    }));
  }
}
