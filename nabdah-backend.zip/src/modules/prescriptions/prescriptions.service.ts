import { Injectable, NotFoundException, BadRequestException, Inject } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Prescription, PrescriptionDocument } from '../../schemas/prescription.schema';
import { Appointment, AppointmentDocument, APPT_STATES } from '../../schemas/appointment.schema';
import { PrescriptionState, PRESCRIPTION_TRANSITIONS, UserRole } from '../../common/enums';
import { EVENTS } from '../../common/events';
import { MedicinesService } from '../medicines/medicines.service';
import { PrescriptionRepository } from "./repositories/prescription.repository";
import { getEffectiveRoles } from '../../common/auth.guard';

@Injectable()
export class PrescriptionsService {
  constructor(
    @Inject('PrescriptionRepository') private model: PrescriptionRepository,
    private medicines: MedicinesService,
    private events: EventEmitter2,
    @InjectModel(Appointment.name) private appointments: Model<AppointmentDocument>,
  ) {}

  /**
   * Creates a prescription only from a verified, in-progress doctor appointment.
   * Patient and doctor identifiers are derived and checked against the server-owned
   * appointment; manually entered or unverified medicines are intentionally refused.
   */
  async create(doctor: any, data: { patient_id: string; appointment_id?: string; items: any[]; diagnosis?: string; notes?: string }) {
    const doctorId = String(doctor?.id || '');
    const patientId = String(data?.patient_id || '');
    const appointmentId = String(data?.appointment_id || '');
    if (!doctorId || !patientId || !appointmentId) {
      throw new BadRequestException('verified appointment and patient are required');
    }
    if (!Array.isArray(data?.items) || data.items.length === 0) {
      throw new BadRequestException('at least one approved medicine is required');
    }

    const appointment = await this.appointments.findOne({
      id: appointmentId,
      patient_id: patientId,
      doctor_user_id: doctorId,
      status: APPT_STATES.IN_PROGRESS,
    });
    if (!appointment) {
      // Existence-hide foreign, stale, or unverified appointment identifiers.
      throw new NotFoundException('verified in-progress appointment not found');
    }

    const items: any[] = [];
    for (const item of data.items) {
      const medicineId = String(item?.medicine_id || '');
      if (!medicineId) {
        throw new BadRequestException('approved medicine_id is required');
      }
      const medicine: any = await this.medicines.getById(medicineId);
      if (medicine?.verified !== true) {
        throw new BadRequestException('medicine must be approved before prescription use');
      }
      const dose = String(item?.dose || '').trim();
      const durationDays = Number(item?.duration_days);
      if (!dose || !Number.isFinite(durationDays) || durationDays <= 0) {
        throw new BadRequestException('dose and positive duration_days are required');
      }
      items.push({
        medicine_id: medicine.id,
        medicine_name_ar: medicine.name_ar,
        medicine_name_en: medicine.name_en,
        active_ingredient: medicine.active_ingredient,
        dose,
        frequency_hours: item.frequency_hours,
        times_per_day: item.times_per_day,
        duration_days: durationDays,
        instructions: item.instructions,
        is_manual_entry: false,
      });
    }

    const rx: any = await this.model.create({
      doctor_id: doctorId,
      patient_id: patientId,
      appointment_id: appointmentId,
      items,
      diagnosis: String(data?.diagnosis || '').trim() || undefined,
      notes: String(data?.notes || '').trim() || undefined,
      has_manual_entries: false,
      state: PrescriptionState.CREATED_BY_DOCTOR,
    });
    await this.appointments.updateOne(
      { id: appointmentId, patient_id: patientId, doctor_user_id: doctorId },
      { $addToSet: { prescriptions: rx.id } },
    );
    this.events.emit(EVENTS.PRESCRIPTION_CREATED, {
      prescription_id: rx.id,
      patient_id: patientId,
      doctor_id: doctorId,
      appointment_id: appointmentId,
    });
    return rx.toObject();
  }

  // Patient uploads scan (image OCR pending in AI module)
  async uploadByPatient(patient: any, data: { upload_image: string; items?: any[]; notes?: string }) {
    const items: any[] = [];
    let hasManual = false;
    for (const it of data.items || []) {
      // Normalize the name field — OCR may return any of these keys.
      const medName = (it.name_ar || it.medicine_name_ar || it.name || it.name_en || '').toString().trim();
      const medNameEn = (it.name_en || it.medicine_name_en || '').toString().trim() || undefined;
      if (!medName) continue; // skip blank items rather than crashing
      let medId = it.medicine_id;
      if (!medId) {
        try {
          const m = await this.medicines.createManualEntry(
            { name_ar: medName, name_en: medNameEn, active_ingredient: it.active_ingredient, category: 'medications' },
            patient.id,
            patient.role,
          );
          medId = m.id;
          hasManual = true;
        } catch (e) {
          // graceful — still record the line with no id so admin/pharmacy can review
          medId = undefined;
          hasManual = true;
        }
      }
      items.push({
        medicine_id: medId,
        medicine_name_ar: medName,
        medicine_name_en: medNameEn,
        active_ingredient: it.active_ingredient,
        dose: it.dose,
        frequency_hours: it.frequency_hours,
        times_per_day: it.times_per_day,
        duration_days: it.duration_days,
        quantity: it.quantity,
        instructions: it.frequency || it.instructions,
        is_manual_entry: !it.medicine_id,
      });
    }
    const rx = await this.model.create({
      patient_id: patient.id,
      upload_image: data.upload_image,
      notes: data.notes,
      state: PrescriptionState.CREATED_BY_DOCTOR, // patient-uploaded but starts here for pharmacy review
      items,
      has_manual_entries: hasManual,
    });
    this.events.emit(EVENTS.PRESCRIPTION_CREATED, { prescription_id: rx.id, patient_id: rx.patient_id });
    return rx.toObject();
  }

  async transition(id: string, to: PrescriptionState, by: any) {
    const rx = await this.model.findOne({ id });
    if (!rx) throw new NotFoundException();
    const allowed = PRESCRIPTION_TRANSITIONS[rx.state] || [];
    if (by.role !== UserRole.ADMIN && !allowed.includes(to)) {
      throw new BadRequestException(`Invalid transition ${rx.state} → ${to}`);
    }
    rx.state = to;
    if (to === PrescriptionState.SENT_TO_PHARMACY) this.events.emit(EVENTS.PRESCRIPTION_SENT, { prescription_id: id });
    if (to === PrescriptionState.DISPENSED) this.events.emit(EVENTS.PRESCRIPTION_DISPENSED, { prescription_id: id });
    await rx.save();
    return rx.toObject();
  }

  async sendToPharmacy(id: string, pharmacy_id: string, by: any) {
    const rx = await this.model.findOneAndUpdate(
      { id },
      { $set: { pharmacy_id, state: PrescriptionState.SENT_TO_PHARMACY } },
      { new: true },
    );
    if (!rx) throw new NotFoundException();
    this.events.emit(EVENTS.PRESCRIPTION_SENT, { prescription_id: id, pharmacy_id });
    return rx.toObject();
  }

  async substitute(id: string, itemIndex: number, newMedicineId: string, by: any) {
    const rx = await this.model.findOne({ id });
    if (!rx) throw new NotFoundException();
    if (!rx.items[itemIndex]) throw new BadRequestException('Invalid item index');
    rx.items[itemIndex].substituted = true;
    rx.items[itemIndex].substituted_to_medicine_id = newMedicineId;
    rx.state = PrescriptionState.PARTIALLY_EDITED;
    await rx.save();
    this.events.emit(EVENTS.PRESCRIPTION_MODIFIED, { prescription_id: id });
    return rx.toObject();
  }

  /** Active prescriptions for the patient — everything not dispensed/archived. */
  async activeForPatient(user: any) {
    return this.model.find(
      { patient_id: user.id, state: { $nin: [PrescriptionState.DISPENSED, PrescriptionState.ARCHIVED] } },
      { _id: 0, __v: 0 },
    ).sort({ createdAt: -1 }).limit(100);
  }

  async listMine(patient_id: string) {
    return this.model.find({ patient_id }, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).limit(100);
  }
  async listForDoctor(doctor_id: string) {
    return this.model.find({ doctor_id }, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).limit(200);
  }
  async listForPharmacy(pharmacy_id: string) {
    return this.model.find({ pharmacy_id, state: { $in: [PrescriptionState.SENT_TO_PHARMACY, PrescriptionState.PARTIALLY_EDITED, PrescriptionState.APPROVED] } }, { _id: 0, __v: 0 }).sort({ createdAt: -1 }).limit(200);
  }
  /**
   * Returns a prescription only to a participating patient, doctor, pharmacy,
   * or privileged administrator. A foreign lookup is deliberately indistinguishable
   * from a missing record so identifiers cannot be used for enumeration.
   */
  async getByIdForUser(id: string, user: any) {
    const rx = await this.model.findOne({ id }, { _id: 0, __v: 0 });
    if (!rx) throw new NotFoundException();
    const roles = getEffectiveRoles(user);
    const hasPrivilegedAdminRole = roles.includes(UserRole.ADMIN) || roles.includes(UserRole.SUPER_ADMIN);
    const isParticipant = [rx.patient_id, rx.doctor_id, rx.pharmacy_id].filter(Boolean).includes(user?.id);
    if (!hasPrivilegedAdminRole && !isParticipant) throw new NotFoundException();
    return rx;
  }
}
