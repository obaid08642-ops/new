import { BadRequestException, NotFoundException } from '@nestjs/common';
import { PrescriptionsService } from './prescriptions.service';

describe('PrescriptionsService authorization and verified creation', () => {
  const prescription = {
    id: 'rx-sandbox-1',
    patient_id: 'patient-owner',
    doctor_id: 'doctor-owner',
    pharmacy_id: 'pharmacy-owner',
  };

  const createService = (overrides: {
    appointment?: any;
    medicine?: any;
    created?: any;
  } = {}) => {
    const repository = {
      findOne: jest.fn().mockResolvedValue(prescription),
      create: jest.fn().mockResolvedValue(overrides.created || {
        id: 'rx-created',
        toObject: () => ({ id: 'rx-created', patient_id: 'patient-owner' }),
      }),
    };
    const medicines = {
      getById: jest.fn().mockResolvedValue(overrides.medicine || {
        id: 'medicine-approved',
        name_ar: 'دواء معتمد',
        name_en: 'Approved medicine',
        active_ingredient: 'ingredient',
        verified: true,
      }),
    };
    const events = { emit: jest.fn() };
    const appointments = {
      findOne: jest.fn().mockResolvedValue(overrides.appointment === undefined ? {
        id: 'appointment-owner',
        patient_id: 'patient-owner',
        doctor_user_id: 'doctor-owner',
        status: 'IN_PROGRESS',
      } : overrides.appointment),
      updateOne: jest.fn().mockResolvedValue({ acknowledged: true }),
    };
    const service = new PrescriptionsService(repository as any, medicines as any, events as any, appointments as any);
    return { service, repository, medicines, events, appointments };
  };

  it.each([
    [{ id: 'patient-owner', role: 'patient' }],
    [{ id: 'doctor-owner', role: 'provider', provider_type: 'doctor' }],
    [{ id: 'pharmacy-owner', role: 'provider', provider_type: 'pharmacy' }],
    [{ id: 'admin-owner', role: 'admin' }],
  ])('returns the prescription to an authorized participant or administrator', async (actor) => {
    const { service, repository } = createService();

    await expect(service.getByIdForUser('rx-sandbox-1', actor)).resolves.toEqual(prescription);
    expect(repository.findOne).toHaveBeenCalledWith({ id: 'rx-sandbox-1' }, { _id: 0, __v: 0 });
  });

  it('hides a prescription from a foreign patient', async () => {
    const { service } = createService();

    await expect(service.getByIdForUser('rx-sandbox-1', { id: 'patient-foreign', role: 'patient' }))
      .rejects.toThrow(NotFoundException);
  });

  it('hides a prescription from an unrelated provider', async () => {
    const { service } = createService();

    await expect(service.getByIdForUser('rx-sandbox-1', { id: 'lab-foreign', role: 'provider', provider_type: 'lab' }))
      .rejects.toThrow(NotFoundException);
  });

  it('rejects creation before an appointment and patient are both supplied', async () => {
    const { service, repository, appointments } = createService();

    await expect(service.create(
      { id: 'doctor-owner', role: 'doctor' },
      { patient_id: 'patient-owner', items: [{ medicine_id: 'medicine-approved', dose: '1 tablet', duration_days: 3 }] },
    )).rejects.toThrow(BadRequestException);
    expect(appointments.findOne).not.toHaveBeenCalled();
    expect(repository.create).not.toHaveBeenCalled();
  });

  it('hides a foreign or stale appointment rather than creating a prescription', async () => {
    const { service, repository, appointments } = createService({ appointment: null });

    await expect(service.create(
      { id: 'doctor-owner', role: 'doctor' },
      { appointment_id: 'appointment-foreign', patient_id: 'patient-owner', items: [{ medicine_id: 'medicine-approved', dose: '1 tablet', duration_days: 3 }] },
    )).rejects.toThrow(NotFoundException);
    expect(appointments.findOne).toHaveBeenCalledWith({
      id: 'appointment-foreign',
      patient_id: 'patient-owner',
      doctor_user_id: 'doctor-owner',
      status: 'IN_PROGRESS',
    });
    expect(repository.create).not.toHaveBeenCalled();
  });

  it('rejects custom or unverified medicines before persistence', async () => {
    const { service, repository, medicines } = createService({ medicine: { id: 'medicine-unverified', verified: false } });

    await expect(service.create(
      { id: 'doctor-owner', role: 'doctor' },
      { appointment_id: 'appointment-owner', patient_id: 'patient-owner', items: [{ medicine_id: 'medicine-unverified', dose: '1 tablet', duration_days: 3 }] },
    )).rejects.toThrow(BadRequestException);
    expect(medicines.getById).toHaveBeenCalledWith('medicine-unverified');
    expect(repository.create).not.toHaveBeenCalled();
  });

  it('persists only approved catalogue medicines against the verified owned appointment', async () => {
    const { service, repository, appointments, events } = createService();

    await expect(service.create(
      { id: 'doctor-owner', role: 'doctor' },
      {
        appointment_id: 'appointment-owner',
        patient_id: 'patient-owner',
        diagnosis: 'verified diagnosis',
        items: [{ medicine_id: 'medicine-approved', dose: '1 tablet', duration_days: 3, instructions: 'after food' }],
      },
    )).resolves.toEqual({ id: 'rx-created', patient_id: 'patient-owner' });

    expect(repository.create).toHaveBeenCalledWith(expect.objectContaining({
      doctor_id: 'doctor-owner',
      patient_id: 'patient-owner',
      appointment_id: 'appointment-owner',
      has_manual_entries: false,
      items: [expect.objectContaining({
        medicine_id: 'medicine-approved',
        medicine_name_ar: 'دواء معتمد',
        is_manual_entry: false,
      })],
    }));
    expect(appointments.updateOne).toHaveBeenCalledWith(
      { id: 'appointment-owner', patient_id: 'patient-owner', doctor_user_id: 'doctor-owner' },
      { $addToSet: { prescriptions: 'rx-created' } },
    );
    expect(events.emit).toHaveBeenCalledWith('prescription.created', expect.objectContaining({
      prescription_id: 'rx-created',
      appointment_id: 'appointment-owner',
    }));
  });
});
