import { NotFoundException } from '@nestjs/common';
import { PrescriptionsService } from './prescriptions.service';

describe('PrescriptionsService detail authorization', () => {
  const prescription = {
    id: 'rx-sandbox-1',
    patient_id: 'patient-owner',
    doctor_id: 'doctor-owner',
    pharmacy_id: 'pharmacy-owner',
  };

  const createService = () => {
    const repository = { findOne: jest.fn().mockResolvedValue(prescription) };
    const service = new PrescriptionsService(repository as any, {} as any, {} as any);
    return { service, repository };
  };

  it.each([
    [{ id: 'patient-owner', role: 'patient' }],
    [{ id: 'doctor-owner', role: 'provider', provider_type: 'doctor' }],
    [{ id: 'pharmacy-owner', role: 'provider', provider_type: 'pharmacy' }],
    [{ id: 'admin-owner', role: 'admin' }],
  ])('returns the prescription to an authorized participant or administrator', async (actor) => {
    const { service, repository } = createService();

    await expect(service.getByIdForUser('rx-sandbox-1', actor)).resolves.toEqual(prescription);
    expect(repository.findOne).toHaveBeenCalledWith({ id: 'rx-sandbox-1' }, { _id: 0, __v: 0 });
  });

  it('hides a prescription from a foreign patient', async () => {
    const { service } = createService();

    await expect(service.getByIdForUser('rx-sandbox-1', { id: 'patient-foreign', role: 'patient' }))
      .rejects.toThrow(NotFoundException);
  });

  it('hides a prescription from an unrelated provider', async () => {
    const { service } = createService();

    await expect(service.getByIdForUser('rx-sandbox-1', { id: 'lab-foreign', role: 'provider', provider_type: 'lab' }))
      .rejects.toThrow(NotFoundException);
  });
});
