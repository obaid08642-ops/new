import { useState, useEffect, useMemo } from 'react';
import { apiFetch } from '../../utils/api';

const ROLE_LABELS: Record<string, string> = {
  patient: 'مريض',
  guest: 'زائر',
  doctor: 'طبيب',
  pharmacy: 'صيدلية',
  laboratory: 'معمل تحاليل',
  lab: 'معمل تحاليل',
  hospital: 'مستشفى',
  facility: 'منشأة طبية',
  radiology: 'أشعة',
  nursing: 'تمريض',
  ambulance: 'إسعاف',
  admin: 'أدمن',
  super_admin: 'أدمن رئيسي',
};

const ROLE_FILTERS = [
  { value: '', label: 'كل الأدوار' },
  { value: 'patient', label: 'المرضى' },
  { value: 'doctor', label: 'الأطباء' },
  { value: 'pharmacy', label: 'الصيدليات' },
  { value: 'laboratory', label: 'معامل التحاليل' },
  { value: 'hospital', label: 'المستشفيات / المنشآت' },
  { value: 'radiology', label: 'مراكز الأشعة' },
  { value: 'nursing', label: 'التمريض' },
  { value: 'ambulance', label: 'الإسعاف' },
];

export default function UsersManagementPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [actionBusy, setActionBusy] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const fetchUsers = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const params = new URLSearchParams({ limit: '200', sort: 'newest' });
      if (roleFilter) params.set('role', roleFilter);
      if (searchTerm.trim()) params.set('q', searchTerm.trim());
      const res = await apiFetch(`/admin/users?${params.toString()}`);
      setUsers(Array.isArray(res) ? res : res?.data || []);
      setTotal(res?.total ?? (Array.isArray(res) ? res.length : res?.data?.length ?? 0));
    } catch (err: any) {
      setErrorMsg(err?.message || 'فشل تحميل المستخدمين');
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(fetchUsers, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleFilter, searchTerm]);

  /** Suspend (reversible) — sets active=false + suspended=true in the DB. */
  const handleSuspend = async (u: any) => {
    const id = u.id || u._id;
    if (!confirm(`تعليق حساب «${u.full_name || u.phone}»؟ يمكن إعادة تفعيله لاحقاً.`)) return;
    setActionBusy(id);
    try {
      await apiFetch(`/admin/users/${id}/ban`, { method: 'POST' });
      await fetchUsers();
    } catch (err: any) {
      alert(`فشل التعليق: ${err?.message || ''}`);
    } finally {
      setActionBusy(null);
    }
  };

  /** Reactivate a suspended account. */
  const handleReactivate = async (u: any) => {
    const id = u.id || u._id;
    setActionBusy(id);
    try {
      await apiFetch(`/admin/users/${id}/unban`, { method: 'POST' });
      await fetchUsers();
    } catch (err: any) {
      alert(`فشل إعادة التفعيل: ${err?.message || ''}`);
    } finally {
      setActionBusy(null);
    }
  };

  /** PERMANENT delete — removes the user and their owned records from the DB. */
  const handleDelete = async (u: any) => {
    const id = u.id || u._id;
    const name = u.full_name || u.phone || id;
    if (!confirm(`⚠️ حذف نهائي!\nسيتم حذف «${name}» وبياناته من قاعدة البيانات نهائياً ولا يمكن التراجع.\n\nهل أنت متأكد تماماً؟`)) return;
    if (!confirm(`تأكيد أخير: حذف «${name}» نهائياً من الـ backend وقاعدة البيانات؟`)) return;
    setActionBusy(id);
    try {
      await apiFetch(`/admin/users/${id}`, { method: 'DELETE' });
      await fetchUsers();
    } catch (err: any) {
      alert(`فشل الحذف: ${err?.message || ''}`);
    } finally {
      setActionBusy(null);
    }
  };

  const visibleUsers = useMemo(() => {
    return users.filter((u) => {
      if (statusFilter === 'active') return u.active !== false && !u.suspended;
      if (statusFilter === 'suspended') return u.suspended || u.active === false;
      return true;
    });
  }, [users, statusFilter]);

  return (
    <div className="p-8">
      <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
        <h1 className="text-2xl font-bold">إدارة المستخدمين ({total})</h1>
        <div className="flex flex-wrap gap-3">
          <input
            type="text"
            placeholder="بحث بالاسم أو الهاتف أو البريد..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="border border-gray-300 rounded px-4 py-2 w-64"
          />
          <select
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
            className="border border-gray-300 rounded px-3 py-2 bg-white"
          >
            {ROLE_FILTERS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
          </select>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="border border-gray-300 rounded px-3 py-2 bg-white"
          >
            <option value="">كل الحالات</option>
            <option value="active">نشط</option>
            <option value="suspended">موقوف / معلّق</option>
          </select>
        </div>
      </div>

      {errorMsg && (
        <div className="mb-4 p-3 bg-red-50 border border-red-300 text-red-700 rounded">{errorMsg}</div>
      )}

      {loading ? (
        <div className="p-8 text-center text-gray-500">جاري التحميل...</div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الاسم</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الهاتف / البريد</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الدور</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الحالة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {visibleUsers.map((u) => {
                const id = u.id || u._id;
                const suspended = !!u.suspended || u.active === false;
                const isAdmin = u.role === 'admin' || u.role === 'super_admin';
                return (
                  <tr key={id}>
                    <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                      {u.full_name || u.name || 'مستخدم'}
                      {u.is_guest && <span className="mr-2 text-xs text-gray-400">(زائر)</span>}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500" dir="ltr">
                      {u.phone || u.email || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      {ROLE_LABELS[String(u.role || 'patient').toLowerCase()] || u.role || 'مريض'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${suspended ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                        {suspended ? 'موقوف' : 'نشط'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      {isAdmin ? (
                        <span className="text-gray-400 text-xs">محمي</span>
                      ) : (
                        <div className="flex gap-3">
                          {suspended ? (
                            <button
                              onClick={() => handleReactivate(u)}
                              disabled={actionBusy === id}
                              className="text-green-600 hover:text-green-900 font-bold disabled:opacity-50"
                            >
                              إعادة تفعيل
                            </button>
                          ) : (
                            <button
                              onClick={() => handleSuspend(u)}
                              disabled={actionBusy === id}
                              className="text-amber-600 hover:text-amber-900 font-bold disabled:opacity-50"
                            >
                              تعليق / إيقاف
                            </button>
                          )}
                          <button
                            onClick={() => handleDelete(u)}
                            disabled={actionBusy === id}
                            className="text-red-600 hover:text-red-900 font-bold disabled:opacity-50"
                          >
                            حذف نهائي
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
              {visibleUsers.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-gray-500">لا يوجد مستخدمين مطابقين.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
