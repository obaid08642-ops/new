import { useState, useEffect, useMemo } from 'react';
import { apiFetch } from '../../utils/api';
import ProviderFullDetail from '../../components/ProviderFullDetail';

const ROLE_LABELS: Record<string, string> = {
  patient: 'مريض',
  guest: 'زائر',
  doctor: 'طبيب',
  pharmacy: 'صيدلية',
  laboratory: 'معمل تحاليل',
  lab: 'معمل تحاليل',
  hospital: 'مستشفى',
  facility: 'منشأة طبية',
  radiology: 'أشعة',
  nursing: 'تمريض',
  ambulance: 'إسعاف',
  admin: 'أدمن',
  super_admin: 'أدمن رئيسي',
};

const ROLE_FILTERS = [
  { value: '', label: 'كل الأدوار' },
  { value: 'patient', label: 'المرضى' },
  { value: 'doctor', label: 'الأطباء' },
  { value: 'pharmacy', label: 'الصيدليات' },
  { value: 'laboratory', label: 'معامل التحاليل' },
  { value: 'hospital', label: 'المستشفيات / المنشآت' },
  { value: 'radiology', label: 'مراكز الأشعة' },
  { value: 'nursing', label: 'التمريض' },
  { value: 'ambulance', label: 'الإسعاف' },
];

export default function UsersManagementPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [actionBusy, setActionBusy] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // ── Full user/provider file viewer ──────────────────────────────
  const [viewUser, setViewUser] = useState<any | null>(null);
  const [viewLoading, setViewLoading] = useState(false);
  const [userOverview, setUserOverview] = useState<any | null>(null);
  const [providerFile, setProviderFile] = useState<any | null>(null);

  const openUserFile = async (u: any) => {
    const id = u.id || u._id;
    setViewUser(u);
    setViewLoading(true);
    setUserOverview(null);
    setProviderFile(null);
    try {
      const ov = await apiFetch(`/admin/users/${id}/overview`).catch(() => null);
      setUserOverview(ov);
      const role = String(u.role || '').toLowerCase();
      if (role && role !== 'patient' && role !== 'guest' && role !== 'admin' && role !== 'super_admin') {
        // Provider account — pull the COMPLETE registration file (same record
        // the moderation screen reviews: every entered field + contract).
        const pf = await apiFetch(`/admin/providers/by-user/${id}`).catch(() => null);
        setProviderFile(pf);
      }
    } finally {
      setViewLoading(false);
    }
  };

  const fetchUsers = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const params = new URLSearchParams({ limit: '200', sort: 'newest' });
      if (roleFilter) params.set('role', roleFilter);
      if (searchTerm.trim()) params.set('q', searchTerm.trim());
      const res = await apiFetch(`/admin/users?${params.toString()}`);
      setUsers(Array.isArray(res) ? res : res?.data || []);
      setTotal(res?.total ?? (Array.isArray(res) ? res.length : res?.data?.length ?? 0));
    } catch (err: any) {
      setErrorMsg(err?.message || 'فشل تحميل المستخدمين');
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(fetchUsers, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleFilter, searchTerm]);

  /** Suspend (reversible) — sets active=false + suspended=true in the DB. */
  const handleSuspend = async (u: any) => {
    const id = u.id || u._id;
    if (!confirm(`تعليق حساب «${u.full_name || u.phone}»؟ يمكن إعادة تفعيله لاحقاً.`)) return;
    setActionBusy(id);
    try {
      await apiFetch(`/admin/users/${id}/ban`, { method: 'POST' });
      await fetchUsers();
    } catch (err: any) {
      alert(`فشل التعليق: ${err?.message || ''}`);
    } finally {
      setActionBusy(null);
    }
  };

  /** Reactivate a suspended account. */
  const handleReactivate = async (u: any) => {
    const id = u.id || u._id;
    setActionBusy(id);
    try {
      await apiFetch(`/admin/users/${id}/unban`, { method: 'POST' });
      await fetchUsers();
    } catch (err: any) {
      alert(`فشل إعادة التفعيل: ${err?.message || ''}`);
    } finally {
      setActionBusy(null);
    }
  };

  /** PERMANENT delete — removes the user and their owned records from the DB. */
  const handleDelete = async (u: any) => {
    const id = u.id || u._id;
    const name = u.full_name || u.phone || id;
    if (!confirm(`⚠️ حذف نهائي!\nسيتم حذف «${name}» وبياناته من قاعدة البيانات نهائياً ولا يمكن التراجع.\n\nهل أنت متأكد تماماً؟`)) return;
    if (!confirm(`تأكيد أخير: حذف «${name}» نهائياً من الـ backend وقاعدة البيانات؟`)) return;
    setActionBusy(id);
    try {
      await apiFetch(`/admin/users/${id}`, { method: 'DELETE' });
      await fetchUsers();
    } catch (err: any) {
      alert(`فشل الحذف: ${err?.message || ''}`);
    } finally {
      setActionBusy(null);
    }
  };

  const visibleUsers = useMemo(() => {
    return users.filter((u) => {
      if (statusFilter === 'active') return u.active !== false && !u.suspended;
      if (statusFilter === 'suspended') return u.suspended || u.active === false;
      return true;
    });
  }, [users, statusFilter]);

  return (
    <div className="p-8">
      <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
        <h1 className="text-2xl font-bold">إدارة المستخدمين ({total})</h1>
        <div className="flex flex-wrap gap-3">
          <input
            type="text"
            placeholder="بحث بالاسم أو الهاتف أو البريد..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="border border-gray-300 rounded px-4 py-2 w-64"
          />
          <select
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
            className="border border-gray-300 rounded px-3 py-2 bg-white"
          >
            {ROLE_FILTERS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
          </select>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="border border-gray-300 rounded px-3 py-2 bg-white"
          >
            <option value="">كل الحالات</option>
            <option value="active">نشط</option>
            <option value="suspended">موقوف / معلّق</option>
          </select>
        </div>
      </div>

      {errorMsg && (
        <div className="mb-4 p-3 bg-red-50 border border-red-300 text-red-700 rounded">{errorMsg}</div>
      )}

      {loading ? (
        <div className="p-8 text-center text-gray-500">جاري التحميل...</div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الاسم</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الهاتف / البريد</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الدور</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الحالة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {visibleUsers.map((u) => {
                const id = u.id || u._id;
                const suspended = !!u.suspended || u.active === false;
                const isAdmin = u.role === 'admin' || u.role === 'super_admin';
                return (
                  <tr key={id}>
                    <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                      {u.full_name || u.name || 'مستخدم'}
                      {u.is_guest && <span className="mr-2 text-xs text-gray-400">(زائر)</span>}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500" dir="ltr">
                      {u.phone || u.email || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      {ROLE_LABELS[String(u.role || 'patient').toLowerCase()] || u.role || 'مريض'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${suspended ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                        {suspended ? 'موقوف' : 'نشط'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      {isAdmin ? (
                        <span className="text-gray-400 text-xs">محمي</span>
                      ) : (
                        <div className="flex gap-3">
                          <button
                            onClick={() => openUserFile(u)}
                            className="text-teal-700 hover:text-teal-900 font-bold"
                          >
                            عرض الملف
                          </button>
                          {suspended ? (
                            <button
                              onClick={() => handleReactivate(u)}
                              disabled={actionBusy === id}
                              className="text-green-600 hover:text-green-900 font-bold disabled:opacity-50"
                            >
                              إعادة تفعيل
                            </button>
                          ) : (
                            <button
                              onClick={() => handleSuspend(u)}
                              disabled={actionBusy === id}
                              className="text-amber-600 hover:text-amber-900 font-bold disabled:opacity-50"
                            >
                              تعليق / إيقاف
                            </button>
                          )}
                          <button
                            onClick={() => handleDelete(u)}
                            disabled={actionBusy === id}
                            className="text-red-600 hover:text-red-900 font-bold disabled:opacity-50"
                          >
                            حذف نهائي
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
              {visibleUsers.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-gray-500">لا يوجد مستخدمين مطابقين.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* ═══ User / Provider full-file modal ═══ */}
      {viewUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-[100] flex items-start justify-center overflow-y-auto py-8" onClick={() => setViewUser(null)}>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl mx-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-slate-900 text-white rounded-t-xl">
              <h2 className="text-lg font-bold">
                ملف المستخدم: {viewUser.full_name || viewUser.name || viewUser.phone || viewUser.email || '—'}
                <span className="mr-3 text-xs bg-slate-700 px-2 py-1 rounded">{ROLE_LABELS[String(viewUser.role || 'patient').toLowerCase()] || viewUser.role}</span>
              </h2>
              <button onClick={() => setViewUser(null)} className="text-slate-300 hover:text-white text-2xl font-bold leading-none">&times;</button>
            </div>
            <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
              {viewLoading && <p className="text-center text-gray-400 py-8">جاري تحميل الملف الكامل…</p>}

              {!viewLoading && userOverview?.user && (
                <div className="border border-gray-200 rounded-xl overflow-hidden">
                  <div className="bg-slate-700 text-white px-4 py-2.5 font-bold text-sm">بيانات المستخدم والنشاط</div>
                  <div className="p-4 grid grid-cols-2 gap-4">
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">الاسم الكامل</label><p className="text-gray-800">{userOverview.user.full_name || '—'}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">الهاتف</label><p className="text-gray-800 font-mono text-sm" dir="ltr">{userOverview.user.phone || '—'}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">البريد الإلكتروني</label><p className="text-gray-800 font-mono text-sm">{userOverview.user.email || '—'}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">المدينة</label><p className="text-gray-800">{userOverview.user.city || '—'}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">الحالة</label><p className="text-gray-800">{userOverview.user.suspended ? 'موقوف' : userOverview.user.active ? 'نشط' : 'غير نشط'}{userOverview.user.verified ? ' — موثّق' : ''}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">تاريخ التسجيل</label><p className="text-gray-800 font-mono text-sm">{userOverview.user.createdAt ? String(userOverview.user.createdAt).slice(0, 19).replace('T', ' ') : '—'}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">إجمالي المواعيد</label><p className="text-gray-800">{userOverview.activity?.appointments_total ?? 0}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">بلاغات الطوارئ</label><p className="text-gray-800">{userOverview.activity?.sos_total ?? 0}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">الأجهزة المسجلة</label><p className="text-gray-800">{userOverview.devices?.registered_count ?? 0}</p></div>
                    <div className="space-y-1"><label className="text-sm font-bold text-gray-500">آخر دخول</label><p className="text-gray-800 font-mono text-sm">{userOverview.user.last_login_at ? String(userOverview.user.last_login_at).slice(0, 19).replace('T', ' ') : '—'}</p></div>
                  </div>
                </div>
              )}

              {!viewLoading && providerFile && (
                <ProviderFullDetail detail={providerFile} accountId={providerFile.account?.id || providerFile.onboarding?.account_id} />
              )}

              {!viewLoading && !userOverview && !providerFile && (
                <p className="text-center text-gray-500 py-8">تعذر تحميل تفاصيل هذا المستخدم.</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
