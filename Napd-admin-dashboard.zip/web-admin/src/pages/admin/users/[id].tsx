import { useEffect, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { apiFetch } from '../../../utils/api';

const ROLE_AR: Record<string, string> = {
  patient: 'مريض', doctor: 'طبيب', pharmacy: 'صيدلية', hospital: 'مستشفى',
  lab: 'مختبر', radiology: 'أشعة', nursing: 'تمريض', home_care: 'رعاية منزلية',
  ambulance: 'إسعاف', physiotherapist: 'علاج طبيعي', admin: 'أدمن', super_admin: 'أدمن رئيسي',
};
const STATE_AR: Record<string, string> = {
  PENDING: 'بانتظار', CONFIRMED: 'مؤكد', CHECKED_IN: 'حضر', IN_PROGRESS: 'جاري',
  COMPLETED: 'مكتمل', CANCELLED: 'ملغي', NO_SHOW: 'لم يحضر',
  TRIGGERED: 'مُطلق', DISPATCHED: 'تم الإرسال', RESOLVED: 'انتهى', FALSE_ALARM: 'بلاغ كاذب',
  APPROVED: 'مقبول', REJECTED: 'مرفوض',
};
const st = (s?: string) => STATE_AR[s || ''] || s || '—';

export default function UserProfilePage() {
  const router = useRouter();
  const { id } = router.query;
  const [data, setData] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const load = async () => {
    try {
      const res = await apiFetch(`/admin/users/${id}/overview`);
      setData(res);
    } catch (e: any) {
      setError('تعذر تحميل ملف المستخدم');
    }
  };
  useEffect(() => { if (id) load(); }, [id]);

  const setBan = async (ban: boolean) => {
    try {
      await apiFetch(`/admin/users/${id}/${ban ? 'ban' : 'unban'}`, { method: 'POST' });
      setToast(ban ? 'تم حظر الحساب.' : 'تم فك الحظر.');
      await load();
    } catch (e: any) { setToast(`فشل: ${e?.message || ''}`); }
    setTimeout(() => setToast(null), 4000);
  };

  const approve = async () => {
    try {
      await apiFetch(`/admin/approve/${id}`, { method: 'POST' });
      setToast('تم اعتماد المزود — أصبح ظاهرًا للمرضى.');
      await load();
    } catch (e: any) { setToast(`فشل: ${e?.message || ''}`); }
    setTimeout(() => setToast(null), 4000);
  };

  if (error) return <div dir="rtl" className="p-8" style={{ color: '#F0567A' }}>{error}</div>;
  if (!data) return <div dir="rtl" className="p-8" style={{ color: '#93A5B3' }}>جاري التحميل...</div>;

  const u = data.user;
  const card: any = { borderRadius: 14, padding: 18, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', marginBottom: 16 };
  const isProvider = !['patient', 'guest'].includes(u.role);

  return (
    <div dir="rtl" className="p-8" style={{ color: '#EAF2F6', maxWidth: 900 }}>
      <Head><title>ملف المستخدم — {u.full_name}</title></Head>
      <Link href="/admin/users-management" style={{ color: '#19C3D6', fontSize: 13 }}>← عودة لإدارة المستخدمين</Link>

      {toast && <div style={{ marginTop: 10, padding: 10, borderRadius: 10, background: 'rgba(25,195,214,0.1)', border: '1px solid rgba(25,195,214,0.35)', color: '#19C3D6', fontSize: 14 }}>{toast}</div>}

      <div style={{ ...card, marginTop: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 800, margin: 0 }}>{u.full_name || 'مستخدم'}</h1>
            <div style={{ color: '#93A5B3', fontSize: 14, marginTop: 6 }}>
              {ROLE_AR[u.role] || u.role} · {u.phone || '—'} {u.email ? `· ${u.email}` : ''} {u.city ? `· ${u.city}` : ''}
            </div>
            <div style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <span style={{ padding: '2px 12px', borderRadius: 12, fontSize: 12, fontWeight: 700, background: u.active ? 'rgba(46,204,113,0.12)' : 'rgba(240,86,122,0.15)', color: u.active ? '#2ECC71' : '#F0567A' }}>
                {u.active ? 'نشط' : 'محظور / موقوف'}
              </span>
              {isProvider && (
                <span style={{ padding: '2px 12px', borderRadius: 12, fontSize: 12, fontWeight: 700, background: u.verified ? 'rgba(25,195,214,0.12)' : 'rgba(245,166,35,0.12)', color: u.verified ? '#19C3D6' : '#F5A623' }}>
                  {u.verified ? 'معتمد — ظاهر للمرضى' : 'بانتظار الاعتماد — غير ظاهر للمرضى'}
                </span>
              )}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {isProvider && !u.verified && (
              <button onClick={approve} style={{ padding: '9px 18px', borderRadius: 10, border: 'none', cursor: 'pointer', background: 'rgba(25,195,214,0.15)', color: '#19C3D6', fontWeight: 700 }}>اعتماد المزود</button>
            )}
            {!['admin', 'super_admin'].includes(u.role) && (
              <button onClick={() => setBan(u.active)} style={{ padding: '9px 18px', borderRadius: 10, border: 'none', cursor: 'pointer', background: u.active ? 'rgba(240,86,122,0.12)' : 'rgba(46,204,113,0.12)', color: u.active ? '#F0567A' : '#2ECC71', fontWeight: 700 }}>
                {u.active ? 'حظر / إيقاف' : 'فك الحظر'}
              </button>
            )}
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12, marginTop: 16, fontSize: 13, color: '#93A5B3' }}>
          <div>مسجل منذ<br /><b style={{ color: '#EAF2F6' }}>{u.createdAt ? new Date(u.createdAt).toLocaleDateString('ar-SA') : '—'}</b></div>
          <div>آخر تسجيل دخول<br /><b style={{ color: '#EAF2F6' }}>{u.last_login_at ? new Date(u.last_login_at).toLocaleString('ar-SA') : 'لم يسجل بعد'}</b></div>
          <div>الأجهزة المسجلة (إشعارات)<br /><b style={{ color: '#EAF2F6' }}>{data.devices.registered_count}</b></div>
          {u.specialty && <div>التخصص<br /><b style={{ color: '#EAF2F6' }}>{u.specialty}</b></div>}
          {u.license_number && <div>رقم الترخيص<br /><b style={{ color: '#EAF2F6' }}>{u.license_number}</b></div>}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div style={card}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>سجل المواعيد ({data.activity.appointments_total})</h2>
          {data.activity.recent_appointments.length === 0 ? (
            <p style={{ color: '#6B7C8A', fontSize: 13 }}>لا توجد مواعيد مسجلة.</p>
          ) : data.activity.recent_appointments.map((a: any) => (
            <div key={a.id || a._id} style={{ padding: '8px 0', borderTop: '1px solid rgba(255,255,255,0.06)', fontSize: 13 }}>
              <b>{st(a.status || a.state)}</b> · {a.type === 'video' ? 'فيديو' : a.type === 'home' ? 'منزلي' : 'عيادة'} · {a.slot_start ? new Date(a.slot_start).toLocaleString('ar-SA') : ''}
            </div>
          ))}
        </div>

        <div style={card}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>طلبات الطوارئ SOS ({data.activity.sos_total})</h2>
          {data.activity.recent_sos.length === 0 ? (
            <p style={{ color: '#6B7C8A', fontSize: 13 }}>لا توجد طلبات طوارئ.</p>
          ) : data.activity.recent_sos.map((s: any) => (
            <div key={s.id || s._id} style={{ padding: '8px 0', borderTop: '1px solid rgba(255,255,255,0.06)', fontSize: 13 }}>
              <b>{st(s.state)}</b> · {s.createdAt ? new Date(s.createdAt).toLocaleString('ar-SA') : ''}
            </div>
          ))}
        </div>
      </div>

      <div style={card}>
        <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>سجل تعديلات الملف ({data.profile_changes.length})</h2>
        {data.profile_changes.length === 0 ? (
          <p style={{ color: '#6B7C8A', fontSize: 13 }}>لا توجد تعديلات مسجلة على الملف.</p>
        ) : data.profile_changes.map((d: any) => (
          <div key={d.id} style={{ padding: '10px 0', borderTop: '1px solid rgba(255,255,255,0.06)', fontSize: 13 }}>
            <b style={{ color: d.status === 'APPROVED' ? '#2ECC71' : d.status === 'REJECTED' ? '#F0567A' : '#F5A623' }}>{st(d.status)}</b>
            {' · '}{d.created_at ? new Date(d.created_at).toLocaleString('ar-SA') : ''}
            {d.rejection_reason ? <span style={{ color: '#F0567A' }}> · السبب: {d.rejection_reason}</span> : null}
            <div style={{ color: '#6B7C8A', marginTop: 4, direction: 'ltr', textAlign: 'left', fontSize: 11, overflow: 'auto', maxHeight: 80 }}>
              {JSON.stringify(d.new_data)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
