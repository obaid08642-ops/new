import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import { startRegistration } from '@simplewebauthn/browser';
import { apiFetch } from '../../utils/api';

interface PasskeyDevice {
  credential_id: string;
  device_name: string;
  created_at?: string;
  last_used_at?: string;
}

/**
 * Admin security settings — enroll/manage Passkey (WebAuthn) devices for the
 * designated admin account. Enrollment is server-gated: only the designated
 * admin email with role admin/super_admin can call these endpoints.
 * Cross-device enrollment (old Mac ↔ iPhone) works via the browser's QR /
 * hybrid transport: choose "Use a phone or tablet" in the WebAuthn prompt.
 */
export default function AdminSecurity() {
  const [devices, setDevices] = useState<PasskeyDevice[]>([]);
  const [trusted, setTrusted] = useState<any[]>([]);
  const [online, setOnline] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [deviceName, setDeviceName] = useState('');
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const list = await apiFetch('/auth/passkey/devices');
      setDevices(Array.isArray(list) ? list : []);
      const [t, o] = await Promise.all([
        apiFetch('/auth/trusted-devices').catch(() => []),
        apiFetch('/auth/sessions/online').catch(() => []),
      ]);
      setTrusted(Array.isArray(t) ? t : []);
      setOnline(Array.isArray(o) ? o : []);
    } catch (e: any) {
      setMessage({ type: 'err', text: 'تعذر تحميل الأجهزة المسجلة' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const revokeTrusted = async (id: string, name?: string) => {
    if (!window.confirm(`إلغاء اعتماد «${name || 'هذا الجهاز'}»؟ سيُطلب رمز التحقق أو البصمة عند دخوله القادم.`)) return;
    try {
      await apiFetch(`/auth/trusted-devices/${encodeURIComponent(id)}`, { method: 'DELETE' });
      setMessage({ type: 'ok', text: 'تم إلغاء اعتماد الجهاز.' });
      await load();
    } catch {
      setMessage({ type: 'err', text: 'تعذر إلغاء الاعتماد' });
    }
  };

  const enroll = async () => {
    setBusy(true);
    setMessage(null);
    try {
      const options = await apiFetch('/auth/passkey/enroll/options', { method: 'POST' });
      // Opens Face ID / Touch ID / passcode — or QR for cross-device enrollment
      const attestation = await startRegistration({ optionsJSON: options });
      await apiFetch('/auth/passkey/enroll/verify', {
        method: 'POST',
        body: JSON.stringify({ response: attestation, device_name: deviceName.trim() || 'جهاز جديد' }),
      });
      setMessage({ type: 'ok', text: 'تم تسجيل الجهاز بنجاح — سيُطلب مفتاح الأمان عند كل دخول من الآن.' });
      setDeviceName('');
      await load();
    } catch (e: any) {
      // Surface the exact WebAuthn failure so device/browser issues are diagnosable
      const detail = e?.message ? ` (${String(e.message).slice(0, 120)})` : '';
      const text = e?.name === 'NotAllowedError'
        ? 'تم إلغاء التسجيل أو انتهت المهلة — على Mac بدون Touch ID اختر «استخدام هاتف أو جهاز لوحي» في النافذة وامسح QR بالآيفون'
        : `فشل تسجيل الجهاز${detail}`;
      setMessage({ type: 'err', text });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (credentialId: string) => {
    if (!window.confirm('حذف هذا المفتاح؟ لن يتمكن هذا الجهاز من الدخول بعد الآن.')) return;
    setBusy(true);
    try {
      await apiFetch(`/auth/passkey/devices/${encodeURIComponent(credentialId)}`, { method: 'DELETE' });
      setMessage({ type: 'ok', text: 'تم حذف المفتاح.' });
      await load();
    } catch (e: any) {
      setMessage({ type: 'err', text: e?.message?.includes('last') ? 'لا يمكن حذف آخر مفتاح — سجّل جهازاً آخر أولاً.' : 'تعذر حذف المفتاح' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <Head><title>الأمان ومفاتيح الدخول</title></Head>
      <div dir="rtl" style={{ padding: 24, maxWidth: 720, margin: '0 auto', color: '#EAF2F6' }}>
        <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 8 }}>الأمان — مفاتيح الدخول (Passkey)</h1>
        <p style={{ color: '#93A5B3', fontSize: 14, lineHeight: 1.9, marginBottom: 24 }}>
          المصادقة الثنائية الإجبارية للوحة التحكم: كلمة المرور ثم تأكيد بالبصمة (Face ID / Touch ID / رمز القفل).
          سجّل أجهزتك المصرّح لها هنا. لجهاز لا يحمل بصمة (مثل Mac قديم): اختر «استخدام هاتف أو جهاز لوحي»
          في نافذة التسجيل وامسح رمز QR بكاميرا الآيفون ثم أكّد بالـ Face ID.
        </p>

        {message && (
          <div style={{
            marginBottom: 16, padding: 12, borderRadius: 12, fontSize: 14, textAlign: 'center',
            background: message.type === 'ok' ? 'rgba(46,204,113,0.1)' : 'rgba(240,86,122,0.1)',
            border: `1px solid ${message.type === 'ok' ? 'rgba(46,204,113,0.35)' : 'rgba(240,86,122,0.35)'}`,
            color: message.type === 'ok' ? '#2ECC71' : '#F0567A',
          }}>
            {message.text}
          </div>
        )}

        <div style={{
          borderRadius: 16, padding: 20, marginBottom: 24,
          background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>تسجيل جهاز جديد</h2>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <input
              value={deviceName} onChange={(e) => setDeviceName(e.target.value)}
              placeholder="اسم الجهاز (مثال: iPhone 15 / MacBook)"
              style={{
                flex: 1, minWidth: 220, padding: '12px 14px', borderRadius: 10,
                border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.04)',
                color: '#EAF2F6', fontSize: 14, outline: 'none',
              }}
            />
            <button
              onClick={enroll} disabled={busy}
              style={{
                padding: '12px 22px', borderRadius: 10, border: 'none', cursor: 'pointer',
                background: 'linear-gradient(135deg, #19C3D6, #0E8FA3)', color: '#04121a',
                fontWeight: 800, fontSize: 14, opacity: busy ? 0.6 : 1,
              }}
            >
              {busy ? 'بانتظار البصمة...' : '🔐 تسجيل بمفتاح أمان'}
            </button>
          </div>
        </div>

        <div style={{
          borderRadius: 16, padding: 20,
          background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>الأجهزة المسجلة</h2>
          {loading ? (
            <p style={{ color: '#93A5B3', fontSize: 14 }}>جاري التحميل...</p>
          ) : devices.length === 0 ? (
            <p style={{ color: '#93A5B3', fontSize: 14, lineHeight: 1.8 }}>
              لا توجد أجهزة مسجلة بعد. سجّل جهازك الأول — بعدها يصبح مفتاح الأمان إجبارياً عند كل تسجيل دخول.
            </p>
          ) : (
            <div style={{ display: 'grid', gap: 10 }}>
              {devices.map((d) => (
                <div key={d.credential_id} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
                  padding: '12px 14px', borderRadius: 10, background: 'rgba(255,255,255,0.03)',
                  border: '1px solid rgba(255,255,255,0.08)',
                }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{d.device_name || 'جهاز'}</div>
                    <div style={{ color: '#6B7C8A', fontSize: 12, marginTop: 4 }}>
                      سُجّل: {d.created_at ? new Date(d.created_at).toLocaleString('ar') : '—'}
                      {' · '}آخر استخدام: {d.last_used_at ? new Date(d.last_used_at).toLocaleString('ar') : '—'}
                    </div>
                  </div>
                  <button
                    onClick={() => remove(d.credential_id)} disabled={busy}
                    style={{
                      padding: '8px 16px', borderRadius: 8, cursor: 'pointer', fontSize: 13,
                      border: '1px solid rgba(240,86,122,0.4)', background: 'rgba(240,86,122,0.08)',
                      color: '#F0567A', fontWeight: 700,
                    }}
                  >
                    حذف
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Trusted devices (skip second factor after first full 2FA) */}
        <div style={{
          borderRadius: 16, padding: 20, marginTop: 24,
          background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 6 }}>الأجهزة المعتمدة</h2>
          <p style={{ color: '#93A5B3', fontSize: 13, lineHeight: 1.8, marginBottom: 14 }}>
            الجهاز المعتمد يدخل بكلمة المرور فقط بعد أول تحقق كامل (بصمة أو رمز بريد).
            أي جهاز جديد يكمل التحقق يصلك عنه تنبيه بريدي فوري، ويمكنك إلغاء اعتماده من هنا.
          </p>
          {loading ? (
            <p style={{ color: '#93A5B3', fontSize: 14 }}>جاري التحميل...</p>
          ) : trusted.length === 0 ? (
            <p style={{ color: '#93A5B3', fontSize: 14 }}>لا توجد أجهزة معتمدة بعد — يُعتمد كل جهاز تلقائيًا بعد أول دخول ناجح بالتحقق الثنائي.</p>
          ) : (
            <div style={{ display: 'grid', gap: 10 }}>
              {trusted.map((d: any) => (
                <div key={d.id} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
                  padding: '12px 14px', borderRadius: 10, background: 'rgba(255,255,255,0.03)',
                  border: '1px solid rgba(255,255,255,0.08)',
                }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{d.name || 'جهاز'}</div>
                    <div style={{ color: '#6B7C8A', fontSize: 12, marginTop: 4 }}>
                      آخر ظهور: {d.last_seen_at ? new Date(d.last_seen_at).toLocaleString('ar') : '—'}
                      {d.last_ip ? ` · IP: ${d.last_ip}` : ''}
                    </div>
                  </div>
                  <button
                    onClick={() => revokeTrusted(d.id, d.name)}
                    style={{
                      padding: '8px 16px', borderRadius: 8, cursor: 'pointer', fontSize: 13,
                      border: '1px solid rgba(245,166,35,0.4)', background: 'rgba(245,166,35,0.08)',
                      color: '#F5A623', fontWeight: 700,
                    }}
                  >
                    إلغاء الاعتماد
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Live sessions */}
        <div style={{
          borderRadius: 16, padding: 20, marginTop: 24,
          background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>الأجهزة المتصلة الآن (أونلاين)</h2>
          {online.length === 0 ? (
            <p style={{ color: '#93A5B3', fontSize: 14 }}>لا توجد جلسات نشطة حاليًا (تُحدَّث كل دقيقة أثناء تصفح اللوحة).</p>
          ) : (
            <div style={{ display: 'grid', gap: 8 }}>
              {online.map((s: any) => (
                <div key={s.session} style={{
                  padding: '10px 14px', borderRadius: 10, background: 'rgba(46,204,113,0.06)',
                  border: '1px solid rgba(46,204,113,0.25)', fontSize: 13,
                }}>
                  <span style={{ color: '#2ECC71', fontWeight: 700 }}>● {s.name || 'جهاز'}</span>
                  <span style={{ color: '#6B7C8A', marginInlineStart: 10 }}>{s.ip || ''} · {s.at ? new Date(s.at).toLocaleTimeString('ar') : ''}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
