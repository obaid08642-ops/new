import { useEffect, useState } from 'react';
import { AdminGuard } from '../../components/AdminGuard';
import { apiFetch } from '../../utils/api';

type ReferralReport = {
  funnel: { total_invites: number; registered: number; rewarded: number; users_with_code: number };
  points: { referral_points_paid: number; referral_transactions: number };
  top_referrers: { user_id: string; name: string; invites: number; rewarded: number; points: number }[];
  recent_invites: { id: string; referrer: string; referred: string; status: string; reward_points: number; created_at: string }[];
};

type LoyaltyOverview = {
  accounts_total: number;
  points_in_circulation: number;
  lifetime_points_issued: number;
  tiers: Record<string, number>;
  top_earners: { user_id: string; name: string; points: number; lifetime_points: number; tier: string }[];
  recent_transactions: { user: string; points_delta: number; reason: string; created_at: string }[];
};

const Stat = ({ label, value, accent }: { label: string; value: string | number; accent?: string }) => (
  <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
    <div className="text-sm text-gray-500">{label}</div>
    <div className={`text-2xl font-bold mt-1 ${accent || 'text-gray-900'}`}>{value}</div>
  </div>
);

export default function ReferralsPage() {
  const [report, setReport] = useState<ReferralReport | null>(null);
  const [loyalty, setLoyalty] = useState<LoyaltyOverview | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [r, l] = (await Promise.all([
          apiFetch('/admin/referrals/report'),
          apiFetch('/admin/loyalty/overview'),
        ])) as [ReferralReport, LoyaltyOverview];
        setReport(r);
        setLoyalty(l);
      } catch (e: any) {
        setError(e?.message || 'تعذر تحميل التقارير');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <AdminGuard>
      <div className="p-6 space-y-8" dir="rtl">
        <h1 className="text-2xl font-bold">تقارير الإحالة ونقاط الولاء</h1>
        {loading && <div className="text-gray-500">جارٍ التحميل…</div>}
        {error && <div className="bg-red-50 text-red-700 rounded-lg p-3">{error}</div>}

        {report && (
          <section className="space-y-4">
            <h2 className="text-lg font-semibold">برنامج الإحالة (دعوة مريض/مستخدم جديد)</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Stat label="إجمالي الدعوات المرسلة" value={report.funnel.total_invites} />
              <Stat label="سجّلوا عبر دعوة" value={report.funnel.registered} />
              <Stat label="دعوات تمت مكافأتها" value={report.funnel.rewarded} accent="text-emerald-600" />
              <Stat label="مستخدمون لديهم كود إحالة" value={report.funnel.users_with_code} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Stat label="نقاط الإحالة المصروفة" value={report.points.referral_points_paid} accent="text-indigo-600" />
              <Stat label="معاملات نقاط الإحالة" value={report.points.referral_transactions} />
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-4 py-3 font-semibold border-b">أعلى المُحيلين</div>
              {report.top_referrers.length === 0 ? (
                <div className="p-4 text-gray-500 text-sm">لا توجد دعوات مسجلة بعد — ستظهر هنا فور بدء المستخدمين بإرسال الدعوات.</div>
              ) : (
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 text-gray-600">
                    <tr><th className="p-2 text-right">المستخدم</th><th className="p-2">دعوات</th><th className="p-2">مكافأة</th><th className="p-2">النقاط</th></tr>
                  </thead>
                  <tbody>
                    {report.top_referrers.map((r) => (
                      <tr key={r.user_id} className="border-t">
                        <td className="p-2">{r.name}</td>
                        <td className="p-2 text-center">{r.invites}</td>
                        <td className="p-2 text-center">{r.rewarded}</td>
                        <td className="p-2 text-center font-semibold text-indigo-600">{r.points}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-4 py-3 font-semibold border-b">أحدث الدعوات</div>
              {report.recent_invites.length === 0 ? (
                <div className="p-4 text-gray-500 text-sm">لا توجد دعوات حديثة.</div>
              ) : (
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 text-gray-600">
                    <tr><th className="p-2 text-right">المُحيل</th><th className="p-2 text-right">المُحال</th><th className="p-2">الحالة</th><th className="p-2">النقاط</th><th className="p-2">التاريخ</th></tr>
                  </thead>
                  <tbody>
                    {report.recent_invites.map((i) => (
                      <tr key={i.id} className="border-t">
                        <td className="p-2">{i.referrer}</td>
                        <td className="p-2">{i.referred}</td>
                        <td className="p-2 text-center">{i.status === 'rewarded' ? 'تمت المكافأة' : 'مسجّل'}</td>
                        <td className="p-2 text-center">{i.reward_points}</td>
                        <td className="p-2 text-center text-gray-500">{new Date(i.created_at).toLocaleString('ar')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </section>
        )}

        {loyalty && (
          <section className="space-y-4">
            <h2 className="text-lg font-semibold">نظام نقاط الولاء</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Stat label="حسابات النقاط" value={loyalty.accounts_total} />
              <Stat label="النقاط المتداولة" value={loyalty.points_in_circulation} accent="text-indigo-600" />
              <Stat label="إجمالي النقاط المصدرة" value={loyalty.lifetime_points_issued} />
              <Stat label="الفئات" value={Object.entries(loyalty.tiers).map(([t, c]) => `${t}: ${c}`).join('، ') || '—'} />
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-4 py-3 font-semibold border-b">أعلى المستخدمين نقاطاً</div>
              <table className="w-full text-sm">
                <thead className="bg-gray-50 text-gray-600">
                  <tr><th className="p-2 text-right">المستخدم</th><th className="p-2">الرصيد</th><th className="p-2">الإجمالي التراكمي</th><th className="p-2">الفئة</th></tr>
                </thead>
                <tbody>
                  {loyalty.top_earners.map((u) => (
                    <tr key={u.user_id} className="border-t">
                      <td className="p-2">{u.name}</td>
                      <td className="p-2 text-center font-semibold text-indigo-600">{u.points}</td>
                      <td className="p-2 text-center">{u.lifetime_points}</td>
                      <td className="p-2 text-center">{u.tier}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-4 py-3 font-semibold border-b">أحدث معاملات النقاط</div>
              <table className="w-full text-sm">
                <thead className="bg-gray-50 text-gray-600">
                  <tr><th className="p-2 text-right">المستخدم</th><th className="p-2">التغيير</th><th className="p-2 text-right">السبب</th><th className="p-2">التاريخ</th></tr>
                </thead>
                <tbody>
                  {loyalty.recent_transactions.map((t, idx) => (
                    <tr key={idx} className="border-t">
                      <td className="p-2">{t.user}</td>
                      <td className={`p-2 text-center font-semibold ${t.points_delta >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{t.points_delta > 0 ? `+${t.points_delta}` : t.points_delta}</td>
                      <td className="p-2">{t.reason}</td>
                      <td className="p-2 text-center text-gray-500">{new Date(t.created_at).toLocaleString('ar')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </div>
    </AdminGuard>
  );
}
