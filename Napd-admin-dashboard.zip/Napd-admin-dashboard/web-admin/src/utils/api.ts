const getBase = () => process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8002';

let refreshPromise: Promise<boolean> | null = null;

/**
 * Access tokens live 1 hour. When one expires we silently rotate it through
 * the refresh token (7 days, rotating + device-bound on the server) and retry
 * the original request — the admin never sees a spurious "access denied".
 */
const tryRefresh = async (): Promise<boolean> => {
  if (typeof window === 'undefined') return false;
  const refreshToken = localStorage.getItem('admin_refresh_token');
  if (!refreshToken) return false;
  // Deduplicate concurrent refreshes (many pages fire parallel requests)
  if (!refreshPromise) {
    refreshPromise = (async () => {
      try {
        const res = await fetch(`${getBase()}/api/v1/auth/refresh`, {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refresh_token: refreshToken }),
        });
        if (!res.ok) return false;
        const data = await res.json();
        const access = data?.accessToken || data?.token?.accessToken;
        const refresh = data?.refreshToken || data?.token?.refreshToken;
        if (!access) return false;
        localStorage.setItem('admin_token', access);
        if (refresh) localStorage.setItem('admin_refresh_token', refresh);
        return true;
      } catch {
        return false;
      } finally {
        setTimeout(() => { refreshPromise = null; }, 500);
      }
    })();
  }
  return refreshPromise;
};

const forceReLogin = () => {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('admin_token');
  localStorage.removeItem('admin_refresh_token');
  if (!window.location.pathname.startsWith('/login')) {
    window.location.href = '/login';
  }
};

export const fetchWithAdminGuard = async (url: string, options: RequestInit = {}) => {
  const buildHeaders = () => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('admin_token') : null;
    return {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    };
  };

  // Same-site (nabd.plus) cookies carry the trusted-device + admin session
  // cookies; without this the device-trust fast-path can never engage.
  let response = await fetch(url, { ...options, credentials: 'include', headers: buildHeaders() });

  if (response.status === 401) {
    // Most likely just an expired 1-hour access token — rotate and retry once
    const refreshed = await tryRefresh();
    if (refreshed) {
      response = await fetch(url, { ...options, credentials: 'include', headers: buildHeaders() });
    } else {
      forceReLogin();
      throw new Error('انتهت الجلسة — يرجى تسجيل الدخول من جديد.');
    }
  }

  if (response.status === 401 || response.status === 403) {
    let serverMsg = '';
    try {
      const clone = response.clone();
      const data = await clone.json();
      serverMsg = Array.isArray(data?.message) ? data.message[0] : data?.message || '';
    } catch { /* keep generic */ }
    throw new Error(serverMsg || 'ليس لديك صلاحية الوصول لهذا الإجراء (رفض من حارس الخادم).');
  }

  return response;
};

export const apiFetch = async (endpoint: string, options: RequestInit = {}) => {
  const url = endpoint.startsWith('http') ? endpoint : `${getBase()}/api/v1${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;
  const response = await fetchWithAdminGuard(url, options);
  if (!response.ok) {
    let serverMsg = '';
    try {
      const data = await response.clone().json();
      serverMsg = Array.isArray(data?.message) ? data.message[0] : data?.message || '';
    } catch { /* keep generic */ }
    throw new Error(serverMsg || `HTTP ${response.status}: ${response.statusText}`);
  }
  return response.json();
};
