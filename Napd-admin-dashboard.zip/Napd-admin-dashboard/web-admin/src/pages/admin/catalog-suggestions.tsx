import { useEffect, useState } from 'react';
import { apiFetch } from '../../utils/api';

const TYPE_LABELS: Record<string, string> = {
  field_edit: 'تعديل بيانات',
  image_remove: 'حذف صورة',
  shortage_badge: 'شارة ناقص',
  duplicate_remove: 'حذف صنف مكرر',
  new_item: 'صنف جديد',
  other: 'أخرى',
};
const TYPE_COLORS: Record<string, string> = {
  field_edit: 'bg-blue-100 text-blue-700',
  image_remove: 'bg-orange-100 text-orange-700',
  shortage_badge: 'bg-amber-100 text-amber-700',
  duplicate_remove: 'bg-red-100 text-red-700',
  new_item: 'bg-emerald-100 text-emerald-700',
  other: 'bg-slate-100 text-slate-600',
};
const FIELD_LABELS: Record<string, string> = {
  name_ar: 'الاسم (عربي)', name_en: 'الاسم (إنجليزي)', active_ingredient: 'المادة الفعالة',
  generic_name: 'الاسم العلمي', manufacturer: 'الشركة المصنعة', category: 'الفئة',
  description_ar: 'الوصف (عربي)', description_en: 'الوصف (إنجليزي)', dosage_ar: 'الجرعة (عربي)',
  dosage_en: 'الجرعة (إنجليزي)', form: 'الشكل الصيدلاني', strength: 'التركيز',
  usage_instructions_ar: 'إرشادات الاستخدام (عربي)', usage_instructions_en: 'إرشادات الاستخدام (إنجليزي)',
  requires_prescription: 'يتطلب وصفة', barcode: 'الباركود', price: 'السعر',
};
const EDITABLE_FIELDS = Object.keys(FIELD_LABELS);

type Req = {
  id: string; type: string; medicine_id: string | null; medicine_name: string;
  changes: any; current_values: any; note: string | null;
  reporter_id: string; reporter_role: string; status: string;
  rejection_reason?: string | null; createdAt: string;
};

function Diff({ req }: { req: Req }) {
  const keys = Object.keys(req.changes || {});
  if (req.type === 'new_item') {
    return (
      <div className="text-sm space-y-1">
        {keys.map(k => (
          <div key={k} className="flex gap-2"><span className="text-slate-500 min-w-32">{FIELD_LABELS[k] || k}:</span><span className="font-medium text-emerald-700">{String(req.changes[k])}</span></div>
        ))}
      </div>
    );
  }
  if (keys.length === 0) return <div className="text-sm text-slate-500">{req.note || 'بدون تفاصيل إضافية'}</div>;
  return (
    <div className="text-sm space-y-1">
      {keys.map(k => (
        <div key={k} className="flex gap-2 flex-wrap">
          <span className="text-slate-500 min-w-32">{FIELD_LABELS[k] || k}:</span>
          <span className="line-through text-red-500">{String(req.current_values?.[k] ?? '—')}</span>
          <span className="text-slate-400">←</span>
          <span className="font-medium text-emerald-700">{String(req.changes[k])}</span>
        </div>
      ))}
    </div>
  );
}

export default function CatalogSuggestionsPage() {
  const [tab, setTab] = useState<'requests' | 'direct'>('requests');
  const [status, setStatus] = useState('pending');
  const [type, setType] = useState('');
  const [items, setItems] = useState<Req[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  // direct edit state
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [selected, setSelected] = useState<any | null>(null);
  const [edit, setEdit] = useState<any>({});

  const load = async () => {
    setLoading(true);
    try {
      const r = await apiFetch(`/medicines/admin/change-requests?status=${status}${type ? `&type=${type}` : ''}&limit=50`);
      setItems(r.data || []); setTotal(r.total || 0);
    } catch (e: any) { setMsg(e.message); } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [status, type]);

  const act = async (id: string, action: 'approve' | 'reject') => {
    const reason = action === 'reject' ? (prompt('سبب الرفض (يظهر للمستخدم):') || '') : undefined;
    if (action === 'reject' && reason === null) return;
    try {
      await apiFetch(`/medicines/admin/change-requests/${id}/${action}`, { method: 'POST', body: JSON.stringify({ reason }) });
      setMsg(action === 'approve' ? 'تم الاعتماد وتطبيق التعديل فوراً على الكتالوج' : 'تم الرفض');
      load();
    } catch (e: any) { setMsg(e.message); }
  };

  const search = async () => {
    if (!q.trim()) return;
    const r = await apiFetch(`/medicines?search=${encodeURIComponent(q)}&limit=10`);
    setResults(r.data || r.items || []);
  };

  const saveDirect = async () => {
    const patch: any = {};
    for (const k of Object.keys(edit)) if (edit[k] !== selected[k]) patch[k] = edit[k];
    if (Object.keys(patch).length === 0) { setMsg('لم يتم تغيير أي حقل'); return; }
    try {
      await apiFetch(`/medicines/admin/catalog/${selected.id || selected._id}`, { method: 'PATCH', body: JSON.stringify(patch) });
      setMsg('تم حفظ التعديل المباشر بنجاح');
      setSelected(null); setResults([]); setQ('');
    } catch (e: any) { setMsg(e.message); }
  };

  return (
    <div dir="rtl" className="p-6 space-y-4">
      <h1 className="text-2xl font-bold text-slate-900">اقتراحات تعديل الكتالوج</h1>
      <p className="text-sm text-slate-500">كل تعديل مقترح من مريض أو مزود (صورة، مادة فعالة، وصف، شارة ناقص، صنف جديد، حذف مكرر…) يصل هنا — لا يدخل حيز التنفيذ إلا باعتمادك.</p>

      <div className="flex gap-2">
        <button onClick={() => setTab('requests')} className={`px-4 py-2 rounded-lg text-sm font-semibold ${tab === 'requests' ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>طلبات التعديل ({total})</button>
        <button onClick={() => setTab('direct')} className={`px-4 py-2 rounded-lg text-sm font-semibold ${tab === 'direct' ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>تعديل مباشر من الأدمن</button>
      </div>

      {msg && <div className="bg-teal-50 border border-teal-200 text-teal-800 rounded-lg px-4 py-2 text-sm">{msg}</div>}

      {tab === 'requests' && (
        <>
          <div className="flex gap-2 flex-wrap">
            {['pending', 'approved', 'rejected', 'all'].map(s => (
              <button key={s} onClick={() => setStatus(s)} className={`px-3 py-1.5 rounded-full text-xs font-semibold ${status === s ? 'bg-slate-800 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
                {s === 'pending' ? 'بانتظار الاعتماد' : s === 'approved' ? 'معتمدة' : s === 'rejected' ? 'مرفوضة' : 'الكل'}
              </button>
            ))}
            <span className="mx-2 border-r border-slate-200" />
            {['', ...Object.keys(TYPE_LABELS)].map(t => (
              <button key={t} onClick={() => setType(t)} className={`px-3 py-1.5 rounded-full text-xs ${type === t ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
                {t === '' ? 'كل الأنواع' : TYPE_LABELS[t]}
              </button>
            ))}
          </div>

          {loading && <div className="text-slate-500 text-sm">جارٍ التحميل…</div>}
          {!loading && items.length === 0 && <div className="bg-white border border-slate-200 rounded-xl p-6 text-center text-slate-500 text-sm">لا توجد طلبات بهذه المواصفات — الطلبات الجديدة من التطبيقات تظهر هنا فور وصولها.</div>}

          <div className="space-y-3">
            {items.map(r => (
              <div key={r.id} className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <div className="flex items-center gap-2 flex-wrap mb-2">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${TYPE_COLORS[r.type] || TYPE_COLORS.other}`}>{TYPE_LABELS[r.type] || r.type}</span>
                  <span className="font-bold text-slate-900">{r.medicine_name}</span>
                  <span className="text-xs text-slate-400">من: {r.reporter_role} · {new Date(r.createdAt).toLocaleString('ar')}</span>
                  {r.status !== 'pending' && <span className={`text-xs font-bold ${r.status === 'approved' ? 'text-emerald-600' : 'text-red-500'}`}>{r.status === 'approved' ? 'معتمد' : `مرفوض${r.rejection_reason ? `: ${r.rejection_reason}` : ''}`}</span>}
                </div>
                <Diff req={r} />
                {r.note && <div className="text-xs text-slate-500 mt-1">ملاحظة المُقترح: {r.note}</div>}
                {r.status === 'pending' && (
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => act(r.id, 'approve')} className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700">اعتماد وتطبيق</button>
                    <button onClick={() => act(r.id, 'reject')} className="px-4 py-1.5 rounded-lg bg-white border border-red-300 text-red-600 text-sm font-semibold hover:bg-red-50">رفض</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      {tab === 'direct' && (
        <div className="space-y-3">
          <div className="flex gap-2">
            <input value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && search()} placeholder="ابحث عن أي صنف بالاسم أو المادة الفعالة…" className="flex-1 border border-slate-300 rounded-lg px-4 py-2 text-sm text-slate-900 bg-white" />
            <button onClick={search} className="px-5 py-2 rounded-lg bg-teal-600 text-white text-sm font-semibold">بحث</button>
          </div>
          {results.length > 0 && !selected && (
            <div className="bg-white border border-slate-200 rounded-xl divide-y">
              {results.map((m: any) => (
                <button key={m.id || m._id} onClick={() => { setSelected(m); setEdit({ ...m }); }} className="w-full text-right px-4 py-3 hover:bg-slate-50 flex justify-between items-center">
                  <span className="font-medium text-slate-900">{m.name_ar || m.name_en}</span>
                  <span className="text-xs text-slate-500">{m.active_ingredient || ''} {m.price ? `· ${m.price} ر.س` : ''}</span>
                </button>
              ))}
            </div>
          )}
          {selected && (
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <div className="flex justify-between items-center">
                <h2 className="font-bold text-slate-900">تعديل: {selected.name_ar || selected.name_en}</h2>
                <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-slate-600 text-sm">إلغاء</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {EDITABLE_FIELDS.map(f => (
                  <label key={f} className="text-xs text-slate-500 space-y-1">
                    <span>{FIELD_LABELS[f]}</span>
                    <input
                      value={edit[f] ?? ''}
                      onChange={e => setEdit({ ...edit, [f]: f === 'price' ? Number(e.target.value) : f === 'requires_prescription' ? e.target.value === 'true' : e.target.value })}
                      className={`w-full border rounded-lg px-3 py-2 text-sm bg-white text-slate-900 ${edit[f] !== selected[f] ? 'border-amber-400 bg-amber-50' : 'border-slate-300'}`}
                    />
                  </label>
                ))}
                <label className="text-xs text-slate-500 space-y-1">
                  <span>حالة التوفر / شارة الناقص</span>
                  <select value={edit.availability_status || 'none'} onChange={e => setEdit({ ...edit, availability_status: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm bg-white text-slate-900">
                    <option value="none">متوفر (بدون شارة)</option>
                    <option value="availability_may_be_limited">قد يكون غير متوفر</option>
                    <option value="admin_flagged_shortage">ناقص (شارة رسمية)</option>
                    <option value="discontinued">متوقف</option>
                  </select>
                </label>
              </div>
              <button onClick={saveDirect} className="px-6 py-2 rounded-lg bg-emerald-600 text-white text-sm font-bold hover:bg-emerald-700">حفظ التعديلات</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
