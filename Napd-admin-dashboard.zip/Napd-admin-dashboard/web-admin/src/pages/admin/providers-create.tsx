import { useState } from 'react';
import Head from 'next/head';
import { apiFetch } from '../../utils/api';

const ROLES = [
  { key: 'doctor', ar: 'طبيب' }, { key: 'pharmacy', ar: 'صيدلية' },
  { key: 'hospital', ar: 'مستشفى' }, { key: 'lab', ar: 'مختبر' },
  { key: 'radiology', ar: 'مركز أشعة' }, { key: 'nursing', ar: 'تمريض' },
  { key: 'home_care', ar: 'رعاية منزلية' }, { key: 'ambulance', ar: 'إسعاف' },
  { key: 'physiotherapist', ar: 'علاج طبيعي' },
];

export default function ProvidersCreatePage() {
  const [form, setForm] = useState({
    role: 'doctor', full_name: '', email: '', phone: '',
    password: '', specialty: '', license_number: '', city: '',
  });
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  const create = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await apiFetch('/admin/providers/create', {
        method: 'POST',
        body: JSON.stringify({
          role: form.role,
          full_name: form.full_name.trim(),
          email: form.email.trim() || undefined,
          phone: form.phone.trim() || undefined,
          password: form.password || undefined,
          specialty: form.specialty.trim() || undefined,
          license_number: form.license_number.trim() || undefined,
          city: form.city.trim() || undefined,
        }),
      });
      setCreated(res);
      setForm({ role: 'doctor', full_name: '', email: '', phone: '', password: '', specialty: '', license_number: '', city: '' });
    } catch (e: any) {
      setError(`فشل الإنشاء: ${e?.message || ''}`);
    } finally {
      setBusy(false);
    }
  };

  const inputStyle: any = {
    width: '100%', padding: '11px 14px', borderRadius: 10, marginBottom: 10,
    border: '1px solid #CBD5E1', background: '#FFFFFF',
    color: '#0F172A', fontSize: 14, outline: 'none', boxSizing: 'border-box',
  };

  return (
    <div dir="rtl" className="p-8" style={{ color: '#0F172A', maxWidth: 640 }}>
      <Head><title>إنشاء حساب مزود خدمة</title></Head>
      <h1 className="text-2xl font-bold" style={{ marginBottom: 8 }}>إنشاء حساب مزود خدمة</h1>
      <p style={{ color: '#64748B', fontSize: 14, lineHeight: 1.9, marginBottom: 20 }}>
        أنشئ الحساب من هنا وسلّم بيانات الدخول للمزود. يسجّل المزود دخوله في <b>تطبيق المزود</b>،
        يكمل إعداداته ويرفع أوراقه، ثم يظهر في صفحة <b>اعتماد المزودين</b> — ولن يظهر للمرضى
        إلا بعد اعتمادك النهائي.
      </p>

      {created && (
        <div style={{ marginBottom: 16, padding: 16, borderRadius: 12, background: 'rgba(22,163,74,0.08)', border: '1px solid rgba(22,163,74,0.35)' }}>
          <b style={{ color: '#16A34A' }}>تم إنشاء الحساب — بانتظار إكمال المزود لأوراقه ثم اعتمادك.</b>
          <div style={{ marginTop: 8, fontSize: 14, color: '#64748B' }}>
            الدور: {ROLES.find(r => r.key === created.role)?.ar || created.role}<br />
            {created.email ? <>البريد: <code style={{ color: '#0F172A' }}>{created.email}</code><br /></> : null}
            {created.phone ? <>الجوال: <code style={{ color: '#0F172A' }}>{created.phone}</code><br /></> : null}
            {created.initial_password ? <>كلمة المرور الأولية: <code style={{ color: '#B45309', fontSize: 16 }}>{created.initial_password}</code> (تظهر مرة واحدة فقط)</> : null}
          </div>
          <button onClick={() => setCreated(null)} style={{ marginTop: 10, padding: '6px 16px', borderRadius: 8, border: 'none', background: '#E2E8F0', color: '#0F172A', cursor: 'pointer' }}>إنشاء حساب آخر</button>
        </div>
      )}

      {error && <div style={{ marginBottom: 12, padding: 10, borderRadius: 10, background: 'rgba(220,38,38,0.1)', border: '1px solid rgba(220,38,38,0.35)', color: '#DC2626', fontSize: 14 }}>{error}</div>}

      {!created && (
        <div style={{ borderRadius: 14, padding: 20, background: '#FFFFFF', border: '1px solid #E2E8F0' }}>
          <div style={{ marginBottom: 6, fontWeight: 700, fontSize: 14 }}>نوع المزود:</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
            {ROLES.map(r => (
              <button key={r.key} type="button" onClick={() => setForm({ ...form, role: r.key })} style={{
                padding: '6px 14px', borderRadius: 18, fontSize: 13, cursor: 'pointer',
                border: form.role === r.key ? '1px solid #19C3D6' : '1px solid #CBD5E1',
                background: form.role === r.key ? 'rgba(25,195,214,0.15)' : '#F8FAFC',
                color: form.role === r.key ? '#19C3D6' : '#64748B',
              }}>{r.ar}</button>
            ))}
          </div>
          <input style={inputStyle} placeholder="الاسم الكامل / اسم المنشأة *" value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} />
          <input style={inputStyle} placeholder="البريد الإلكتروني (الجوال أو البريد مطلوب)" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          <input style={inputStyle} placeholder="رقم الجوال" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
          <input style={inputStyle} placeholder="كلمة مرور (اتركها فارغة لتوليد واحدة تلقائيًا)" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          <input style={inputStyle} placeholder="التخصص (اختياري)" value={form.specialty} onChange={e => setForm({ ...form, specialty: e.target.value })} />
          <input style={inputStyle} placeholder="رقم الترخيص (اختياري)" value={form.license_number} onChange={e => setForm({ ...form, license_number: e.target.value })} />
          <input style={inputStyle} placeholder="المدينة (اختياري)" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} />
          <button
            onClick={create}
            disabled={busy || !form.full_name.trim() || (!form.email.trim() && !form.phone.trim())}
            style={{ marginTop: 8, padding: '12px 28px', borderRadius: 10, border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg,#19C3D6,#0E8FA3)', color: '#04121a', fontWeight: 800, opacity: busy ? 0.6 : 1 }}
          >
            {busy ? 'جاري الإنشاء...' : 'إنشاء حساب المزود'}
          </button>
        </div>
      )}
    </div>
  );
}
