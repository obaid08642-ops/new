import { useState, useEffect, useCallback } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { apiFetch } from '../../utils/api';

const ROLE_LABELS: Record<string, string> = {
  patient: 'مريض', doctor: 'طبيب', pharmacy: 'صيدلية', hospital: 'مستشفى',
  lab: 'مختبر', radiology: 'أشعة', nursing: 'تمريض', home_care: 'رعاية منزلية',
  ambulance: 'إسعاف', physiotherapist: 'علاج طبيعي', admin: 'أدمن',
  super_admin: 'أدمن رئيسي', delivery: 'توصيل', guest: 'زائر',
};
const ROLE_FILTERS = [
  { key: '', label: 'الكل' },
  { key: 'patient', label: 'المرضى' },
  { key: 'doctor', label: 'الأطباء' },
  { key: 'pharmacy', label: 'الصيدليات' },
  { key: 'hospital', label: 'المستشفيات' },
  { key: 'nursing', label: 'التمريض' },
  { key: 'lab', label: 'المعامل' },
  { key: 'radiology', label: 'الأشعة' },
  { key: 'ambulance', label: 'الإسعاف' },
  { key: 'home_care', label: 'الرعاية المنزلية' },
];
const SORTS = [
  { key: 'newest', label: 'الأحدث تسجيلًا' },
  { key: 'activity', label: 'الأكثر نشاطًا (آخر دخول)' },
  { key: 'oldest', label: 'الأقدم تسجيلًا' },
  { key: 'name', label: 'الاسم أبجديًا' },
];

export default function UsersManagementPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [stats, setStats] = useState<Record<string, number>>({});
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [role, setRole] = useState('');
  const [sort, setSort] = useState('newest');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams({ page: String(page), limit: '25', sort });
      if (role) qs.set('role', role);
      if (searchTerm.trim()) qs.set('q', searchTerm.trim());
      const res = await apiFetch(`/admin/users?${qs.toString()}`);
      setUsers(res?.data || []);
      setTotal(res?.total || 0);
      setPages(res?.pages || 1);
    } catch (err: any) {
      setError('تعذر تحميل المستخدمين من الخادم');
      setUsers([]);
    } finally {
      setLoading(false);
    }
  }, [page, role, sort, searchTerm]);

  const fetchStats = useCallback(async () => {
    try {
      const res = await apiFetch('/admin/users/stats');
      setStats(res?.byRole || {});
    } catch {}
  }, []);

  useEffect(() => { fetchStats(); }, [fetchStats]);
  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const setBan = async (u: any, ban: boolean) => {
    const id = u.id || u._id;
    if (!confirm(ban ? `تأكيد إيقاف/حظر «${u.full_name || u.phone}»؟` : `تأكيد فك الحظر عن «${u.full_name || u.phone}»؟`)) return;
    setBusyId(id);
    try {
      await apiFetch(`/admin/users/${id}/${ban ? 'ban' : 'unban'}`, { method: 'POST' });
      setToast(ban ? 'تم حظر المستخدم — لن يتمكن من تسجيل الدخول.' : 'تم فك الحظر عن المستخدم.');
      await fetchUsers();
    } catch (err: any) {
      setToast(`فشل الإجراء: ${err?.message || 'خطأ غير معروف'}`);
    } finally {
      setBusyId(null);
      setTimeout(() => setToast(null), 4000);
    }
  };

  const isBanned = (u: any) => u.active === false || u.suspended === true;

  return (
    <div dir="rtl" className="p-8" style={{ color: '#0F172A' }}>
      <Head><title>إدارة المستخدمين</title></Head>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-3">
        <h1 className="text-2xl font-bold">إدارة المستخدمين ({total})</h1>
        <input
          type="text"
          placeholder="بحث بالاسم أو الجوال أو البريد..."
          value={searchTerm}
          onChange={e => { setSearchTerm(e.target.value); setPage(1); }}
          className="border border-gray-600 rounded px-4 py-2 w-72 bg-transparent"
        />
      </div>

      {/* Role filter chips with real counts */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
        {ROLE_FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => { setRole(f.key); setPage(1); }}
            style={{
              padding: '6px 14px', borderRadius: 20, fontSize: 13, cursor: 'pointer',
              border: role === f.key ? '1px solid #19C3D6' : '1px solid #CBD5E1',
              background: role === f.key ? 'rgba(25,195,214,0.15)' : '#F8FAFC',
              color: role === f.key ? '#19C3D6' : '#64748B',
            }}
          >
            {f.label}{f.key && stats[f.key] != null ? ` (${stats[f.key]})` : ''}
          </button>
        ))}
        <select
          value={sort}
          onChange={e => { setSort(e.target.value); setPage(1); }}
          style={{ marginInlineStart: 'auto', padding: '6px 12px', borderRadius: 10, background: '#FFFFFF', color: '#0F172A', border: '1px solid #CBD5E1' }}
        >
          {SORTS.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
        </select>
      </div>

      {toast && (
        <div style={{ marginBottom: 12, padding: 10, borderRadius: 10, background: 'rgba(25,195,214,0.1)', border: '1px solid rgba(25,195,214,0.35)', color: '#19C3D6', fontSize: 14 }}>
          {toast}
        </div>
      )}

      {loading ? (
        <div className="p-8 text-center" style={{ color: '#64748B' }}>جاري التحميل...</div>
      ) : error ? (
        <div className="p-8 text-center" style={{ color: '#DC2626' }}>{error}</div>
      ) : (
        <div style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #E2E8F0' }}>
          <table className="min-w-full">
            <thead style={{ background: '#F1F5F9' }}>
              <tr>
                {['الاسم', 'التواصل', 'الدور', 'الحالة', 'آخر نشاط', 'الإجراءات'].map(h => (
                  <th key={h} className="px-6 py-3 text-right text-xs font-medium" style={{ color: '#64748B' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id || u._id} style={{ borderTop: '1px solid #F1F5F9' }}>
                  <td className="px-6 py-4 whitespace-nowrap font-medium">
                    <Link href={`/admin/users/${u.id || u._id}`} style={{ color: '#0F172A', textDecoration: 'none', borderBottom: '1px dashed rgba(25,195,214,0.5)' }}>
                      {u.full_name || 'مستخدم'}
                    </Link>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap" style={{ color: '#64748B', fontSize: 13 }}>
                    {u.phone || ''}{u.phone && u.email ? ' · ' : ''}{u.email || ''}{!u.phone && !u.email ? '-' : ''}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap" style={{ color: '#64748B' }}>{ROLE_LABELS[u.role] || u.role || 'مريض'}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span style={{
                      padding: '2px 10px', borderRadius: 12, fontSize: 12, fontWeight: 700,
                      background: isBanned(u) ? 'rgba(220,38,38,0.15)' : 'rgba(22,163,74,0.12)',
                      color: isBanned(u) ? '#DC2626' : '#16A34A',
                    }}>
                      {isBanned(u) ? 'محظور / موقوف' : 'نشط'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap" style={{ color: '#64748B', fontSize: 12 }}>
                    {u.last_login_at ? new Date(u.last_login_at).toLocaleString('ar-SA') : 'لم يسجل دخول'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    {['admin', 'super_admin'].includes(u.role) ? (
                      <span style={{ color: '#94A3B8', fontSize: 12 }}>—</span>
                    ) : isBanned(u) ? (
                      <button
                        disabled={busyId === (u.id || u._id)}
                        onClick={() => setBan(u, false)}
                        style={{ color: '#16A34A', fontWeight: 700, cursor: 'pointer', background: 'none', border: 'none' }}
                      >
                        فك الحظر
                      </button>
                    ) : (
                      <button
                        disabled={busyId === (u.id || u._id)}
                        onClick={() => setBan(u, true)}
                        style={{ color: '#DC2626', fontWeight: 700, cursor: 'pointer', background: 'none', border: 'none' }}
                      >
                        حظر / إيقاف
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr><td colSpan={6} className="px-6 py-8 text-center" style={{ color: '#64748B' }}>لا يوجد مستخدمون مطابقون.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {pages > 1 && (
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 16 }}>
          <button disabled={page <= 1} onClick={() => setPage(p => p - 1)} style={{ padding: '6px 16px', borderRadius: 8, background: '#F1F5F9', color: '#0F172A', border: 'none', cursor: 'pointer' }}>السابق</button>
          <span style={{ alignSelf: 'center', color: '#64748B', fontSize: 13 }}>صفحة {page} من {pages}</span>
          <button disabled={page >= pages} onClick={() => setPage(p => p + 1)} style={{ padding: '6px 16px', borderRadius: 8, background: '#F1F5F9', color: '#0F172A', border: 'none', cursor: 'pointer' }}>التالي</button>
        </div>
      )}
    </div>
  );
}
