import { useEffect, useState } from 'react';
import { apiFetch } from '../../utils/api';

const STATUS_LABELS: Record<string, { ar: string; cls: string }> = {
  PENDING_ADMIN_REVIEW: { ar: 'بانتظار مراجعة الأدمن', cls: 'bg-amber-100 text-amber-700' },
  QUOTATION_ISSUED: { ar: 'تم إصدار عرض السعر', cls: 'bg-blue-100 text-blue-700' },
  APPROVED_BY_PHARMACY: { ar: 'وافقت الصيدلية', cls: 'bg-emerald-100 text-emerald-700' },
  CANCELLED: { ar: 'ملغي', cls: 'bg-red-100 text-red-600' },
  COMPLETED: { ar: 'مكتمل', cls: 'bg-slate-200 text-slate-700' },
  DRAFT: { ar: 'مسودة', cls: 'bg-slate-100 text-slate-500' },
};

export default function ProcurementPage() {
  const [requests, setRequests] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [filter, setFilter] = useState('');
  const [selected, setSelected] = useState<any | null>(null);
  const [prices, setPrices] = useState<Record<number, string>>({});
  const [quoteNotes, setQuoteNotes] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [list, sum] = await Promise.all([
        apiFetch(`/admin/procurement${filter ? `?status=${filter}` : ''}`),
        apiFetch('/admin/procurement/summary'),
      ]);
      setRequests(Array.isArray(list) ? list : list.data || []);
      setSummary(sum);
    } catch (e: any) { setMsg(e.message); } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [filter]);

  const open = async (id: string) => {
    try { setSelected(await apiFetch(`/admin/procurement/${id}`)); } catch (e: any) { setMsg(e.message); }
  };

  const quoteItems = () => (selected?.items || []).map((it: any, i: number) => ({
    medicineId: it.medicine_id ? String(it.medicine_id) : (it.raw_name_string || `item-${i}`),
    quantity: Number(it.requested_quantity ?? it.quantity ?? 1),
    price: Number(prices[i] || 0),
  }));
  const quoteTotal = () => quoteItems().reduce((a: number, it: any) => a + it.quantity * it.price, 0);

  const issueQuote = async () => {
    if (!selected) return;
    try {
      await apiFetch(`/admin/procurement/${selected._id}/quotation`, {
        method: 'POST',
        body: JSON.stringify({ items: quoteItems(), totalPrice: quoteTotal(), adminNotes: quoteNotes || undefined }),
      });
      setMsg('تم إصدار عرض السعر وإرساله للصيدلية');
      setSelected(null); setPrices({}); setQuoteNotes(''); load();
    } catch (e: any) { setMsg(e.message); }
  };

  const setStatus = async (id: string, action: 'cancel' | 'complete') => {
    try {
      await apiFetch(`/admin/procurement/${id}/${action}`, { method: 'PATCH' });
      setMsg(action === 'cancel' ? 'تم إلغاء الطلب' : 'تم إنهاء الطلب'); setSelected(null); load();
    } catch (e: any) { setMsg(e.message); }
  };

  const exportCsv = async (id: string) => {
    const token = localStorage.getItem('admin_token');
    const base = process.env.NEXT_PUBLIC_API_URL || '';
    const res = await fetch(`${base}/api/v1/admin/procurement/${id}/export`, { headers: { Authorization: `Bearer ${token}` } });
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `procurement-${id}.csv`;
    a.click();
  };

  const groups = (items: any[]) => ({
    medical: (items || []).filter(i => i.category_group !== 'non_medical'),
    non_medical: (items || []).filter(i => i.category_group === 'non_medical'),
  });

  return (
    <div dir="rtl" className="p-6 space-y-4">
      <h1 className="text-2xl font-bold text-slate-900">طلبات المستودعات (عروض الأسعار)</h1>
      <p className="text-sm text-slate-500">طلبات النواقص الواردة من الصيدليات — الملفات والصور المحلّلة بالذكاء الاصطناعي، الأصناف المصنفة (أدوية / غير دوائية)، إصدار عرض السعر، والتصدير إلى Excel.</p>

      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {Object.entries(STATUS_LABELS).map(([k, v]) => (
            <button key={k} onClick={() => setFilter(filter === k ? '' : k)} className={`rounded-xl border p-3 text-center transition ${filter === k ? 'border-teal-500 ring-2 ring-teal-200' : 'border-slate-200'} bg-white`}>
              <div className="text-2xl font-bold text-slate-900">{summary.by_status?.[k] || 0}</div>
              <div className="text-xs text-slate-500">{v.ar}</div>
            </button>
          ))}
        </div>
      )}
      {msg && <div className="bg-teal-50 border border-teal-200 text-teal-800 rounded-lg px-4 py-2 text-sm">{msg}</div>}
      {loading && <div className="text-slate-500 text-sm">جارٍ التحميل…</div>}

      {!selected && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr><th className="p-3 text-right">الصيدلية</th><th className="p-3">الأصناف</th><th className="p-3">ملف مرفق</th><th className="p-3">الحالة</th><th className="p-3">التاريخ</th><th className="p-3"></th></tr>
            </thead>
            <tbody>
              {requests.map(r => (
                <tr key={r._id} className="border-t hover:bg-slate-50">
                  <td className="p-3 font-medium text-slate-900">{r.pharmacy_name || String(r.pharmacy_id).slice(-8)}</td>
                  <td className="p-3 text-center">{(r.items || []).length}</td>
                  <td className="p-3 text-center">{r.uploaded_file_url ? '📎' : '—'}</td>
                  <td className="p-3 text-center"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${STATUS_LABELS[r.status]?.cls || ''}`}>{STATUS_LABELS[r.status]?.ar || r.status}</span></td>
                  <td className="p-3 text-center text-slate-500">{r.createdAt ? new Date(r.createdAt).toLocaleString('ar') : ''}</td>
                  <td className="p-3 text-center"><button onClick={() => open(r._id)} className="px-3 py-1 rounded-lg bg-teal-600 text-white text-xs font-semibold">فتح</button></td>
                </tr>
              ))}
              {requests.length === 0 && !loading && <tr><td colSpan={6} className="p-8 text-center text-slate-500">لا توجد طلبات — عندما ترفع صيدلية قائمة نواقص (أو صورة يحللها الذكاء الاصطناعي) ستظهر هنا فوراً.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {selected && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <button onClick={() => setSelected(null)} className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-600 text-sm">← رجوع</button>
            <h2 className="text-lg font-bold text-slate-900">طلب #{String(selected._id).slice(-8)}</h2>
            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${STATUS_LABELS[selected.status]?.cls}`}>{STATUS_LABELS[selected.status]?.ar}</span>
            <button onClick={() => exportCsv(selected._id)} className="mr-auto px-4 py-1.5 rounded-lg bg-slate-800 text-white text-sm font-semibold">⬇ تصدير Excel (CSV)</button>
          </div>

          {selected.uploaded_file_url && (
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-sm font-semibold text-slate-700 mb-2">الملف / الصورة المرفقة من الصيدلية:</div>
              {/\.(png|jpe?g|webp)$/i.test(selected.uploaded_file_url)
                ? <img src={selected.uploaded_file_url} alt="مرفق الطلب" className="max-h-80 rounded-lg border border-slate-200" />
                : <a href={selected.uploaded_file_url} target="_blank" className="text-teal-600 underline text-sm">فتح الملف المرفق</a>}
            </div>
          )}

          {(['medical', 'non_medical'] as const).map(g => {
            const items = groups(selected.items)[g];
            if (items.length === 0) return null;
            return (
              <div key={g} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-2.5 bg-slate-50 font-bold text-slate-800 text-sm">{g === 'medical' ? `💊 أدوية (${items.length})` : `🧴 غير دوائية (${items.length})`}</div>
                <table className="w-full text-sm">
                  <thead className="text-slate-500 text-xs"><tr><th className="p-2 text-right">الصنف</th><th className="p-2">مطابق للكتالوج</th><th className="p-2">الكمية</th><th className="p-2 text-right">ملاحظات</th></tr></thead>
                  <tbody>
                    {items.map((it: any, i: number) => (
                      <tr key={i} className="border-t">
                        <td className="p-2 text-slate-900">{it.medicine_name || it.raw_name_string}</td>
                        <td className="p-2 text-center">{it.medicine_id ? <span className="text-emerald-600 font-semibold">✓ {it.medicine_name || ''}</span> : <span className="text-amber-600">غير مطابق — يدوي</span>}</td>
                        <td className="p-2 text-center font-semibold">{it.requested_quantity ?? it.quantity}</td>
                        <td className="p-2 text-slate-500">{it.notes || ''}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })}

          {selected.status === 'PENDING_ADMIN_REVIEW' && (
            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="font-bold text-slate-800 text-sm">إصدار عرض سعر — سعر الوحدة لكل صنف:</div>
              <div className="space-y-2">
                {(selected.items || []).map((it: any, i: number) => (
                  <div key={i} className="flex items-center gap-3 text-sm">
                    <span className="flex-1 text-slate-900">{it.medicine_name || it.raw_name_string} <span className="text-slate-400">× {it.requested_quantity ?? it.quantity ?? 1}</span></span>
                    <input
                      type="number" min="0" step="0.01" value={prices[i] || ''}
                      onChange={e => setPrices({ ...prices, [i]: e.target.value })}
                      placeholder="سعر الوحدة"
                      className="border border-slate-300 rounded-lg px-3 py-1.5 w-32 bg-white text-slate-900"
                    />
                    <span className="text-slate-500 w-24 text-left">{((Number(prices[i]) || 0) * Number(it.requested_quantity ?? it.quantity ?? 1)).toFixed(2)} ر.س</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-3 flex-wrap items-center border-t border-slate-100 pt-3">
                <span className="font-bold text-slate-900">الإجمالي: {quoteTotal().toFixed(2)} ر.س</span>
                <input value={quoteNotes} onChange={e => setQuoteNotes(e.target.value)} placeholder="ملاحظات للصيدلية (اختياري)" className="border border-slate-300 rounded-lg px-3 py-2 text-sm flex-1 bg-white text-slate-900" />
                <button onClick={issueQuote} disabled={quoteTotal() <= 0} className="px-5 py-2 rounded-lg bg-emerald-600 text-white text-sm font-bold disabled:opacity-40">إرسال عرض السعر</button>
                <button onClick={() => setStatus(selected._id, 'cancel')} className="px-4 py-2 rounded-lg bg-white border border-red-300 text-red-600 text-sm font-semibold">إلغاء الطلب</button>
              </div>
            </div>
          )}
          {selected.status === 'APPROVED_BY_PHARMACY' && (
            <button onClick={() => setStatus(selected._id, 'complete')} className="px-5 py-2 rounded-lg bg-slate-800 text-white text-sm font-bold">تأكيد التوريد وإنهاء الطلب</button>
          )}
        </div>
      )}
    </div>
  );
}
