import { useEffect, useState, useCallback } from 'react';
import Head from 'next/head';
import { apiFetch } from '../../utils/api';

const STATUS_LABELS: Record<string, { ar: string; color: string }> = {
  pending:  { ar: 'قيد المراجعة', color: '#B45309' },
  approved: { ar: 'معتمدة',      color: '#16A34A' },
  rejected: { ar: 'مرفوضة',      color: '#DC2626' },
};
const TYPE_LABELS: Record<string, string> = { BLS: 'إسعاف أساسي (BLS)', ALS: 'إسعاف متقدم (ALS)', ICU: 'عناية مركزة متنقلة (ICU)' };

export default function AmbulanceFleetPage() {
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch(`/admin/ambulance/fleet${status ? `?status=${status}` : ''}`);
      setVehicles(Array.isArray(res) ? res : res?.data || []);
    } catch (e: any) {
      setError('تعذر تحميل أساطيل الإسعاف من الخادم');
      setVehicles([]);
    } finally {
      setLoading(false);
    }
  }, [status]);

  useEffect(() => { load(); }, [load]);

  const review = async (v: any, approve: boolean) => {
    let reason: string | undefined;
    if (!approve) {
      reason = prompt(`سبب رفض المركبة «${v.plate_number}» (سيظهر للمزود):`) || undefined;
      if (reason === undefined) return;
    } else if (!confirm(`اعتماد المركبة «${v.plate_number}»؟ ستصبح متاحة لطلبات الإسعاف.`)) {
      return;
    }
    setBusyId(v.id);
    try {
      await apiFetch(`/admin/ambulance/fleet/${v.id}/${approve ? 'approve' : 'reject'}`, {
        method: 'POST',
        body: JSON.stringify(approve ? {} : { reason }),
      });
      setToast(approve ? 'تم اعتماد المركبة.' : 'تم رفض المركبة وإشعار المزود.');
      await load();
    } catch (e: any) {
      setToast(`فشل الإجراء: ${e?.message || ''}`);
    } finally {
      setBusyId(null);
      setTimeout(() => setToast(null), 4000);
    }
  };

  return (
    <div dir="rtl" className="p-8" style={{ color: '#0F172A' }}>
      <Head><title>أساطيل الإسعاف</title></Head>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-3">
        <h1 className="text-2xl font-bold">أساطيل الإسعاف ({vehicles.length})</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          {[{ k: '', l: 'الكل' }, { k: 'pending', l: 'قيد المراجعة' }, { k: 'approved', l: 'المعتمدة' }, { k: 'rejected', l: 'المرفوضة' }].map(f => (
            <button key={f.k} onClick={() => setStatus(f.k)} style={{
              padding: '6px 14px', borderRadius: 20, fontSize: 13, cursor: 'pointer',
              border: status === f.k ? '1px solid #19C3D6' : '1px solid #CBD5E1',
              background: status === f.k ? 'rgba(25,195,214,0.15)' : '#F8FAFC',
              color: status === f.k ? '#19C3D6' : '#64748B',
            }}>{f.l}</button>
          ))}
        </div>
      </div>

      {toast && <div style={{ marginBottom: 12, padding: 10, borderRadius: 10, background: 'rgba(25,195,214,0.1)', border: '1px solid rgba(25,195,214,0.35)', color: '#19C3D6', fontSize: 14 }}>{toast}</div>}

      {loading ? (
        <div className="p-8 text-center" style={{ color: '#64748B' }}>جاري التحميل...</div>
      ) : error ? (
        <div className="p-8 text-center" style={{ color: '#DC2626' }}>{error}</div>
      ) : vehicles.length === 0 ? (
        <div className="p-8 text-center" style={{ color: '#64748B' }}>لا توجد مركبات مسجلة{status ? ' بهذه الحالة' : ''} — تُسجَّل المركبات من تطبيق مزود خدمة الإسعاف ثم تظهر هنا للمراجعة.</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: 14 }}>
          {vehicles.map(v => {
            const st = STATUS_LABELS[v.status] || { ar: v.status, color: '#64748B' };
            return (
              <div key={v.id} style={{ borderRadius: 14, padding: 18, background: '#FFFFFF', border: '1px solid #E2E8F0' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <b style={{ fontSize: 17 }}>{v.plate_number}</b>
                  <span style={{ padding: '2px 12px', borderRadius: 12, fontSize: 12, fontWeight: 700, color: st.color, background: `${st.color}22` }}>{st.ar}</span>
                </div>
                <div style={{ color: '#64748B', fontSize: 13, lineHeight: 2 }}>
                  <div>النوع: {TYPE_LABELS[v.vehicle_type] || v.vehicle_type || '-'}{v.has_icu ? ' · عناية مركزة' : ''}</div>
                  <div>الموديل: {v.model || '-'} {v.year ? `(${v.year})` : ''} · المدينة: {v.base_city || '-'}</div>
                  <div>المسعفون: {v.paramedic_count ?? '-'} · التجهيزات: {(v.equipment || []).length ? v.equipment.join('، ') : '-'}</div>
                  <div>المزود: {v.provider_account_id}</div>
                  {v.admin_notes ? <div style={{ color: "#DC2626" }}>سبب الرفض: {v.admin_notes}</div> : null}
                </div>
                {v.status === 'pending' && (
                  <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
                    <button disabled={busyId === v.id} onClick={() => review(v, true)} style={{ flex: 1, padding: '9px 0', borderRadius: 9, border: 'none', cursor: 'pointer', background: 'rgba(22,163,74,0.15)', color: '#16A34A', fontWeight: 700 }}>اعتماد</button>
                    <button disabled={busyId === v.id} onClick={() => review(v, false)} style={{ flex: 1, padding: '9px 0', borderRadius: 9, border: 'none', cursor: 'pointer', background: 'rgba(220,38,38,0.12)', color: '#DC2626', fontWeight: 700 }}>رفض</button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
