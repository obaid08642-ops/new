import { useEffect, useState, useCallback } from 'react';
import Head from 'next/head';
import { apiFetch } from '../../utils/api';

/** Permission catalog — grouped, Arabic labels. Keys are stored on the user. */
const PERMISSION_GROUPS: { group: string; perms: { key: string; ar: string }[] }[] = [
  { group: 'المستخدمون', perms: [
    { key: 'users.read', ar: 'عرض المستخدمين' }, { key: 'users.manage', ar: 'حظر/فك حظر المستخدمين' },
  ]},
  { group: 'المزودون', perms: [
    { key: 'providers.read', ar: 'عرض المزودين' }, { key: 'providers.approve', ar: 'اعتماد/رفض المزودين' },
    { key: 'providers.create', ar: 'إنشاء حسابات مزودين' },
  ]},
  { group: 'المالية', perms: [
    { key: 'finance.read', ar: 'عرض المالية' }, { key: 'finance.payouts', ar: 'تنفيذ اعتمادات السحب' },
    { key: 'finance.refunds', ar: 'اعتماد المستردات للمرضى' },
  ]},
  { group: 'الطوارئ', perms: [
    { key: 'sos.read', ar: 'مراقبة الطوارئ' }, { key: 'ambulance.review', ar: 'اعتماد مركبات الإسعاف' },
  ]},
  { group: 'النظام', perms: [
    { key: 'config.manage', ar: 'إعدادات المنصة' }, { key: 'audit.read', ar: 'سجل التدقيق' },
    { key: 'notifications.send', ar: 'إرسال الإشعارات' },
  ]},
];

export default function SubAdminsPage() {
  const [admins, setAdmins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ full_name: '', email: '', phone: '', password: '' });
  const [perms, setPerms] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState<{ email: string; password: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch('/admin/sub-admins');
      setAdmins(Array.isArray(res) ? res : []);
      setError(null);
    } catch (e: any) {
      setError(e?.message?.includes('403') || e?.message?.includes('Forbidden') ? 'هذه الصفحة متاحة لحساب المالك فقط' : 'تعذر تحميل القائمة');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const togglePerm = (k: string) => {
    const next = new Set(perms);
    next.has(k) ? next.delete(k) : next.add(k);
    setPerms(next);
  };

  const create = async () => {
    setBusy(true);
    setToast(null);
    try {
      const res = await apiFetch('/admin/sub-admins', {
        method: 'POST',
        body: JSON.stringify({
          full_name: form.full_name.trim(),
          email: form.email.trim(),
          phone: form.phone.trim() || undefined,
          password: form.password || undefined,
          permissions: [...perms],
        }),
      });
      if (res?.initial_password) {
        setCreated({ email: res.email, password: res.initial_password });
      } else {
        setCreated({ email: res.email, password: '(كلمة المرور التي أدخلتها)' });
      }
      setShowForm(false);
      setForm({ full_name: '', email: '', phone: '', password: '' });
      setPerms(new Set());
      await load();
    } catch (e: any) {
      setToast(`فشل الإنشاء: ${e?.message || ''}`);
    } finally {
      setBusy(false);
    }
  };

  const toggleActive = async (a: any) => {
    try {
      await apiFetch(`/admin/sub-admins/${a.id}`, { method: 'PATCH', body: JSON.stringify({ active: !a.active }) });
      setToast(a.active ? 'تم تعطيل الحساب.' : 'تم تفعيل الحساب.');
      await load();
    } catch (e: any) { setToast(`فشل: ${e?.message || ''}`); }
    setTimeout(() => setToast(null), 4000);
  };

  const remove = async (a: any) => {
    if (!confirm(`حذف حساب الأدمن «${a.full_name || a.email}» نهائيًا؟`)) return;
    try {
      await apiFetch(`/admin/sub-admins/${a.id}`, { method: 'DELETE' });
      setToast('تم حذف الحساب.');
      await load();
    } catch (e: any) { setToast(`فشل الحذف: ${e?.message || ''}`); }
    setTimeout(() => setToast(null), 4000);
  };

  const inputStyle: any = {
    width: '100%', padding: '11px 14px', borderRadius: 10, marginBottom: 10,
    border: '1px solid #CBD5E1', background: '#FFFFFF',
    color: '#0F172A', fontSize: 14, outline: 'none', boxSizing: 'border-box',
  };

  return (
    <div dir="rtl" className="p-8" style={{ color: '#0F172A', maxWidth: 900 }}>
      <Head><title>حسابات الأدمن الفرعية</title></Head>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h1 className="text-2xl font-bold">حسابات الأدمن الفرعية (Sub-Admins)</h1>
        <button onClick={() => setShowForm(s => !s)} style={{ padding: '10px 20px', borderRadius: 10, border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg,#19C3D6,#0E8FA3)', color: '#04121a', fontWeight: 800 }}>
          {showForm ? 'إلغاء' : '+ إنشاء حساب أدمن'}
        </button>
      </div>

      {toast && <div style={{ marginBottom: 12, padding: 10, borderRadius: 10, background: 'rgba(25,195,214,0.1)', border: '1px solid rgba(25,195,214,0.35)', color: '#19C3D6', fontSize: 14 }}>{toast}</div>}

      {created && (
        <div style={{ marginBottom: 16, padding: 16, borderRadius: 12, background: 'rgba(22,163,74,0.08)', border: '1px solid rgba(22,163,74,0.35)' }}>
          <b style={{ color: '#16A34A' }}>تم إنشاء الحساب بنجاح.</b>
          <div style={{ marginTop: 8, fontSize: 14, color: '#64748B' }}>
            البريد: <code style={{ color: '#0F172A' }}>{created.email}</code><br />
            كلمة المرور الأولية: <code style={{ color: '#B45309', fontSize: 16 }}>{created.password}</code><br />
            <span style={{ fontSize: 12 }}>انسخها الآن وسلّمها للأدمن — تظهر مرة واحدة فقط.</span>
          </div>
          <button onClick={() => setCreated(null)} style={{ marginTop: 10, padding: '6px 16px', borderRadius: 8, border: 'none', background: '#E2E8F0', color: '#0F172A', cursor: 'pointer' }}>تم النسخ، إخفاء</button>
        </div>
      )}

      {showForm && (
        <div style={{ borderRadius: 14, padding: 20, marginBottom: 20, background: '#FFFFFF', border: '1px solid #E2E8F0' }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>أدمن فرعي جديد</h2>
          <input style={inputStyle} placeholder="الاسم الكامل" value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} />
          <input style={inputStyle} placeholder="البريد الإلكتروني" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          <input style={inputStyle} placeholder="رقم الجوال (اختياري)" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
          <input style={inputStyle} placeholder="كلمة مرور (اتركها فارغة لتوليد واحدة تلقائيًا)" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          <div style={{ margin: '10px 0 6px', fontWeight: 700, fontSize: 14 }}>الصلاحيات المخصصة:</div>
          {PERMISSION_GROUPS.map(g => (
            <div key={g.group} style={{ marginBottom: 10 }}>
              <div style={{ color: '#19C3D6', fontSize: 13, marginBottom: 6 }}>{g.group}</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {g.perms.map(p => (
                  <button key={p.key} type="button" onClick={() => togglePerm(p.key)} style={{
                    padding: '5px 12px', borderRadius: 16, fontSize: 12, cursor: 'pointer',
                    border: perms.has(p.key) ? '1px solid #16A34A' : '1px solid #CBD5E1',
                    background: perms.has(p.key) ? 'rgba(22,163,74,0.12)' : '#F8FAFC',
                    color: perms.has(p.key) ? '#16A34A' : '#64748B',
                  }}>{p.ar}</button>
                ))}
              </div>
            </div>
          ))}
          <button onClick={create} disabled={busy || !form.full_name.trim() || !form.email.trim()} style={{ marginTop: 10, padding: '11px 26px', borderRadius: 10, border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg,#19C3D6,#0E8FA3)', color: '#04121a', fontWeight: 800, opacity: busy ? 0.6 : 1 }}>
            {busy ? 'جاري الإنشاء...' : 'إنشاء الحساب'}
          </button>
        </div>
      )}

      {loading ? (
        <div className="p-8 text-center" style={{ color: '#64748B' }}>جاري التحميل...</div>
      ) : error ? (
        <div className="p-8 text-center" style={{ color: '#DC2626' }}>{error}</div>
      ) : (
        <div style={{ display: 'grid', gap: 12 }}>
          {admins.map(a => (
            <div key={a.id} style={{ borderRadius: 14, padding: 16, background: '#FFFFFF', border: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
              <div>
                <b>{a.full_name || '—'}</b> {a.is_owner && <span style={{ color: '#B45309', fontSize: 12, marginInlineStart: 8 }}>المالك الرئيسي</span>}
                <div style={{ color: '#64748B', fontSize: 13, marginTop: 4 }}>{a.email}{a.phone ? ` · ${a.phone}` : ''}</div>
                <div style={{ color: '#94A3B8', fontSize: 12, marginTop: 4 }}>
                  {a.permissions?.length ? `الصلاحيات: ${a.permissions.join('، ')}` : a.is_owner ? 'كل الصلاحيات' : 'بدون صلاحيات مخصصة'}
                </div>
              </div>
              {!a.is_owner && (
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => toggleActive(a)} style={{ padding: '7px 16px', borderRadius: 9, border: 'none', cursor: 'pointer', background: a.active ? 'rgba(180,83,9,0.12)' : 'rgba(22,163,74,0.12)', color: a.active ? '#B45309' : '#16A34A', fontWeight: 700 }}>
                    {a.active ? 'تعطيل' : 'تفعيل'}
                  </button>
                  <button onClick={() => remove(a)} style={{ padding: '7px 16px', borderRadius: 9, border: 'none', cursor: 'pointer', background: 'rgba(220,38,38,0.12)', color: '#DC2626', fontWeight: 700 }}>حذف</button>
                </div>
              )}
            </div>
          ))}
          {admins.length === 0 && <div className="p-8 text-center" style={{ color: '#64748B' }}>لا توجد حسابات أدمن فرعية بعد.</div>}
        </div>
      )}
    </div>
  );
}
