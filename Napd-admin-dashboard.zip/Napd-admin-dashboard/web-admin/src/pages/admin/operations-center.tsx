import { useEffect, useState } from 'react';
import { apiFetch } from '../../utils/api';

const KIND_LABELS: Record<string, string> = {
  orders: 'طلبات الصيدلية', appointments: 'المواعيد', emergency: 'الطوارئ SOS', procurement: 'المستودعات',
};
const NORM: Record<string, { ar: string; cls: string }> = {
  done: { ar: 'تم', cls: 'bg-emerald-100 text-emerald-700' },
  pending: { ar: 'ينتظر', cls: 'bg-amber-100 text-amber-700' },
  late: { ar: 'متأخر', cls: 'bg-orange-100 text-orange-700' },
  failed: { ar: 'مشكلة / ملغي', cls: 'bg-red-100 text-red-600' },
};

const Stat = ({ label, value, sub, cls }: any) => (
  <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
    <div className="text-xs text-slate-500">{label}</div>
    <div className={`text-2xl font-bold mt-1 ${cls || 'text-slate-900'}`}>{value}</div>
    {sub && <div className="text-[11px] text-slate-400 mt-0.5">{sub}</div>}
  </div>
);

export default function OperationsCenterPage() {
  const [ov, setOv] = useState<any>(null);
  const [feed, setFeed] = useState<any>(null);
  const [kind, setKind] = useState('');
  const [error, setError] = useState('');

  const load = async () => {
    try {
      const [o, f] = await Promise.all([
        apiFetch('/admin/ops/overview'),
        apiFetch(`/admin/ops/requests?limit=40${kind ? `&kind=${kind}` : ''}`),
      ]);
      setOv(o); setFeed(f);
    } catch (e: any) { setError(e.message); }
  };
  useEffect(() => { load(); const iv = setInterval(load, 30_000); return () => clearInterval(iv); }, [kind]);

  const pipeRow = (label: string, p: any) => p && (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="font-bold text-slate-800 text-sm mb-2">{label}</div>
      <div className="flex gap-4 text-sm flex-wrap">
        <span>اليوم: <b>{p.created_today}</b></span>
        <span className="text-orange-600">متأخر: <b>{p.late}</b></span>
      </div>
      <div className="flex gap-1.5 flex-wrap mt-2">
        {Object.entries(p.by_status || {}).map(([s, n]) => (
          <span key={s} className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[11px]">{s}: <b>{n as number}</b></span>
        ))}
      </div>
    </div>
  );

  return (
    <div dir="rtl" className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">مركز العمليات والمتابعة</h1>
        <span className="text-xs text-slate-400">يتحدث تلقائياً كل 30 ثانية</span>
      </div>
      {error && <div className="bg-red-50 text-red-700 rounded-lg p-3 text-sm">{error}</div>}

      {ov && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Stat label="مستخدمون أونلاين الآن" value={ov.online.users} cls="text-emerald-600" sub={`جلسات أدمن نشطة: ${ov.online.admin_sessions}`} />
            <Stat label="طلبات API اليوم" value={ov.today.total_requests} sub={`نسبة النجاح: ${ov.today.success_rate ?? '—'}%`} />
            <Stat label="نجاح (2xx)" value={ov.today.success} cls="text-emerald-600" />
            <Stat label="فشل (4xx / 5xx)" value={`${ov.today.client_errors} / ${ov.today.server_errors}`} cls={ov.today.server_errors > 0 ? 'text-red-600' : 'text-slate-900'} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pipeRow('طلبات الصيدلية', ov.pipelines.orders)}
            {pipeRow('طلبات صيدليات (orders)', ov.pipelines.pharmacy_orders)}
            {pipeRow('المواعيد', ov.pipelines.appointments)}
            {pipeRow('الطوارئ SOS', ov.pipelines.emergency)}
            {pipeRow('طلبات المستودعات', ov.pipelines.procurement)}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-50 font-bold text-slate-800 text-sm">المسارات الأكثر استخداماً اليوم</div>
              <table className="w-full text-xs">
                <tbody>
                  {ov.top_endpoints.map((t: any) => (
                    <tr key={t.path} className="border-t border-slate-100"><td className="p-2 font-mono text-slate-700" dir="ltr">{t.path}</td><td className="p-2 text-center font-bold text-slate-900 w-16">{t.count}</td></tr>
                  ))}
                  {ov.top_endpoints.length === 0 && <tr><td className="p-4 text-center text-slate-400">تبدأ البيانات بالتراكم من لحظة النشر</td></tr>}
                </tbody>
              </table>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-50 font-bold text-slate-800 text-sm">المسارات الأكثر فشلاً اليوم (للتدخل)</div>
              <table className="w-full text-xs">
                <tbody>
                  {ov.top_failing.map((t: any) => (
                    <tr key={t.path + t.class} className="border-t border-slate-100">
                      <td className="p-2 font-mono text-slate-700" dir="ltr">{t.path}</td>
                      <td className={`p-2 text-center font-bold w-12 ${t.class === '5xx' ? 'text-red-600' : 'text-amber-600'}`}>{t.class}</td>
                      <td className="p-2 text-center font-bold text-slate-900 w-14">{t.count}</td>
                    </tr>
                  ))}
                  {ov.top_failing.length === 0 && <tr><td className="p-4 text-center text-slate-400">لا أعطال مسجلة اليوم</td></tr>}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-2.5 bg-slate-50 font-bold text-slate-800 text-sm">آخر النشاطات — من فعل ماذا</div>
            <table className="w-full text-xs">
              <thead className="text-slate-500"><tr><th className="p-2 text-right">الحدث</th><th className="p-2">الفاعل</th><th className="p-2">الدور</th><th className="p-2">الكيان</th><th className="p-2">الوقت</th></tr></thead>
              <tbody>
                {ov.recent_activity.map((a: any, i: number) => (
                  <tr key={i} className="border-t border-slate-100">
                    <td className="p-2 font-mono text-slate-800" dir="ltr">{a.type}</td>
                    <td className="p-2 text-center text-slate-600">{String(a.actor_account_id || '—').slice(-8)}</td>
                    <td className="p-2 text-center text-slate-600">{a.actor_role || '—'}</td>
                    <td className="p-2 text-center text-slate-600">{a.entity_type || '—'}</td>
                    <td className="p-2 text-center text-slate-400">{a.createdAt ? new Date(a.createdAt).toLocaleString('ar') : ''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {feed && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-lg font-bold text-slate-900 ml-2">تتبع الطلبات الموحد</h2>
            <button onClick={() => setKind('')} className={`px-3 py-1 rounded-full text-xs font-semibold ${kind === '' ? 'bg-slate-800 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>الكل</button>
            {Object.entries(KIND_LABELS).map(([k, v]) => (
              <button key={k} onClick={() => setKind(k)} className={`px-3 py-1 rounded-full text-xs font-semibold ${kind === k ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>{v}</button>
            ))}
            <span className="mr-auto text-xs text-slate-500">
              تم: {feed.counts.done} · ينتظر: {feed.counts.pending} · <span className="text-orange-600 font-bold">متأخر: {feed.counts.late}</span> · <span className="text-red-600 font-bold">مشكلة: {feed.counts.failed}</span>
            </span>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-600 text-xs">
                <tr><th className="p-2 text-right">النوع</th><th className="p-2 text-right">المعرف</th><th className="p-2">الحالة الأصلية</th><th className="p-2">الوضع</th><th className="p-2">المصدر (من طلب)</th><th className="p-2">أُنشئ</th><th className="p-2">آخر تحديث</th></tr>
              </thead>
              <tbody>
                {feed.data.map((r: any) => (
                  <tr key={r.kind + r.id} className={`border-t border-slate-100 ${r.normalized_status === 'late' ? 'bg-orange-50' : r.normalized_status === 'failed' ? 'bg-red-50' : ''}`}>
                    <td className="p-2 font-medium text-slate-800">{r.kind_label}</td>
                    <td className="p-2 font-mono text-xs text-slate-500" dir="ltr">{r.id.slice(-10)}</td>
                    <td className="p-2 text-center text-xs text-slate-600" dir="ltr">{r.status}</td>
                    <td className="p-2 text-center"><span className={`px-2 py-0.5 rounded-full text-xs font-bold ${NORM[r.normalized_status].cls}`}>{NORM[r.normalized_status].ar}</span></td>
                    <td className="p-2 text-center font-mono text-xs text-slate-500" dir="ltr">{r.created_by ? String(r.created_by).slice(-8) : '—'}</td>
                    <td className="p-2 text-center text-xs text-slate-500">{r.created_at ? new Date(r.created_at).toLocaleString('ar') : ''}</td>
                    <td className="p-2 text-center text-xs text-slate-500">{r.updated_at ? new Date(r.updated_at).toLocaleString('ar') : ''}</td>
                  </tr>
                ))}
                {feed.data.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-slate-400">لا توجد طلبات بعد</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
