import React, { useState, useEffect } from 'react';
import { fetchWithAdminGuard } from '@/utils/api';

/**
 * Provider Moderation — fully wired to real endpoints:
 *  • List pending:   GET  /admin/providers?status=pending
 *  • Full detail:    GET  /admin/providers/:id  (account + profile + documents + bank)
 *  • Document view:  GET  /storage/:storageObjectId/signed-url (admin role, 5-min R2 presigned)
 *  • Approve:        POST /admin/providers/:id/approve { commission, note }
 *  • Reject:         POST /admin/providers/:id/reject  { note }
 *  • Deltas:         POST /providers/provider-deltas | /:id/approve | /:id/reject
 * No mock data anywhere — empty states are rendered when collections are empty.
 */

const API = () => process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8002';

// Default commission suggestions by provider type (admin can override freely)
const DEFAULT_COMMISSION: Record<string, number> = {
  pharmacy: 5, lab: 8, radiology: 10, home_care: 15, nurse: 15,
  doctor: 10, clinic: 10, hospital: 10, ambulance: 10,
};

interface AccountRow {
  id: string;
  email: string;
  provider_type: string;
  status: string;
  display_name_ar?: string;
  display_name_en?: string;
  createdAt?: string;
}

interface ProviderDetail {
  account: any;
  profile: any;
  documents: any[];
  bank: any;
}

const DOC_TYPE_AR: Record<string, string> = {
  national_id: 'الهوية الوطنية', commercial_cr: 'السجل التجاري', moh_license: 'ترخيص وزارة الصحة',
  medical_license: 'الترخيص الطبي', scfhs_license: 'ترخيص الهيئة السعودية للتخصصات',
  sfda_license: 'ترخيص الغذاء والدواء', iban_certificate: 'شهادة الآيبان', other: 'مستند آخر',
};

export default function ProviderModeration() {
  const [activeTab, setActiveTab] = useState<'onboarding' | 'deltas'>('onboarding');

  const [pendingProviders, setPendingProviders] = useState<AccountRow[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detail, setDetail] = useState<ProviderDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [docUrls, setDocUrls] = useState<Record<string, string>>({});

  const [pendingDeltas, setPendingDeltas] = useState<any[]>([]);
  const [selectedDelta, setSelectedDelta] = useState<any | null>(null);

  const [commission, setCommission] = useState<string>('');
  const [note, setNote] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [isRejectOpen, setIsRejectOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  const loadList = async () => {
    setIsLoading(true); setError('');
    try {
      const res = await fetchWithAdminGuard(`${API()}/api/v1/admin/providers?status=pending&limit=50`);
      if (res.ok) {
        const data = await res.json();
        setPendingProviders(data.items || data.data || []);
      } else {
        const d = await res.json().catch(() => ({}));
        setError(d?.message || `تعذر تحميل الحسابات المعلقة (${res.status})`);
      }
      const dRes = await fetchWithAdminGuard(`${API()}/api/v1/providers/provider-deltas`, { method: 'POST' });
      if (dRes.ok) setPendingDeltas(await dRes.json());
    } catch (e: any) {
      setError(e?.message || 'تعذر تحميل البيانات');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => { loadList(); }, []);

  // Load full detail (account + profile + documents + bank) when a provider is selected
  useEffect(() => {
    if (!selectedId) { setDetail(null); return; }
    (async () => {
      setDetailLoading(true); setDetail(null); setDocUrls({});
      try {
        const res = await fetchWithAdminGuard(`${API()}/api/v1/admin/providers/${selectedId}`);
        if (res.ok) {
          const d = await res.json();
          setDetail(d);
          // Resolve signed URLs for every uploaded document (admin-only, 5-min)
          const docs = d.documents || [];
          const entries = await Promise.all(docs.map(async (doc: any) => {
            if (!doc.storage_object_id) return [doc.id, ''] as const;
            try {
              const s = await fetchWithAdminGuard(`${API()}/api/v1/storage/${doc.storage_object_id}/signed-url`);
              if (s.ok) { const j = await s.json(); return [doc.id, j.url || ''] as const; }
            } catch { /* keep empty */ }
            return [doc.id, ''] as const;
          }));
          setDocUrls(Object.fromEntries(entries));
        }
      } catch { /* detail stays null, error shown inline */ }
      setDetailLoading(false);
    })();
  }, [selectedId]);

  const handleApprove = async () => {
    if (!selectedId) return;
    const rate = commission.trim() === '' ? NaN : Number(commission);
    if (commission.trim() !== '' && (isNaN(rate) || rate < 0 || rate > 100)) {
      return alert('نسبة العمولة يجب أن تكون رقماً بين 0 و 100');
    }
    try {
      const body: any = {};
      if (!isNaN(rate)) body.commission = rate;
      if (note.trim()) body.note = note.trim();
      const res = await fetchWithAdminGuard(`${API()}/api/v1/admin/providers/${selectedId}/approve`, {
        method: 'POST', body: JSON.stringify(body),
      });
      if (res.ok) {
        alert(`تم الاعتماد بنجاح${!isNaN(rate) ? ` بنسبة عمولة ${rate}%` : ''}.`);
        setPendingProviders(prev => prev.filter(p => p.id !== selectedId));
        setSelectedId(null); setCommission(''); setNote('');
      } else {
        const d = await res.json().catch(() => ({}));
        alert(d?.message || 'فشل الاعتماد');
      }
    } catch (e) { console.error(e); alert('خطأ في الاعتماد'); }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) return alert('يرجى إدخال سبب الرفض');
    try {
      const res = await fetchWithAdminGuard(`${API()}/api/v1/admin/providers/${selectedId}/reject`, {
        method: 'POST', body: JSON.stringify({ note: rejectReason.trim() }),
      });
      if (res.ok) {
        alert('تم رفض الحساب وإبلاغ المزود.');
        setPendingProviders(prev => prev.filter(p => p.id !== selectedId));
        setSelectedId(null); setIsRejectOpen(false); setRejectReason('');
      } else {
        const d = await res.json().catch(() => ({}));
        alert(d?.message || 'فشل الرفض');
      }
    } catch (e) { console.error(e); alert('خطأ في الرفض'); }
  };

  const handleDelta = async (id: string, action: 'approve' | 'reject') => {
    try {
      const res = await fetchWithAdminGuard(`${API()}/api/v1/providers/provider-deltas/${id}/${action}`, { method: 'POST' });
      if (res.ok) {
        alert(action === 'approve' ? 'تم اعتماد التعديلات وتطبيقها على الملف الحي.' : 'تم رفض التعديلات.');
        setPendingDeltas(prev => prev.filter(d => d.id !== id));
        setSelectedDelta(null);
      } else {
        const d = await res.json().catch(() => ({}));
        alert(d?.message || 'فشلت العملية');
      }
    } catch (e) { console.error(e); alert('خطأ في تنفيذ العملية'); }
  };

  const selected = pendingProviders.find(p => p.id === selectedId) || null;
  const profile = detail?.profile || {};
  const account = detail?.account || {};
  const bank = detail?.bank;

  const InfoRow = ({ label, value }: { label: string; value: any }) => (
    <div className="flex justify-between items-center p-3 bg-white rounded border border-gray-100">
      <span className="text-gray-500 text-sm">{label}</span>
      <span className="font-bold text-slate-800 text-sm text-left" dir="auto">{value ?? '—'}</span>
    </div>
  );

  return (
    <div className="p-8 h-full flex flex-col">
      <div className="mb-6 flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة المزودين (Provider Moderation)</h1>
          <p className="text-gray-500 mt-1">مراجعة مستندات التسجيل الحقيقية، الاعتماد بنسبة عمولة، ومراجعة التعديلات</p>
        </div>
        <div className="flex border border-gray-300 rounded-lg overflow-hidden bg-white">
          <button className={`px-6 py-2 font-bold ${activeTab === 'onboarding' ? 'bg-teal-600 text-white' : 'text-gray-600 hover:bg-gray-50'}`} onClick={() => { setActiveTab('onboarding'); setSelectedDelta(null); }}>
            توثيق التسجيل ({pendingProviders.length})
          </button>
          <button className={`px-6 py-2 font-bold ${activeTab === 'deltas' ? 'bg-teal-600 text-white' : 'text-gray-600 hover:bg-gray-50'}`} onClick={() => { setActiveTab('deltas'); setSelectedId(null); }}>
            تعديلات الحسابات ({pendingDeltas.length})
          </button>
        </div>
      </div>

      {error && <div className="bg-red-50 text-red-700 rounded-lg p-3 mb-4">{error}</div>}

      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* LEFT: list */}
        <div className="w-1/3 bg-white border border-gray-200 rounded-xl flex flex-col overflow-hidden shadow-sm">
          <div className="p-4 bg-slate-50 border-b border-gray-200 font-bold text-slate-700">
            {activeTab === 'onboarding' ? 'حسابات بانتظار الاعتماد' : 'تعديلات بانتظار المراجعة'}
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {isLoading && <p className="text-center text-gray-400 mt-10">جارٍ التحميل…</p>}
            {!isLoading && activeTab === 'onboarding' && pendingProviders.map(p => (
              <div key={p.id} onClick={() => { setSelectedId(p.id); setCommission(String(DEFAULT_COMMISSION[p.provider_type] ?? 10)); }}
                className={`p-4 border rounded-lg cursor-pointer transition-all ${selectedId === p.id ? 'border-teal-500 bg-teal-50 shadow-md' : 'border-gray-200 hover:border-teal-300'}`}>
                <h3 className="font-bold text-gray-800">{p.display_name_ar || p.display_name_en || p.email}</h3>
                <span className="text-xs bg-slate-200 text-slate-700 px-2 py-1 rounded mt-2 inline-block uppercase tracking-wider">{p.provider_type}</span>
                <div className="text-xs text-gray-400 mt-1" dir="ltr">{p.email}</div>
              </div>
            ))}
            {!isLoading && activeTab === 'deltas' && pendingDeltas.map(d => (
              <div key={d.id} onClick={() => setSelectedDelta(d)}
                className={`p-4 border rounded-lg cursor-pointer transition-all ${selectedDelta?.id === d.id ? 'border-amber-500 bg-amber-50 shadow-md' : 'border-gray-200 hover:border-amber-300'}`}>
                <h3 className="font-bold text-gray-800">{d.provider_name || d.account_id || 'مزود'}</h3>
                <span className="text-xs bg-amber-200 text-amber-800 px-2 py-1 rounded mt-2 inline-block font-bold">طلب تعديل ملف</span>
              </div>
            ))}
            {!isLoading && activeTab === 'onboarding' && pendingProviders.length === 0 && <p className="text-center text-gray-500 mt-10">لا توجد حسابات معلقة</p>}
            {!isLoading && activeTab === 'deltas' && pendingDeltas.length === 0 && <p className="text-center text-gray-500 mt-10">لا توجد تعديلات معلقة</p>}
          </div>
        </div>

        {/* RIGHT: inspector */}
        <div className="w-2/3 bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm flex flex-col relative">
          {activeTab === 'onboarding' && selected ? (
            <div className="flex flex-col h-full">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center bg-slate-900 text-white">
                <h2 className="text-xl font-bold">ملف المزود — مراجعة قبل الاعتماد</h2>
                <span className="bg-slate-700 px-3 py-1 rounded text-sm">{selected.display_name_ar || selected.email}</span>
              </div>

              <div className="flex-1 p-6 overflow-y-auto space-y-6">
                {detailLoading && <p className="text-center text-gray-400 py-10">جارٍ تحميل التفاصيل والمستندات…</p>}

                {!detailLoading && detail && (
                  <>
                    <div>
                      <h3 className="font-bold text-slate-700 mb-2 border-b pb-1">بيانات الحساب والترخيص</h3>
                      <div className="grid grid-cols-2 gap-2">
                        <InfoRow label="النوع" value={account.provider_type} />
                        <InfoRow label="البريد" value={account.email} />
                        <InfoRow label="الاسم القانوني" value={profile.legal_name || profile.name_ar} />
                        <InfoRow label="رقم الترخيص" value={profile.license_number} />
                        <InfoRow label="ترخيص الهيئة (SCFHS)" value={profile.scfhs_license_number} />
                        <InfoRow label="السجل التجاري" value={profile.cr_number} />
                        <InfoRow label="ترخيص وزارة الصحة" value={profile.moh_license_number} />
                        <InfoRow label="المدينة" value={profile.city} />
                        <InfoRow label="التخصص" value={profile.specialty} />
                        <InfoRow label="تاريخ انتهاء الترخيص" value={profile.license_expiry_date ? new Date(profile.license_expiry_date).toLocaleDateString('ar-SA') : null} />
                      </div>
                    </div>

                    {bank && (
                      <div>
                        <h3 className="font-bold text-slate-700 mb-2 border-b pb-1">الحساب البنكي</h3>
                        <div className="grid grid-cols-2 gap-2">
                          <InfoRow label="اسم الحساب" value={bank.holder_name || bank.bank_account_name} />
                          <InfoRow label="الآيبان" value={bank.iban_masked || bank.iban} />
                        </div>
                      </div>
                    )}

                    <div>
                      <h3 className="font-bold text-slate-700 mb-2 border-b pb-1">المستندات المرفوعة ({(detail.documents || []).length})</h3>
                      {(detail.documents || []).length === 0 && (
                        <p className="text-amber-700 bg-amber-50 rounded p-3 text-sm">لم يرفع المزود أي مستندات بعد — لا يُنصح بالاعتماد.</p>
                      )}
                      <div className="grid grid-cols-2 gap-4">
                        {(detail.documents || []).map((doc: any) => (
                          <div key={doc.id} className="space-y-2">
                            <label className="text-sm font-bold text-gray-500">{DOC_TYPE_AR[doc.doc_type] || doc.doc_type}
                              <span className={`mr-2 text-xs px-2 py-0.5 rounded ${doc.review_status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>{doc.review_status || 'pending'}</span>
                            </label>
                            {docUrls[doc.id] ? (
                              <a href={docUrls[doc.id]} target="_blank" rel="noreferrer">
                                <img src={docUrls[doc.id]} alt={doc.doc_type} className="h-44 w-full object-cover rounded border border-gray-200 hover:opacity-90" />
                              </a>
                            ) : (
                              <div className="h-44 bg-gray-100 border-2 border-dashed border-gray-300 rounded flex items-center justify-center text-sm text-gray-400">
                                {doc.mime?.includes('pdf') ? 'ملف PDF' : 'تعذر تحميل المعاينة'}
                                {docUrls[doc.id] === '' && doc.storage_object_id && (
                                  <button onClick={async () => {
                                    const s = await fetchWithAdminGuard(`${API()}/api/v1/storage/${doc.storage_object_id}/signed-url`);
                                    if (s.ok) { const j = await s.json(); if (j.url) window.open(j.url, '_blank'); }
                                  }} className="mr-2 text-teal-600 underline">فتح الملف</button>
                                )}
                              </div>
                            )}
                            {doc.doc_number && <div className="text-xs text-gray-500">رقم المستند: {doc.doc_number}</div>}
                            {doc.expiry_date && <div className="text-xs text-gray-500">ينتهي: {new Date(doc.expiry_date).toLocaleDateString('ar-SA')}</div>}
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Approve bar with commission */}
              <div className="p-5 border-t border-gray-200 bg-slate-50 space-y-3">
                <div className="flex gap-3 items-end">
                  <div className="w-48">
                    <label className="text-xs font-bold text-gray-600 block mb-1">نسبة عمولة المنصة % *</label>
                    <input type="number" min={0} max={100} step={0.5} value={commission}
                      onChange={e => setCommission(e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 text-lg font-bold text-teal-700 bg-white" />
                  </div>
                  <div className="flex-1">
                    <label className="text-xs font-bold text-gray-600 block mb-1">ملاحظة للمزود (اختياري)</label>
                    <input value={note} onChange={e => setNote(e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white" placeholder="ستظهر في سجل الاعتماد" />
                  </div>
                </div>
                <div className="flex gap-4">
                  <button onClick={handleApprove} className="flex-1 bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 rounded-lg shadow transition text-lg">
                    اعتماد المزود {commission !== '' ? `بعمولة ${commission}%` : ''}
                  </button>
                  <button onClick={() => setIsRejectOpen(true)} className="flex-1 bg-red-100 hover:bg-red-200 text-red-700 font-bold py-3 rounded-lg border border-red-200 transition text-lg">
                    رفض الحساب
                  </button>
                </div>
              </div>
            </div>
          ) : activeTab === 'deltas' && selectedDelta ? (
            <div className="flex flex-col h-full bg-slate-50">
              <div className="p-6 border-b border-gray-200 bg-amber-100 text-amber-900">
                <h2 className="text-xl font-bold">مراجعة التعديلات المطلوبة</h2>
                <p className="text-sm mt-1 font-medium">لن تُطبَّق على الملف الحي إلا بعد الاعتماد</p>
              </div>
              <div className="flex-1 p-8 overflow-y-auto">
                <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-3 max-w-2xl mx-auto">
                  {Object.entries(selectedDelta.requested_changes || selectedDelta.changes || {}).map(([k, v]: [string, any]) => (
                    <div key={k} className="flex justify-between items-center p-3 bg-amber-50 rounded border border-amber-100">
                      <span className="text-gray-600 font-mono text-sm" dir="ltr">{k}</span>
                      <span className="font-bold text-slate-800" dir="auto">{String(v)}</span>
                    </div>
                  ))}
                  {Object.keys(selectedDelta.requested_changes || selectedDelta.changes || {}).length === 0 && (
                    <p className="text-gray-400 text-center py-6">لا توجد تفاصيل تغييرات مسجلة</p>
                  )}
                </div>
              </div>
              <div className="p-6 border-t border-gray-200 bg-white flex gap-4">
                <button onClick={() => handleDelta(selectedDelta.id, 'approve')} className="flex-1 bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 rounded-lg shadow text-lg">اعتماد وتطبيق</button>
                <button onClick={() => handleDelta(selectedDelta.id, 'reject')} className="flex-1 bg-red-100 hover:bg-red-200 text-red-700 font-bold py-3 rounded-lg border border-red-200 text-lg">رفض</button>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-400">
              اختر {activeTab === 'onboarding' ? 'مزوداً' : 'تعديلاً'} من القائمة لعرض التفاصيل
            </div>
          )}
        </div>
      </div>

      {/* Reject modal */}
      {isRejectOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[100]">
          <div className="bg-white p-6 rounded-xl w-96 shadow-2xl">
            <h3 className="text-xl font-bold text-red-600 mb-4">تأكيد رفض الحساب</h3>
            <p className="text-sm text-gray-600 mb-4">سيُبلَّغ المزود بالرفض والسبب، ويمكنه استكمال النواقص وإعادة التقديم.</p>
            <textarea
              className="w-full border border-gray-300 rounded p-3 mb-4 h-24"
              placeholder="سبب الرفض (يظهر للمزود)…"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
            />
            <div className="flex gap-3">
              <button onClick={handleReject} className="flex-1 bg-red-600 text-white font-bold py-2 rounded">تأكيد الرفض</button>
              <button onClick={() => setIsRejectOpen(false)} className="flex-1 bg-gray-200 text-gray-800 font-bold py-2 rounded">تراجع</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
