import { useState, useEffect } from 'react';
import { apiFetch } from '../../utils/api';

const PROVIDERS = [
  { key: 'gemini', label: 'Google Gemini', color: '#4285F4' },
  { key: 'openai', label: 'OpenAI (ChatGPT)', color: '#10A37F' },
  { key: 'openrouter', label: 'OpenRouter', color: '#6D5DF6' },
  { key: 'groq', label: 'Groq', color: '#F55036' },
];

export default function AiControlPage() {
  const [active, setActive] = useState('');
  const [usage, setUsage] = useState<any[]>([]);
  const [days, setDays] = useState(7);
  const [switching, setSwitching] = useState(false);

  const load = async () => {
    const [p, u] = await Promise.all([
      apiFetch('/ai/admin/provider').catch(() => null),
      apiFetch(`/ai/admin/usage?days=${days}`).catch(() => []),
    ]);
    if (p) setActive(p.active);
    setUsage(Array.isArray(u) ? u : []);
  };
  useEffect(() => { load(); }, [days]);

  const switchProvider = async (provider: string) => {
    setSwitching(true);
    await apiFetch('/ai/admin/provider', { method: 'POST', body: JSON.stringify({ provider }) }).catch(() => null);
    setActive(provider);
    setSwitching(false);
  };

  return (
    <div className="p-8" dir="rtl">
      <h1 className="text-2xl font-bold mb-2">التحكم في الذكاء الاصطناعي</h1>
      <p className="text-sm text-gray-500 mb-6">تبديل المزود فوراً بدون إعادة نشر — مع تقرير الاستخدام لكل مزود.</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {PROVIDERS.map(p => (
          <button
            key={p.key}
            onClick={() => switchProvider(p.key)}
            disabled={switching || active === p.key}
            className={`p-5 rounded-xl border-2 text-right transition-all ${active === p.key ? 'border-teal-500 bg-teal-50 shadow-md' : 'border-gray-200 bg-white hover:border-gray-400'}`}
          >
            <div className="w-3 h-3 rounded-full mb-2" style={{ backgroundColor: p.color }} />
            <div className="font-bold">{p.label}</div>
            {active === p.key && <div className="text-xs text-teal-600 font-bold mt-1">المزود النشط ✓</div>}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-lg shadow border">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-bold">تقرير الاستخدام</h2>
          <select value={days} onChange={e => setDays(parseInt(e.target.value))} className="border rounded p-2 text-sm">
            <option value={1}>آخر 24 ساعة</option>
            <option value={7}>آخر 7 أيام</option>
            <option value={30}>آخر 30 يوم</option>
          </select>
        </div>
        {usage.length === 0 ? (
          <div className="p-8 text-center text-gray-400">لا استخدام بعد في هذه الفترة</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-3 text-right">المزود</th>
                <th className="p-3 text-right">النموذج</th>
                <th className="p-3 text-right">الميزة</th>
                <th className="p-3 text-right">النداءات</th>
                <th className="p-3 text-right">الفشل</th>
                <th className="p-3 text-right">متوسط الزمن</th>
              </tr>
            </thead>
            <tbody>
              {usage.map((u: any, i: number) => (
                <tr key={i} className="border-t hover:bg-gray-50">
                  <td className="p-3 font-bold">{u._id.provider}</td>
                  <td className="p-3 text-xs" dir="ltr">{u._id.model}</td>
                  <td className="p-3">{u._id.feature}</td>
                  <td className="p-3">{u.calls}</td>
                  <td className={`p-3 ${u.failures > 0 ? 'text-red-600 font-bold' : 'text-green-600'}`}>{u.failures}</td>
                  <td className="p-3">{Math.round(u.avg_ms)}ms</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
